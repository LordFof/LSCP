package cz.ls170.colormatcher

import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.os.ParcelUuid
import java.util.UUID

class Ls170Ble(private val context:Context, private val onRgb:(Int,Int,Int)->Unit, private val onState:(String)->Unit) {
    private val serviceNotify=UUID.fromString("0000FFE0-0000-1000-8000-00805F9B34FB")
    private val charNotify=UUID.fromString("0000FFE4-0000-1000-8000-00805F9B34FB")
    private val serviceWrite=UUID.fromString("0000FFE5-0000-1000-8000-00805F9B34FB")
    private val charWrite=UUID.fromString("0000FFE9-0000-1000-8000-00805F9B34FB")
    private val command=byteArrayOf(0xAB.toByte(),0x44,0,0,0,0,0x36,0,0x18,0x64)
    private var gatt:BluetoothGatt?=null

    private val cb=object:BluetoothGattCallback(){
        override fun onConnectionStateChange(g:BluetoothGatt,status:Int,newState:Int){
            if(newState==BluetoothProfile.STATE_CONNECTED){ onState("Připojeno"); g.discoverServices() }
            else if(newState==BluetoothProfile.STATE_DISCONNECTED) onState("Odpojeno")
        }
        override fun onServicesDiscovered(g:BluetoothGatt,status:Int){
            val c=g.getService(serviceNotify)?.getCharacteristic(charNotify)
            if(c!=null){
                g.setCharacteristicNotification(c,true)
                c.descriptors?.forEach { d ->
                    if(d.uuid.toString().equals("00002902-0000-1000-8000-00805f9b34fb",true)){
                        d.value=BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                        g.writeDescriptor(d)
                    }
                }
            }
            onState("Připraveno")
        }
        override fun onCharacteristicChanged(g:BluetoothGatt,c:BluetoothGattCharacteristic){
            val d=c.value
            if(d.size>=39){
                val r=d[36].toInt() and 255
                val gr=d[37].toInt() and 255
                val b=d[38].toInt() and 255
                onRgb(r,gr,b)
            }
        }
    }

    fun connect(device:BluetoothDevice){ gatt=device.connectGatt(context,false,cb) }
    fun measure(){
        val c=gatt?.getService(serviceWrite)?.getCharacteristic(charWrite) ?: return
        c.value=command
        gatt?.writeCharacteristic(c)
    }
    fun close(){ gatt?.close(); gatt=null }
}
