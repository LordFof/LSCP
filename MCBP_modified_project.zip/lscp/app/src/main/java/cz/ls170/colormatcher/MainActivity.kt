package cz.ls170.colormatcher

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothManager
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var result: TextView
    private lateinit var scan: Button
    private lateinit var measure: Button
    private lateinit var database: Button
    private lateinit var savedColorsButton: Button
    private lateinit var redSeek: SeekBar
    private lateinit var greenSeek: SeekBar
    private lateinit var blueSeek: SeekBar
    private lateinit var rgbValues: TextView
    private var updatingSliders = false
    private var ble: Ls170Ble? = null
    private var colors: List<NamedColor> = emptyList()
    private var scanning = false
    private lateinit var scanner: BluetoothLeScanner
    private val prefs by lazy { getSharedPreferences("mcbp_colors", Context.MODE_PRIVATE) }

    private fun colorKey(c: NamedColor) = "%d,%d,%d".format(c.r, c.g, c.b)
    private fun displayName(c: NamedColor): String =
        prefs.getString("name_${colorKey(c)}", null)?.takeIf { it.isNotBlank() } ?: c.name

    private fun isSaved(c: NamedColor): Boolean = prefs.getBoolean("saved_${colorKey(c)}", false)

    private fun setSaved(c: NamedColor, saved: Boolean) {
        prefs.edit().putBoolean("saved_${colorKey(c)}", saved).apply()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this).apply { setBackgroundColor(Color.DKGRAY) }
        result = TextView(this).apply {
            text = "Zatím žádné měření"
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.DKGRAY)
            setPadding(24, 120, 24, 220)
        }
        root.addView(result, FrameLayout.LayoutParams(-1, -1))

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(0x66000000)
        }
        status = TextView(this).apply {
            text = "Načítám…"
            textSize = 18f
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, 12)
        }
        scan = Button(this).apply { text = "Hledat LS170" }
        measure = Button(this).apply { text = "Měřit (dálkově)" }
        database = Button(this).apply { text = "Databáze barev" }
        savedColorsButton = Button(this).apply { text = "ULOŽENÉ BARVY" }
        controls.addView(status)
        controls.addView(scan)
        controls.addView(measure)
        controls.addView(database)
        controls.addView(savedColorsButton)

        rgbValues = TextView(this).apply {
            text = "RGB 128, 128, 128   #808080"
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(0, 12, 0, 2)
        }
        controls.addView(rgbValues)

        fun addSlider(label: String, initial: Int): SeekBar {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val tv = TextView(this).apply {
                text = label
                textSize = 16f
                setTextColor(Color.WHITE)
                minWidth = 34
            }
            val sb = SeekBar(this).apply {
                max = 255
                progress = initial
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            row.addView(tv)
            row.addView(sb)
            controls.addView(row)
            return sb
        }
        redSeek = addSlider("R", 128)
        greenSeek = addSlider("G", 128)
        blueSeek = addSlider("B", 128)

        val sliderListener = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!updatingSliders && fromUser) {
                    val rr = redSeek.progress
                    val gg = greenSeek.progress
                    val bb = blueSeek.progress
                    val nearest = nearestColor(rr, gg, bb)
                    updateDisplayedColor(rr, gg, bb, nearest?.let(::displayName))
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        }
        redSeek.setOnSeekBarChangeListener(sliderListener)
        greenSeek.setOnSeekBarChangeListener(sliderListener)
        blueSeek.setOnSeekBarChangeListener(sliderListener)
        root.addView(controls, FrameLayout.LayoutParams(-1, -2).apply { gravity = Gravity.TOP })

        val credit = TextView(this).apply {
            text = "Created by LordFof"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(12, 6, 12, 6)
            setBackgroundColor(0x66000000)
        }
        root.addView(credit, FrameLayout.LayoutParams(-2, -2).apply {
            gravity = Gravity.BOTTOM or Gravity.END
            setMargins(0, 0, 12, 12)
        })
        setContentView(root)

        if (android.os.Build.VERSION.SDK_INT >= 31) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT), 10)
        }

        Executors.newSingleThreadExecutor().execute {
            try {
                colors = ColorDb.load()
                runOnUiThread { status.text = "Databáze: ${colors.size} barev • připraveno" }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Databáze barev se nepodařila načíst" }
            }
        }

        val manager = getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
        scanner = manager.adapter.bluetoothLeScanner

        scan.setOnClickListener {
            ble?.close()
            stopScan()
            startScan()
        }
        measure.setOnClickListener {
            if (ble?.triggerMeasurement() == true) status.text = "Příkaz odeslán • čekám na měření…"
            else status.text = "LS170 není připravený — nejdřív ho připoj"
        }
        database.setOnClickListener { showColorDatabase() }
        savedColorsButton.setOnClickListener { showSavedColors() }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun showColorDatabase() {
        if (colors.isEmpty()) {
            Toast.makeText(this, "Databáze barev ještě není načtená", Toast.LENGTH_SHORT).show()
            return
        }
        val dialog = AlertDialog.Builder(this).create()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(10))
        }
        val title = TextView(this).apply {
            text = "Databáze barev"
            textSize = 22f
            setPadding(0, 0, 0, dp(10))
        }
        val search = EditText(this).apply {
            hint = "RGB 255,0,0 / #FF0000 / název"
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
        }
        val scroll = ScrollView(this)
        val listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(listBox)
        box.addView(title)
        box.addView(search)
        box.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        dialog.setView(box)
        dialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Zavřít") { _, _ -> dialog.dismiss() }

        val sorted = colors.sortedBy { displayName(it).lowercase(Locale.getDefault()) }

        fun rebuild(qRaw: String) {
            val q = qRaw.trim().lowercase(Locale.getDefault())
            val shown = if (q.isEmpty()) sorted else sorted.filter { c ->
                val name = displayName(c).lowercase(Locale.getDefault())
                val rgb = "${c.r},${c.g},${c.b}"
                val rgbSpaced = "${c.r} ${c.g} ${c.b}"
                val hex = "%02x%02x%02x".format(c.r, c.g, c.b)
                name.contains(q) || rgb.contains(q.replace(" ", "")) ||
                    rgbSpaced.contains(q) || hex.contains(q.removePrefix("#"))
            }
            listBox.removeAllViews()
            shown.forEach { c ->
                listBox.addView(databaseRow(c, dialog))
            }
        }

        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) =
                rebuild(s?.toString().orEmpty())
            override fun afterTextChanged(s: android.text.Editable?) = Unit
        })
        rebuild("")
        dialog.show()
        dialog.window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.94).toInt(),
            (resources.displayMetrics.heightPixels * 0.88).toInt()
        )
    }

    private fun databaseRow(c: NamedColor, dialog: AlertDialog): View {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(6), 0, dp(6))
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val info = TextView(this).apply {
            text = "${displayName(c)}\nRGB ${c.r}, ${c.g}, ${c.b}   #%02X%02X%02X".format(c.r, c.g, c.b)
            textSize = 15f
            setTextColor(Color.BLACK)
            setPadding(dp(4), dp(4), dp(4), dp(4))
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            setOnClickListener {
                showColorOnMainScreen(c)
                dialog.dismiss()
                status.text = "Vybraná barva: ${displayName(c)}"
            }
        }
        val save = Button(this).apply {
            text = if (isSaved(c)) "ULOŽENO" else "ULOŽIT"
            setOnClickListener {
                val now = !isSaved(c)
                setSaved(c, now)
                text = if (now) "ULOŽENO" else "ULOŽIT"
                Toast.makeText(this@MainActivity, if (now) "Barva uložena" else "Barva odebrána", Toast.LENGTH_SHORT).show()
            }
        }
        val rename = Button(this).apply {
            text = "NÁZEV"
            setOnClickListener { editColorName(c, dialog) }
        }
        top.addView(info)
        top.addView(save, LinearLayout.LayoutParams(dp(92), -2))
        top.addView(rename, LinearLayout.LayoutParams(dp(82), -2))
        outer.addView(top)
        val line = View(this).apply { setBackgroundColor(0x33000000) }
        outer.addView(line, LinearLayout.LayoutParams(-1, dp(1)))
        return outer
    }

    private fun editColorName(c: NamedColor, databaseDialog: AlertDialog) {
        val input = EditText(this).apply {
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setText(displayName(c))
            selectAll()
        }
        AlertDialog.Builder(this)
            .setTitle("Název barvy")
            .setView(input)
            .setNegativeButton("Zrušit", null)
            .setPositiveButton("ULOŽIT") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    prefs.edit().putString("name_${colorKey(c)}", name).apply()
                    databaseDialog.dismiss()
                    showColorDatabase()
                    Toast.makeText(this, "Název uložen: $name", Toast.LENGTH_SHORT).show()
                }
            }
            .show()
    }

    private fun showSavedColors() {
        val saved = colors.filter(::isSaved).sortedBy { displayName(it).lowercase(Locale.getDefault()) }
        val dialog = AlertDialog.Builder(this).create()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(10))
        }
        box.addView(TextView(this).apply {
            text = "ULOŽENÉ BARVY"
            textSize = 22f
            setPadding(0, 0, 0, dp(10))
        })
        if (saved.isEmpty()) {
            box.addView(TextView(this).apply {
                text = "Zatím nemáš uloženou žádnou barvu."
                textSize = 17f
                setPadding(0, dp(12), 0, dp(12))
            })
        } else {
            val scroll = ScrollView(this)
            val listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            saved.forEach { c ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, dp(5), 0, dp(5))
                }
                val info = TextView(this).apply {
                    text = "${displayName(c)}\nRGB ${c.r}, ${c.g}, ${c.b}   #%02X%02X%02X".format(c.r, c.g, c.b)
                    textSize = 15f
                    setTextColor(Color.BLACK)
                    layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                    setOnClickListener {
                        showColorOnMainScreen(c)
                        dialog.dismiss()
                        status.text = "Vybraná uložená barva: ${displayName(c)}"
                    }
                }
                val remove = Button(this).apply {
                    text = "SMAZAT"
                    setOnClickListener {
                        setSaved(c, false)
                        dialog.dismiss()
                        showSavedColors()
                    }
                }
                row.addView(info)
                row.addView(remove, LinearLayout.LayoutParams(dp(90), -2))
                listBox.addView(row)
            }
            scroll.addView(listBox)
            box.addView(scroll, LinearLayout.LayoutParams(-1, dp(480)))
        }
        dialog.setView(box)
        dialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Zavřít") { _, _ -> dialog.dismiss() }
        dialog.show()
        dialog.window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.94).toInt(),
            (resources.displayMetrics.heightPixels * 0.82).toInt()
        )
    }

    private fun showColorOnMainScreen(c: NamedColor) {
        updateDisplayedColor(c.r, c.g, c.b, displayName(c))
    }

    private fun nearestColor(r: Int, g: Int, b: Int): NamedColor? {
        if (colors.isEmpty()) return null
        val lab = ColorMath.rgbToLab(r, g, b)
        return colors.minByOrNull { ColorMath.deltaE00(lab, it.lab) }
    }

    private fun updateDisplayedColor(r: Int, g: Int, b: Int, name: String?) {
        val rr = r.coerceIn(0, 255)
        val gg = g.coerceIn(0, 255)
        val bb = b.coerceIn(0, 255)
        updatingSliders = true
        redSeek.progress = rr
        greenSeek.progress = gg
        blueSeek.progress = bb
        updatingSliders = false
        result.setBackgroundColor(Color.rgb(rr, gg, bb))
        val brightness = (rr * 299 + gg * 587 + bb * 114) / 1000
        result.setTextColor(if (brightness < 140) Color.WHITE else Color.BLACK)
        val hex = "#%02X%02X%02X".format(rr, gg, bb)
        rgbValues.text = "RGB $rr, $gg, $bb   $hex"
        result.text = if (name != null) "$name\nRGB $rr, $gg, $bb\n$hex" else "RGB $rr, $gg, $bb\n$hex"
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, r: ScanResult) {
            val name = try { r.device.name } catch (_: SecurityException) { null }
            if (name.isNullOrBlank() || !name.contains("LS170", true)) return
            stopScan(); ble?.close()
            ble = Ls170Ble(this@MainActivity, { rr, gg, bb ->
                val lab = ColorMath.rgbToLab(rr, gg, bb)
                val best = colors.minByOrNull { ColorMath.deltaE00(lab, it.lab) }
                runOnUiThread {
                    updateDisplayedColor(rr, gg, bb, best?.let(::displayName))
                    status.text = if (best != null) "Měření přijato • ΔE00 %.2f".format(ColorMath.deltaE00(lab, best.lab)) else "Měření přijato"
                }
            }, { s -> runOnUiThread { status.text = s } })
            ble?.connect(r.device)
        }
        override fun onScanFailed(errorCode: Int) {
            scanning = false
            runOnUiThread { status.text = "Skenování selhalo: $errorCode" }
        }
    }

    private fun startScan() {
        if (android.os.Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
            status.text = "Povol Bluetooth skenování a zkus znovu"; return
        }
        if (scanning) return
        scanning = true; status.text = "Hledám LS170…"; scanner.startScan(scanCallback)
    }

    private fun stopScan() {
        if (!scanning) return
        if (android.os.Build.VERSION.SDK_INT < 31 || checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED) scanner.stopScan(scanCallback)
        scanning = false
    }

    override fun onDestroy() {
        stopScan()
        ble?.close()
        super.onDestroy()
    }
}
