# LS170 Color Matcher — complete project

This is the complete Android project, not a patch.

## Build
GitHub Actions workflow: `.github/workflows/build-apk.yml`.
It installs Gradle 8.7 and builds `app-debug.apk`.

## Measurement
1. Open the app.
2. Tap `Hledat LS170`.
3. Wait for `PŘIPRAVENO`.
4. Press the physical measurement button on the LS170.
5. The app reads RGB from response bytes 36, 37 and 38, shows the measured color, RGB, HEX, closest database color and ΔE00.
6. `Měřit (dálkově)` remains only as an optional remote trigger.

If the device disconnects, the GATT state is closed and a new scan can reconnect.
