package cz.ls170.colormatcher

import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothProfile
import android.content.Context
import java.util.UUID

class Ls170Ble(
    private val context: Context,
    private val onRgb: (Int, Int, Int, String) -> Unit,
    private val onState: (String) -> Unit
) {
    companion object {
        private val SERVICE_NOTIFY = UUID.fromString("0000FFE0-0000-1000-8000-00805F9B34FB")
        private val CHAR_NOTIFY = UUID.fromString("0000FFE4-0000-1000-8000-00805F9B34FB")
        private val SERVICE_WRITE = UUID.fromString("0000FFE5-0000-1000-8000-00805F9B34FB")
        private val CHAR_WRITE = UUID.fromString("0000FFE9-0000-1000-8000-00805F9B34FB")
        private val CCCD = UUID.fromString("00002902-0000-1000-8000-00805F9B34FB")
    }

    private var gatt: BluetoothGatt? = null
    private var notifyChar: BluetoothGattCharacteristic? = null
    private var writeChar: BluetoothGattCharacteristic? = null
    private var deviceName = "LS170"
    private var ready = false
    private val packet = ArrayList<Byte>()

    private val callback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED && status == BluetoothGatt.GATT_SUCCESS) {
                gatt = g
                ready = false
                onState("PŘIPOJENO: $deviceName — zjišťuji služby…")
                g.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                ready = false
                notifyChar = null
                writeChar = null
                packet.clear()
                if (gatt === g) gatt = null
                g.close()
                onState("ODPOJENO: $deviceName — stiskni Hledat LS170")
            } else if (status != BluetoothGatt.GATT_SUCCESS) {
                ready = false
                onState("BLE chyba: $status")
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                ready = false
                onState("Chyba při zjišťování služeb: $status")
                g.close(); gatt = null
                return
            }

            val n = g.getService(SERVICE_NOTIFY)?.getCharacteristic(CHAR_NOTIFY)
            val w = g.getService(SERVICE_WRITE)?.getCharacteristic(CHAR_WRITE)
            if (n == null || w == null) {
                ready = false
                onState("LS170 připojeno, ale nenašel jsem FFE4/FFE9")
                g.close(); gatt = null
                return
            }

            notifyChar = n
            writeChar = w
            if (!g.setCharacteristicNotification(n, true)) {
                ready = false
                onState("Nepodařilo se zapnout BLE notifikace")
                return
            }

            val d = n.getDescriptor(CCCD)
            if (d == null) {
                ready = true
                onState("PŘIPRAVENO: stiskni tlačítko na LS170")
                return
            }
            d.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            if (!g.writeDescriptor(d)) {
                ready = false
                onState("Nepodařilo se zapnout BLE notifikace")
            } else {
                onState("PŘIPOJENO: čekám na měření z tlačítka LS170…")
            }
        }

        override fun onDescriptorWrite(g: BluetoothGatt, descriptor: BluetoothGattDescriptor, status: Int) {
            if (descriptor.uuid == CCCD) {
                ready = status == BluetoothGatt.GATT_SUCCESS
                onState(if (ready) "PŘIPRAVENO: stiskni tlačítko na LS170" else "Notifikace LS170 selhaly: $status")
            }
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            if (characteristic.uuid != CHAR_NOTIFY) return
            val data = characteristic.value ?: return
            if (data.isEmpty()) return

            // Notifications can be fragmented, and Android may deliver more than one
            // measurement over the lifetime of a connection. Keep a rolling buffer,
            // resynchronise on the LS170 response header, and never treat arbitrary
            // bytes from a previous measurement as RGB.
            packet.addAll(data.toList())

            while (true) {
                val start = findHeader(packet)
                if (start < 0) {
                    // Keep only a possible partial header.
                    if (packet.size > 1) {
                        val last = packet.last()
                        packet.clear()
                        if ((last.toInt() and 0xFF) == 0xAB) packet.add(last)
                    }
                    return
                }

                if (start > 0) repeat(start) { packet.removeAt(0) }
                if (packet.size < 39) return

                val r = packet[36].toInt() and 0xFF
                val gr = packet[37].toInt() and 0xFF
                val b = packet[38].toInt() and 0xFF
                val hex = packet.joinToString("") { "%02X".format(it.toInt() and 0xFF) }

                // The LS170 response used by LSColor has RGB at bytes 36..38.
                // Consume exactly the response portion we use, then resynchronise
                // if another response is already waiting in the buffer.
                repeat(39) { packet.removeAt(0) }
                if (ready) onRgb(r, gr, b, hex)
            }
        }

        private fun findHeader(bytes: List<Byte>): Int {
            for (i in 0 until bytes.size - 1) {
                if ((bytes[i].toInt() and 0xFF) == 0xAB &&
                    (bytes[i + 1].toInt() and 0xFF) == 0x44) return i
            }
            return -1
        }
    }

    fun connect(device: BluetoothDevice) {
        close(false)
        deviceName = device.name?.takeIf { it.isNotBlank() } ?: "LS170"
        onState("PŘIPOJUJI: $deviceName…")
        gatt = device.connectGatt(context, false, callback)
    }

    /** Optional remote trigger. The physical LS170 button remains the primary trigger. */
    fun triggerMeasurement(): Boolean {
        val g = gatt ?: return false
        val w = writeChar ?: return false
        if (!ready) return false
        // LS170 accepts the remote measurement command as a write-without-response.
        // Using NO_RESPONSE also matches the way this characteristic is exposed by the device.
        w.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
        w.value = byteArrayOf(
            0xAB.toByte(), 0x44.toByte(), 0x00, 0x00, 0x00, 0x00,
            0x36.toByte(), 0x00, 0x18.toByte(), 0x64.toByte()
        )
        return try {
            @Suppress("DEPRECATION")
            g.writeCharacteristic(w)
        } catch (_: Exception) { false }
    }

    fun close() = close(true)

    private fun close(showState: Boolean) {
        ready = false
        notifyChar = null
        writeChar = null
        packet.clear()
        gatt?.disconnect()
        gatt?.close()
        gatt = null
        if (showState) onState("Odpojeno")
    }
}
