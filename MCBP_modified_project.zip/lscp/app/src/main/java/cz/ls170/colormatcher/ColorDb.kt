package cz.ls170.colormatcher

import android.content.Context
import org.json.JSONObject
import java.net.URL

data class NamedColor(val name:String,val r:Int,val g:Int,val b:Int,val lab:Lab)

object ColorDb {
    private const val URL_JSON =
        "https://gist.githubusercontent.com/gurkanakdeniz/dbbf7fd89d887ac4b56ef9e316e18fc6/raw/"
    private const val PREFS = "color_custom_names"

    fun load(context: Context): List<NamedColor> {
        val text=URL(URL_JSON).readText()
        val obj=JSONObject(text)
        val prefs=context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val out=ArrayList<NamedColor>(obj.length())
        for (k in obj.keys()) {
            val h=k.removePrefix("#")
            if(h.length!=6) continue
            val r=h.substring(0,2).toInt(16)
            val g=h.substring(2,4).toInt(16)
            val b=h.substring(4,6).toInt(16)
            val key="#%02X%02X%02X".format(r,g,b)
            val original=obj.getString(k)
            val name=prefs.getString(key, original) ?: original
            out += NamedColor(name,r,g,b,ColorMath.rgbToLab(r,g,b))
        }
        return out
    }

    fun saveCustomName(context: Context, c: NamedColor, name: String) {
        val key="#%02X%02X%02X".format(c.r,c.g,c.b)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(key,name).apply()
    }
}
