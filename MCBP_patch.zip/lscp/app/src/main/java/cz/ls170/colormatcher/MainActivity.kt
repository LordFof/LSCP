package cz.ls170.colormatcher

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothManager
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.FrameLayout
import android.widget.TextView
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var result: TextView
    private lateinit var scan: Button
    private lateinit var measure: Button
    private var ble: Ls170Ble? = null
    private var colors: List<NamedColor> = emptyList()
    private var scanning = false
    private lateinit var scanner: BluetoothLeScanner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.DKGRAY)
        }

        result = TextView(this).apply {
            text = "Zatím žádné měření"
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.DKGRAY)
            setPadding(24, 120, 24, 220)
        }
        root.addView(result, FrameLayout.LayoutParams(-1, -1))

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(0x66000000)
        }
        status = TextView(this).apply {
            text = "Načítám…"
            textSize = 18f
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, 18)
        }
        scan = Button(this).apply { text = "Hledat LS170" }
        measure = Button(this).apply { text = "Měřit (dálkově)" }
        controls.addView(status)
        controls.addView(scan)
        controls.addView(measure)
        val controlParams = FrameLayout.LayoutParams(-1, -2).apply {
            gravity = Gravity.TOP
        }
        root.addView(controls, controlParams)
        setContentView(root)

        if (android.os.Build.VERSION.SDK_INT >= 31) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT), 10)
        }

        Executors.newSingleThreadExecutor().execute {
            try {
                colors = ColorDb.load()
                runOnUiThread { status.text = "Databáze: ${colors.size} barev • připraveno" }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Databáze barev se nepodařila načíst: ${e.message}" }
            }
        }

        val manager = getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
        scanner = manager.adapter.bluetoothLeScanner

        scan.setOnClickListener {
            ble?.close()
            stopScan()
            startScan()
        }

        measure.setOnClickListener {
            if (ble?.triggerMeasurement() == true) {
                status.text = "Příkaz odeslán • čekám na odpověď LS170…"
            } else {
                status.text = "LS170 není připravený — nejdřív ho připoj"
            }
        }
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, r: ScanResult) {
            val name = try { r.device.name } catch (_: SecurityException) { null }
            if (name.isNullOrBlank() || !name.contains("LS170", true)) return

            stopScan()
            ble?.close()
            ble = Ls170Ble(
                this@MainActivity,
                { rr, gg, bb ->
                    val lab = ColorMath.rgbToLab(rr, gg, bb)
                    val best = colors.minByOrNull { ColorMath.deltaE00(lab, it.lab) }
                    runOnUiThread {
                        val measured = Color.rgb(rr, gg, bb)
                        result.setBackgroundColor(measured)
                        val brightness = (rr * 299 + gg * 587 + bb * 114) / 1000
                        result.setTextColor(if (brightness < 140) Color.WHITE else Color.BLACK)
                        if (best != null) {
                            result.text = "${best.name}\nRGB $rr, $gg, $bb\n#%02X%02X%02X".format(rr, gg, bb)
                            status.text = "Měření přijato • ΔE00 %.2f".format(ColorMath.deltaE00(lab, best.lab))
                        } else {
                            result.text = "RGB $rr, $gg, $bb\n#%02X%02X%02X".format(rr, gg, bb)
                            status.text = "Měření přijato • databáze barev není načtená"
                        }
                    }
                },
                { s -> runOnUiThread { status.text = s } }
            )
            ble?.connect(r.device)
        }

        override fun onScanFailed(errorCode: Int) {
            scanning = false
            runOnUiThread { status.text = "Skenování selhalo: $errorCode" }
        }
    }

    private fun startScan() {
        if (android.os.Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
            status.text = "Povol Bluetooth skenování a zkus znovu"
            return
        }
        if (scanning) return
        scanning = true
        status.text = "Hledám LS170…"
        scanner.startScan(scanCallback)
    }

    private fun stopScan() {
        if (!scanning) return
        if (android.os.Build.VERSION.SDK_INT < 31 || checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED) {
            scanner.stopScan(scanCallback)
        }
        scanning = false
    }

    override fun onDestroy() {
        stopScan()
        ble?.close()
        super.onDestroy()
    }
}
