package cz.ls170.colormatcher

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothManager
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.os.Build
import android.provider.MediaStore
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var result: TextView
    private lateinit var scan: Button
    private lateinit var measure: Button
    private lateinit var database: Button
    private lateinit var savedColorsButton: Button
    private lateinit var cardsButton: Button
    private lateinit var redSeek: SeekBar
    private lateinit var greenSeek: SeekBar
    private lateinit var blueSeek: SeekBar
    private var cardsListContainer: LinearLayout? = null
    private var cardsDialogRef: AlertDialog? = null
    private lateinit var rgbValues: TextView
    private var updatingSliders = false
    private var ble: Ls170Ble? = null
    private var colors: List<NamedColor> = emptyList()
    private var scanning = false
    private lateinit var scanner: BluetoothLeScanner
    private val prefs by lazy { getSharedPreferences("mcbp_colors", Context.MODE_PRIVATE) }
    private val cardsPrefs by lazy { getSharedPreferences("mcbp_cards", Context.MODE_PRIVATE) }
    private val uiPrefs by lazy { getSharedPreferences("mcbp_ui", Context.MODE_PRIVATE) }
    private var activeCardId: String? = null
    private lateinit var menuButtonRef: TextView
    private lateinit var rgbButtonRef: TextView
    private lateinit var menuPanelRef: LinearLayout
    private lateinit var rgbPanelRef: LinearLayout
    private lateinit var mainRootRef: FrameLayout
    private var settingsDialog: AlertDialog? = null
    private var previewOverlay: View? = null
    private var previewPopup: View? = null
    private var previewScroll: ScrollView? = null
    private var previewBox: LinearLayout? = null
    private var previewActiveRow: View? = null
    private var previewHiddenRows: MutableList<View> = mutableListOf()
    private var menuButtons: MutableList<Button> = mutableListOf()

    private fun colorKey(c: NamedColor) = "%d,%d,%d".format(c.r, c.g, c.b)
    private fun displayName(c: NamedColor): String =
        prefs.getString("name_${colorKey(c)}", null)?.takeIf { it.isNotBlank() } ?: c.name

    private fun isSaved(c: NamedColor): Boolean = prefs.getBoolean("saved_${colorKey(c)}", false)

    private fun setSaved(c: NamedColor, saved: Boolean) {
        prefs.edit().putBoolean("saved_${colorKey(c)}", saved).apply()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this).apply { setBackgroundColor(Color.rgb(28, 32, 38)) }

        result = TextView(this).apply {
            text = "Zatím žádné měření"
            textSize = if (resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE) 48f else 64f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(dp(18), dp(88), dp(18), dp(88))
            includeFontPadding = true
        }
        root.addView(result, FrameLayout.LayoutParams(-1, -1))

        // RGB controls are hidden behind their own floating button so they never cover the main result.
        val sliderPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(18), dp(10), dp(18), dp(8))
            background = aeroBackground(uiColor("menu_panel", 0xD0181818.toInt()), dp(24))
            elevation = dp(12).toFloat()
            visibility = View.GONE
        }

        rgbValues = TextView(this).apply {
            text = "RGB 128, 128, 128   #808080"
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, dp(4))
        }
        sliderPanel.addView(rgbValues, LinearLayout.LayoutParams(-1, dp(34)))

        fun addMainSlider(label: String, initial: Int): SeekBar {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val tv = TextView(this).apply {
                text = label
                textSize = 20f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                minWidth = dp(38)
            }
            val sb = SeekBar(this).apply {
                max = 255
                progress = initial
                minHeight = dp(34)
                layoutParams = LinearLayout.LayoutParams(0, dp(46), 1f)
            }
            row.addView(tv, LinearLayout.LayoutParams(dp(42), dp(46)))
            row.addView(sb)
            sliderPanel.addView(row, LinearLayout.LayoutParams(-1, dp(46)))
            return sb
        }

        redSeek = addMainSlider("R", 128)
        greenSeek = addMainSlider("G", 128)
        blueSeek = addMainSlider("B", 128)

        val mainOverlay = FrameLayout(this)
        mainOverlay.addView(sliderPanel, FrameLayout.LayoutParams(dp(310), dp(190)).apply {
            gravity = Gravity.TOP or Gravity.START
            setMargins(dp(12), dp(78), 0, 0)
        })

        val rgbButton = TextView(this).apply {
            text = "RGB"
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = aeroBackground(uiColor("rgb", 0x66000000.toInt()), dp(30))
            elevation = dp(10).toFloat()
            contentDescription = "RGB posuvníky"
        }
        rgbButtonRef = rgbButton
        mainOverlay.addView(rgbButton, FrameLayout.LayoutParams(dp(62), dp(58)).apply {
            gravity = Gravity.TOP or Gravity.START
            setMargins(dp(12), dp(10), 0, 0)
        })
        root.addView(mainOverlay, FrameLayout.LayoutParams(-1, -1))
        mainRootRef = root

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = aeroBackground(uiColor("menu_panel", 0xD0181818.toInt()), dp(24))
            elevation = dp(12).toFloat()
            visibility = View.GONE
        }
        status = TextView(this).apply {
            text = "Načítám…"
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, dp(8))
        }
        scan = makeAeroButton("Hledat LS170")
        measure = makeAeroButton("Měřit")
        database = makeAeroButton("Databáze barev")
        savedColorsButton = makeAeroButton("ULOŽENÉ BARVY")
        cardsButton = makeAeroButton("KARTY")
        val settingsButton = makeAeroButton("NASTAVENÍ")
        controls.addView(status)
        controls.addView(scan, LinearLayout.LayoutParams(-1, dp(40)).apply { bottomMargin = dp(5) })
        controls.addView(measure, LinearLayout.LayoutParams(-1, dp(40)).apply { bottomMargin = dp(5) })
        controls.addView(database, LinearLayout.LayoutParams(-1, dp(40)).apply { bottomMargin = dp(5) })
        controls.addView(savedColorsButton, LinearLayout.LayoutParams(-1, dp(40)).apply { bottomMargin = dp(5) })
        controls.addView(cardsButton, LinearLayout.LayoutParams(-1, dp(40)).apply { bottomMargin = dp(5) })
        controls.addView(settingsButton, LinearLayout.LayoutParams(-1, dp(40)))
        menuButtons = mutableListOf(scan, measure, database, savedColorsButton, cardsButton, settingsButton)

        val menuWrap = FrameLayout(this)
        menuWrap.addView(controls, FrameLayout.LayoutParams(dp(245), -2).apply {
            gravity = Gravity.TOP or Gravity.END
            setMargins(0, dp(78), dp(12), 0)
        })
        val menuButton = TextView(this).apply {
            text = "☰"
            textSize = 23f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = aeroBackground(uiColor("menu", 0x66000000.toInt()), dp(30))
            elevation = dp(10).toFloat()
            contentDescription = "Nabídka"
        }
        menuButtonRef = menuButton
        menuWrap.addView(menuButton, FrameLayout.LayoutParams(dp(58), dp(58)).apply {
            gravity = Gravity.TOP or Gravity.END
            setMargins(0, dp(10), dp(12), 0)
        })
        root.addView(menuWrap, FrameLayout.LayoutParams(-1, -1))

        menuPanelRef = controls
        rgbPanelRef = sliderPanel

        var menuOpen = false
        menuButton.setOnClickListener {
            menuOpen = !menuOpen
            controls.visibility = if (menuOpen) View.VISIBLE else View.GONE
            menuButton.text = if (menuOpen) "×" else "☰"
        }
        var rgbOpen = false
        rgbButton.setOnClickListener {
            rgbOpen = !rgbOpen
            sliderPanel.visibility = if (rgbOpen) View.VISIBLE else View.GONE
            rgbButton.text = if (rgbOpen) "×" else "RGB"
        }

        val sliderListener = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!updatingSliders && fromUser) {
                    val rr = redSeek.progress
                    val gg = greenSeek.progress
                    val bb = blueSeek.progress
                    val nearest = nearestColor(rr, gg, bb)
                    updateDisplayedColor(rr, gg, bb, nearest?.let(::displayName))
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        }
        redSeek.setOnSeekBarChangeListener(sliderListener)
        greenSeek.setOnSeekBarChangeListener(sliderListener)
        blueSeek.setOnSeekBarChangeListener(sliderListener)

        val credit = TextView(this).apply {
            text = "Created by LordFof"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(0xCCFFFFFF.toInt())
        }
        root.addView(credit, FrameLayout.LayoutParams(-2, -2).apply {
            gravity = Gravity.BOTTOM or Gravity.START
            setMargins(dp(12), 0, 0, dp(14))
        })
        setContentView(root)

        if (android.os.Build.VERSION.SDK_INT >= 31) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT), 10)
        } else if (android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 11)
        }

        Executors.newSingleThreadExecutor().execute {
            try {
                colors = ColorDb.load()
                runOnUiThread { status.text = "Databáze: ${colors.size} barev • připraveno" }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Databáze barev se nepodařila načíst" }
            }
        }

        val manager = getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
        scanner = manager.adapter.bluetoothLeScanner

        scan.setOnClickListener {
            ble?.close()
            stopScan()
            startScan()
        }
        measure.setOnClickListener {
            if (ble?.triggerMeasurement() == true) status.text = "Příkaz odeslán • čekám na měření…"
            else status.text = "LS170 není připravený — nejdřív ho připoj"
        }
        database.setOnClickListener { showColorDatabase() }
        savedColorsButton.setOnClickListener { showSavedColors() }
        cardsButton.setOnClickListener { showCards() }
        settingsButton.setOnClickListener { showUiSettings() }

        applyUiSettings()
    }

    private fun uiColor(prefix: String, default: Int): Int {
        val r = uiPrefs.getInt("${prefix}_r", Color.red(default))
        val g = uiPrefs.getInt("${prefix}_g", Color.green(default))
        val b = uiPrefs.getInt("${prefix}_b", Color.blue(default))
        val a = uiPrefs.getInt("${prefix}_a", Color.alpha(default))
        return Color.argb(a, r, g, b)
    }

    private fun applyUiSettings() {
        if (!::menuButtonRef.isInitialized) return
        val menuSize = uiPrefs.getInt("menu_size", 58).coerceIn(44, 100)
        val rgbSize = uiPrefs.getInt("rgb_size", 62).coerceIn(44, 100)
        val menuColor = uiColor("menu", 0x66000000)
        val rgbColor = uiColor("rgb", 0x66000000)
        menuButtonRef.background = aeroBackground(menuColor, dp(menuSize / 2))
        rgbButtonRef.background = aeroBackground(rgbColor, dp(rgbSize / 2))
        menuPanelRef.background = aeroBackground(uiColor("menu_panel", 0xD0181818.toInt()), dp(24))
        val buttonColor = uiColor("menu_button", 0xA02D73B7.toInt())
        menuButtons.forEach { it.background = aeroBackground(buttonColor, dp(18)) }
        (menuButtonRef.layoutParams as? FrameLayout.LayoutParams)?.let { lp ->
            lp.width = dp(menuSize); lp.height = dp(menuSize); menuButtonRef.layoutParams = lp
        }
        (rgbButtonRef.layoutParams as? FrameLayout.LayoutParams)?.let { lp ->
            lp.width = dp(rgbSize); lp.height = dp(rgbSize); rgbButtonRef.layoutParams = lp
        }
    }

    private fun showUiSettings() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(4), dp(10), dp(8))
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(root, ViewGroup.LayoutParams(-1, -1))
        }

        fun put(prefix: String, key: String, value: Int) {
            uiPrefs.edit().putInt("${prefix}_$key", value).apply()
        }
        fun color(prefix: String, def: Int) = uiColor(prefix, def)
        fun setColor(prefix: String, c: Int) = uiPrefs.edit()
            .putInt("${prefix}_r", Color.red(c)).putInt("${prefix}_g", Color.green(c))
            .putInt("${prefix}_b", Color.blue(c)).putInt("${prefix}_a", Color.alpha(c)).apply()

        fun previewFor(target: String?) {
            when (target) {
                "menu_panel", "menu_button" -> {
                    menuPanelRef.visibility = View.VISIBLE
                    menuPanelRef.bringToFront()
                }
                "rgb_panel" -> {
                    rgbPanelRef.visibility = View.VISIBLE
                    rgbPanelRef.bringToFront()
                }
                "popup", "popup_button" -> showStylePreviewPopup()
            }
        }

        // One compact, expandable setting. The slider is hidden until the user opens it.
        fun setting(
            label: String,
            min: Int,
            max: Int,
            initial: Int,
            resetValue: Int,
            reset: () -> Unit,
            change: (Int) -> Unit,
            preview: String? = null
        ): LinearLayout {
            val outer = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(4), dp(1), dp(4), dp(1))
            }
            val head = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = aeroBackground(0x18000000, dp(12))
                setPadding(dp(8), 0, dp(4), 0)
            }
            val arrow = TextView(this).apply {
                text = "›"
                textSize = 18f
                setTextColor(Color.BLACK)
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(dp(22), dp(36))
            }
            val title = TextView(this).apply {
                text = label
                textSize = 13f
                setTextColor(Color.BLACK)
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, dp(36), 1f)
            }
            var seek: SeekBar? = null
            val resetButton = Button(this).apply {
                text = "↶"
                textSize = 12f
                minWidth = 0
                minimumWidth = 0
                setPadding(0, 0, 0, 0)
                layoutParams = LinearLayout.LayoutParams(dp(32), dp(30))
                setOnClickListener {
                    reset()
                    seek?.progress = (resetValue - min).coerceIn(0, max - min)
                    applyUiSettings()
                }
            }
            head.addView(arrow)
            head.addView(title)
            head.addView(resetButton)

            val sliderBox = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                visibility = View.GONE
                setPadding(dp(4), 0, dp(4), dp(2))
            }
            seek = SeekBar(this).apply {
                this.max = max - min
                progress = (initial.coerceIn(min, max) - min)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                        if (fromUser) change(p + min)
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) {
                        startLivePreview(label, preview, outer, s)
                    }
                    override fun onStopTrackingTouch(s: SeekBar?) {
                        stopLivePreview()
                    }
                })
            }
            sliderBox.addView(seek, LinearLayout.LayoutParams(-1, dp(42)))
            outer.addView(head)
            outer.addView(sliderBox)

            head.setOnClickListener {
                val open = sliderBox.visibility != View.VISIBLE
                sliderBox.visibility = if (open) View.VISIBLE else View.GONE
                arrow.text = if (open) "⌄" else "›"
            }
            return outer
        }

        fun section(titleText: String): Pair<LinearLayout, LinearLayout> {
            val holder = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, dp(4), 0, dp(4))
            }
            val head = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = aeroBackground(0x25000000, dp(16))
                setPadding(dp(10), 0, dp(6), 0)
            }
            val arrow = TextView(this).apply {
                text = "›"
                textSize = 21f
                setTextColor(Color.BLACK)
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(dp(28), dp(42))
            }
            head.addView(arrow)
            head.addView(TextView(this).apply {
                text = titleText
                textSize = 15f
                setTextColor(Color.BLACK)
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f)
            })
            val content = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                visibility = View.GONE
                setPadding(dp(4), dp(2), dp(4), 0)
            }
            holder.addView(head)
            holder.addView(content)
            head.setOnClickListener {
                val open = content.visibility != View.VISIBLE
                content.visibility = if (open) View.VISIBLE else View.GONE
                arrow.text = if (open) "⌄" else "›"
            }
            return holder to content
        }

        lateinit var settingToImpl: (LinearLayout, String, Int, Int, Int, Int, () -> Unit, (Int) -> Unit, String?) -> Unit

        fun addColor(content: LinearLayout, prefix: String, title: String, def: Int, preview: String) {
            val current = color(prefix, def)
            settingToImpl(content, "$title – PRŮHLEDNOST", 10, 100,
                Color.alpha(current) * 100 / 255, Color.alpha(def) * 100 / 255,
                { setColor(prefix, def) }, { v ->
                    val c = Color.argb(v * 255 / 100, Color.red(color(prefix, def)), Color.green(color(prefix, def)), Color.blue(color(prefix, def)))
                    setColor(prefix, c); applyUiSettings(); previewFor(preview)
                }, preview)
            settingToImpl(content, "$title – ČERVENÁ", 0, 255, Color.red(current), Color.red(def),
                { setColor(prefix, def) }, { v ->
                    val c0 = color(prefix, def)
                    setColor(prefix, Color.argb(Color.alpha(c0), v, Color.green(c0), Color.blue(c0))); applyUiSettings(); previewFor(preview)
                }, preview)
            settingToImpl(content, "$title – ZELENÁ", 0, 255, Color.green(current), Color.green(def),
                { setColor(prefix, def) }, { v ->
                    val c0 = color(prefix, def)
                    setColor(prefix, Color.argb(Color.alpha(c0), Color.red(c0), v, Color.blue(c0))); applyUiSettings(); previewFor(preview)
                }, preview)
            settingToImpl(content, "$title – MODRÁ", 0, 255, Color.blue(current), Color.blue(def),
                { setColor(prefix, def) }, { v ->
                    val c0 = color(prefix, def)
                    setColor(prefix, Color.argb(Color.alpha(c0), Color.red(c0), Color.green(c0), v)); applyUiSettings(); previewFor(preview)
                }, preview)
        }

        // Helper kept outside addColor so every setting can live in a category content panel.
        fun addSetting(content: LinearLayout, view: LinearLayout) {
            content.addView(view, LinearLayout.LayoutParams(-1, -2))
        }

        settingToImpl = { content, label, min, max, initial, resetValue, reset, change, preview ->
            addSetting(content, setting(label, min, max, initial, resetValue, reset, change, preview))
        }

        // Top level: NASTAVENÍ → VZHLED → individual categories → individual sliders.
        val (appearanceHolder, appearance) = section("VZHLED")
        root.addView(appearanceHolder)

        fun addSize(content: LinearLayout, label: String, prefix: String, default: Int, preview: String) {
            addSetting(content, setting(label, 44, 100, uiPrefs.getInt("${prefix}_size", default), default,
                { put(prefix, "size", default); applyUiSettings() },
                { put(prefix, "size", it); applyUiSettings() }, preview))
        }

        val (menuHolder, menuContent) = section("MENU")
        appearance.addView(menuHolder)
        addSize(menuContent, "VELIKOST IKONY MENU", "menu", 58, "menu")
        addColor(menuContent, "menu", "MENU IKONA", 0x66000000, "menu")

        val (menuPanelHolder, menuPanelContent) = section("VYSOUVACÍ MENU")
        appearance.addView(menuPanelHolder)
        addColor(menuPanelContent, "menu_panel", "VYSOUVACÍ MENU", 0xD0181818.toInt(), "menu_panel")

        val (menuButtonHolder, menuButtonContent) = section("TLAČÍTKA MENU")
        appearance.addView(menuButtonHolder)
        addColor(menuButtonContent, "menu_button", "TLAČÍTKA MENU", 0xA02D73B7.toInt(), "menu_button")

        val (rgbHolder, rgbContent) = section("RGB")
        appearance.addView(rgbHolder)
        addSize(rgbContent, "VELIKOST IKONY RGB", "rgb", 62, "rgb")
        addColor(rgbContent, "rgb", "RGB IKONA", 0x66000000, "rgb")

        val (rgbPanelHolder, rgbPanelContent) = section("RGB VYSOUVACÍ OKNO")
        appearance.addView(rgbPanelHolder)
        addColor(rgbPanelContent, "rgb_panel", "RGB VYSOUVACÍ OKNO", 0xD0181818.toInt(), "rgb_panel")

        val (popupHolder, popupContent) = section("OSTATNÍ VYSOUVACÍ OKNA")
        appearance.addView(popupHolder)
        addColor(popupContent, "popup", "OSTATNÍ VYSOUVACÍ OKNA", 0xD0A6A6A6.toInt(), "popup")

        val (popupButtonHolder, popupButtonContent) = section("TLAČÍTKA V OKNECH")
        appearance.addView(popupButtonHolder)
        addColor(popupButtonContent, "popup_button", "TLAČÍTKA V OKNECH", 0xBFE0E0E0.toInt(), "popup_button")

        previewScroll = scroll
        previewBox = root
        val dialog = AlertDialog.Builder(this)
            .setTitle("NASTAVENÍ")
            .setView(scroll)
            .setPositiveButton("HOTOVO", null)
            .create()
        settingsDialog = dialog
        dialog.setOnDismissListener {
            stopLivePreview()
            settingsDialog = null
        }
        dialog.show()
        stylePopup(dialog)
        dialog.window?.setLayout(-1, (resources.displayMetrics.heightPixels * 0.82f).toInt())
    }

    private fun startLivePreview(label: String, target: String?, activeRow: View, seek: SeekBar?) {
        val dialog = settingsDialog ?: return
        previewActiveRow = activeRow
        previewHiddenRows.clear()

        // Hide everything except the actual slider and its required parent chain.
        // This keeps the live preview clean even with nested expandable sections.
        previewBox?.let { box ->
            fun isAncestorOf(view: View, child: View): Boolean {
                var p = child.parent
                while (p is View) {
                    if (p === view) return true
                    p = p.parent
                }
                return false
            }
            fun hideTree(parent: ViewGroup) {
                for (i in 0 until parent.childCount) {
                    val child = parent.getChildAt(i)
                    if (child === seek || isAncestorOf(child, seek ?: activeRow)) {
                        if (child is ViewGroup) hideTree(child)
                    } else {
                        if (child.visibility != View.GONE) {
                            previewHiddenRows.add(child)
                            child.visibility = View.GONE
                        }
                    }
                }
            }
            hideTree(box)
            activeRow.visibility = View.VISIBLE
            seek?.visibility = View.VISIBLE
        }

        dialog.window?.setDimAmount(0f)
        dialog.window?.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.visibility = View.GONE
        previewForLiveTarget(target)
        seek?.post {
            val y = (seek.parent as? View)?.top ?: activeRow.top
            previewScroll?.scrollTo(0, (y - dp(80)).coerceAtLeast(0))
        }
    }

    private fun stopLivePreview() {
        previewHiddenRows.forEach { it.visibility = View.VISIBLE }
        previewHiddenRows.clear()
        previewActiveRow = null
        previewPopup?.let { mainRootRef.removeView(it) }
        previewPopup = null
        settingsDialog?.let { dialog ->
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.visibility = View.VISIBLE
            dialog.window?.setBackgroundDrawable(
                aeroBackground(uiColor("popup", 0xD0A6A6A6.toInt()), dp(24))
            )
            dialog.window?.setDimAmount(0.10f)
            stylePopup(dialog)
        }
    }

    private fun previewForLiveTarget(target: String?) {
        when (target) {
            "menu_panel", "menu_button" -> menuPanelRef.visibility = View.VISIBLE
            "rgb_panel" -> rgbPanelRef.visibility = View.VISIBLE
            "popup", "popup_button" -> showStylePreviewPopup()
        }
    }

    private fun showStylePreviewPopup() {
        if (previewPopup != null) return
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(14))
            background = aeroBackground(uiColor("popup", 0xD0A6A6A6.toInt()), dp(24))
            elevation = dp(18).toFloat()
        }
        box.addView(TextView(this).apply {
            text = "NÁHLED VYSOUVACÍHO OKNA"
            textSize = 17f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
        })
        box.addView(TextView(this).apply {
            text = "Tady vidíš změny barvy a průhlednosti v reálném čase."
            setTextColor(Color.BLACK)
            setPadding(0, dp(10), 0, dp(10))
        })
        box.addView(Button(this).apply {
            text = "UKÁZKOVÉ TLAČÍTKO"
            setTextColor(Color.BLACK)
            background = aeroBackground(uiColor("popup_button", 0xBFE0E0E0.toInt()), dp(18))
        }, LinearLayout.LayoutParams(-1, dp(42)))
        val lp = FrameLayout.LayoutParams(dp(330), -2).apply {
            gravity = Gravity.CENTER
        }
        mainRootRef.addView(box, lp)
        previewPopup = box
    }

    private fun stylePopupIfOpen() { }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun aeroBackground(color: Int, radius: Int): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
            setStroke(dp(1), 0x33FFFFFF)
        }

    private fun makeAeroButton(label: String): Button = Button(this).apply {
        text = label.uppercase(Locale.getDefault())
        textSize = 13f
        setTextColor(Color.WHITE)
        isAllCaps = false
        background = aeroBackground(0xA02D73B7.toInt(), dp(18))
        stateListAnimator = null
        elevation = dp(2).toFloat()
        setPadding(dp(8), 0, dp(8), 0)
    }

    private data class CardCell(var r: Int = 0, var g: Int = 0, var b: Int = 0, var name: String = "", var filled: Boolean = false)
    private data class CardRow(var date: String = "", val cells: MutableList<CardCell> = MutableList(5) { CardCell() })
    private data class ColorCard(var id: String, val rows: MutableList<CardRow> = mutableListOf(CardRow(), CardRow()))

    private fun loadCards(): MutableList<ColorCard> {
        val result = mutableListOf<ColorCard>()
        val raw = cardsPrefs.getString("cards_json", "[]") ?: "[]"
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val card = ColorCard(o.optString("id"))
                val rows = o.optJSONArray("rows") ?: JSONArray()
                for (ri in 0 until 2) {
                    val row = CardRow()
                    if (ri < rows.length()) {
                        val ro = rows.getJSONObject(ri)
                        row.date = ro.optString("date")
                        val cells = ro.optJSONArray("cells") ?: JSONArray()
                        for (ci in 0 until minOf(5, cells.length())) {
                            val co = cells.getJSONObject(ci)
                            row.cells[ci] = CardCell(
                                co.optInt("r", 0), co.optInt("g", 0), co.optInt("b", 0),
                                co.optString("name"), co.optBoolean("filled", false)
                            )
                        }
                    }
                    card.rows[ri] = row
                }
                if (card.id.isNotBlank()) result.add(card)
            }
        } catch (_: Exception) {}
        return result
    }

    private fun saveCards(cards: List<ColorCard>) {
        val arr = JSONArray()
        cards.forEach { card ->
            val o = JSONObject().put("id", card.id)
            val rows = JSONArray()
            card.rows.take(2).forEach { row ->
                val ro = JSONObject().put("date", row.date)
                val cells = JSONArray()
                row.cells.take(5).forEach { c ->
                    cells.put(JSONObject()
                        .put("r", c.r).put("g", c.g).put("b", c.b)
                        .put("name", c.name).put("filled", c.filled))
                }
                ro.put("cells", cells)
                rows.put(ro)
            }
            o.put("rows", rows)
            arr.put(o)
        }
        cardsPrefs.edit().putString("cards_json", arr.toString()).apply()
    }

    private fun todayString(): String =
        java.text.SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(java.util.Date())

    private fun firstEmptyCell(row: CardRow): Int = row.cells.indexOfFirst { !it.filled }

    private fun findCard(cards: List<ColorCard>, id: String): ColorCard? =
        cards.firstOrNull { it.id.equals(id.trim(), ignoreCase = true) }

    private fun recordMeasurementToActiveCard(r: Int, g: Int, b: Int, name: String?) {
        val id = activeCardId ?: return
        val cards = loadCards()
        val card = findCard(cards, id) ?: return
        var rowIndex = firstEmptyCell(card.rows[0]).let { if (it >= 0) 0 else 1 }
        val row = card.rows[rowIndex]
        val slot = firstEmptyCell(row)
        if (slot < 0) {
            if (rowIndex == 0 && firstEmptyCell(card.rows[1]) >= 0) {
                rowIndex = 1
            } else {
                runOnUiThread { status.text = "Karta $id má už všech 10 měření vyplněných" }
                return
            }
        }
        val targetRow = card.rows[rowIndex]
        val targetSlot = firstEmptyCell(targetRow)
        if (targetRow.date.isBlank()) targetRow.date = todayString()
        val bestName = name ?: nearestColor(r, g, b)?.let(::displayName) ?: ""
        targetRow.cells[targetSlot] = CardCell(r, g, b, bestName, true)
        saveCards(cards)
        runOnUiThread { status.text = "Karta $id • ${rowIndex + 1}. řádek • místo ${targetSlot + 1} uloženo" }
    }

    private fun stylePopup(dialog: AlertDialog) {
        dialog.window?.setBackgroundDrawable(aeroBackground(uiColor("popup", 0xD0A6A6A6.toInt()), dp(24)))
        dialog.window?.setDimAmount(0.10f)

        fun styleView(v: View) {
            when (v) {
                is Button -> {
                    v.setTextColor(Color.BLACK)
                    v.background = aeroBackground(uiColor("popup_button", 0xBFE0E0E0.toInt()), dp(18))
                    v.stateListAnimator = null
                }
                is EditText -> {
                    v.setTextColor(Color.BLACK)
                    v.setHintTextColor(0x99000000.toInt())
                }
                is TextView -> v.setTextColor(Color.BLACK)
            }
            if (v is ViewGroup) {
                for (i in 0 until v.childCount) styleView(v.getChildAt(i))
            }
        }

        dialog.window?.decorView?.let { styleView(it) }
        listOf(
            AlertDialog.BUTTON_POSITIVE,
            AlertDialog.BUTTON_NEGATIVE,
            AlertDialog.BUTTON_NEUTRAL
        ).forEach { which ->
            dialog.getButton(which)?.apply {
                setTextColor(Color.BLACK)
                background = aeroBackground(uiColor("popup_button", 0xBFE0E0E0.toInt()), dp(18))
                stateListAnimator = null
            }
        }
    }

    private fun showCards() {
        val dialog = AlertDialog.Builder(this).create()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(8))
        }
        root.addView(TextView(this).apply {
            text = "KARTY"
            textSize = 22f
            setPadding(0, 0, 0, dp(8))
        })

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val idInput = EditText(this).apply {
            hint = "ID karty"
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT
        }
        val newButton = Button(this).apply { text = "NOVÁ KARTA" }
        val exportButton = Button(this).apply { text = "EXPORT" }
        top.addView(idInput, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(newButton, LinearLayout.LayoutParams(dp(118), -2))
        top.addView(exportButton, LinearLayout.LayoutParams(dp(105), -2))
        root.addView(top)

        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        fun refresh() {
            list.removeAllViews()
            val cards = loadCards()
            if (cards.isEmpty()) {
                list.addView(TextView(this).apply {
                    text = "Zatím není vytvořená žádná karta."
                    textSize = 16f
                    setPadding(dp(4), dp(18), dp(4), dp(18))
                })
            }
            cards.forEach { card -> addCardView(list, card, dialog) }
        }

        newButton.setOnClickListener {
            val id = idInput.text.toString().trim()
            if (id.isBlank()) {
                idInput.error = "Zadej ID karty"
                return@setOnClickListener
            }
            val cards = loadCards()
            if (findCard(cards, id) != null) {
                idInput.error = "Toto ID už existuje"
                return@setOnClickListener
            }
            cards.add(ColorCard(id))
            saveCards(cards)
            activeCardId = id
            idInput.text.clear()
            refresh()
        }

        exportButton.setOnClickListener { exportCardsFiles() }

        cardsListContainer = list
        cardsDialogRef = dialog
        dialog.setView(root)
        dialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Zavřít") { _, _ -> dialog.dismiss() }
        dialog.setOnDismissListener {
            activeCardId = null
            status.text = "Připraveno"
            cardsDialogRef = null
            cardsListContainer = null
        }
        dialog.show()
        stylePopup(dialog)
        dialog.window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.98).toInt(),
            (resources.displayMetrics.heightPixels * 0.90).toInt()
        )
        refresh()
    }

    private fun refreshCardsDialog() {
        val list = cardsListContainer ?: return
        val dialog = cardsDialogRef ?: return
        list.removeAllViews()
        val cards = loadCards()
        if (cards.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "Zatím není vytvořená žádná karta."
                textSize = 16f
                setPadding(dp(4), dp(18), dp(4), dp(18))
            })
        } else {
            cards.forEach { card -> addCardView(list, card, dialog) }
        }
    }

    private fun addCardView(list: LinearLayout, card: ColorCard, dialog: AlertDialog) {
        val cardBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(5), dp(5), dp(5), dp(8))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
            setBackgroundColor(0x22000000)
        }
        val arrow = TextView(this).apply {
            text = "▶"
            textSize = 15f
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(dp(20), -2)
        }
        val idText = TextView(this).apply {
            text = card.id
            textSize = 17f
            setTypeface(null, android.graphics.Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        val exportOne = Button(this).apply {
            text = "TXT"
            setOnClickListener { exportCardTxt(card) }
        }
        header.addView(arrow)
        header.addView(idText)
        header.addView(exportOne, LinearLayout.LayoutParams(dp(44), -2))
        cardBox.addView(header)

        val details = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = if (activeCardId.equals(card.id, true)) View.VISIBLE else View.GONE
            setPadding(dp(3), dp(3), dp(3), dp(3))
        }

        val edit = Button(this).apply {
            text = "EDITOVAT KARTU"
            setOnClickListener { editCardManually(card, dialog) }
        }
        details.addView(edit, LinearLayout.LayoutParams(-1, dp(34)))

        for (ri in 0..1) {
            val row = card.rows[ri]
            val dateLine = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val date = TextView(this).apply {
                text = if (row.date.isBlank()) "${ri + 1}. měření – datum zatím není" else row.date
                textSize = 14f
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            }
            val dateEdit = Button(this).apply {
                text = "DATUM"
                setOnClickListener { editRowDate(card, ri, dialog) }
            }
            dateLine.addView(date)
            dateLine.addView(dateEdit, LinearLayout.LayoutParams(dp(62), dp(32)))
            details.addView(dateLine)

            val cells = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                weightSum = 5f
            }
            for (ci in 0..4) {
                val c = row.cells[ci]
                val cell = TextView(this).apply {
                    gravity = Gravity.CENTER
                    textSize = 10f
                    setPadding(dp(2), dp(5), dp(2), dp(5))
                    text = if (c.filled)
                        "${ci + 1}\nRGB\n${c.r},${c.g},${c.b}\n${c.name}"
                    else "${ci + 1}\nprázdné"
                    setBackgroundColor(if (c.filled) Color.rgb(c.r, c.g, c.b) else 0x22000000)
                    val bright = if (c.filled) (c.r * 299 + c.g * 587 + c.b * 114) / 1000 else 255
                    setTextColor(if (bright < 140) Color.WHITE else Color.BLACK)
                    setOnClickListener { editCardCell(card, ri, ci, dialog) }
                }
                cells.addView(cell, LinearLayout.LayoutParams(0, dp(68), 1f).apply {
                    setMargins(dp(2), dp(2), dp(2), dp(2))
                })
            }
            details.addView(cells)
        }

        val del = Button(this).apply {
            text = "SMAZAT KARTU"
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Smazat kartu?")
                    .setMessage("Karta ${card.id} a všech jejích 10 měření budou odstraněny.")
                    .setNegativeButton("Zrušit", null)
                    .setPositiveButton("SMAZAT") { _, _ ->
                        val cards = loadCards()
                        cards.removeAll { it.id.equals(card.id, true) }
                        saveCards(cards)
                        if (activeCardId.equals(card.id, true)) activeCardId = null
                        dialog.dismiss()
                        showCards()
                    }.show().also { stylePopup(it) }
            }
        }
        details.addView(del, LinearLayout.LayoutParams(-1, dp(34)))
        cardBox.addView(details)

        header.setOnClickListener {
            val open = details.visibility != View.VISIBLE
            details.visibility = if (open) View.VISIBLE else View.GONE
            arrow.text = if (open) "▼" else "▶"
            if (open) {
                activeCardId = card.id
                status.text = "Aktivní karta: ${card.id}"
            } else if (activeCardId.equals(card.id, true)) {
                activeCardId = null
            }
        }

        list.addView(cardBox)
        list.addView(View(this).apply { setBackgroundColor(0x55000000) },
            LinearLayout.LayoutParams(-1, dp(1)))
    }

    private fun exportCardTxt(card: ColorCard) {
        val sb = StringBuilder()
        sb.append("MCBP – KARTA\n")
        sb.append("ID: ${card.id}\n\n")
        card.rows.forEachIndexed { ri, row ->
            sb.append("${ri + 1}. MĚŘENÍ")
            if (row.date.isNotBlank()) sb.append(" – ${row.date}")
            sb.append("\n")
            row.cells.forEachIndexed { ci, c ->
                sb.append("Místo ${ci + 1}: ")
                if (c.filled) {
                    sb.append("RGB ${c.r},${c.g},${c.b}")
                    sb.append(" | HEX #%02X%02X%02X".format(c.r, c.g, c.b))
                    sb.append(" | ${c.name}")
                } else sb.append("prázdné")
                sb.append("\n")
            }
            sb.append("\n")
        }
        saveTextToMcbpFolder("MCBP_${safeFilePart(card.id)}.txt", sb.toString())
    }

    private fun exportCardsFiles() {
        val cards = loadCards()
        if (cards.isEmpty()) {
            Toast.makeText(this, "NENÍ CO EXPORTOVAT", Toast.LENGTH_SHORT).show()
            return
        }
        val txt = StringBuilder()
        val csv = StringBuilder()
        csv.append("KARTA;ŘÁDEK;DATUM;MÍSTO;R;G;B;HEX;NÁZEV\n")
        cards.forEachIndexed { i, card ->
            if (i > 0) txt.append("\n==============================\n\n")
            txt.append("MCBP – KARTA\nID: ${card.id}\n\n")
            card.rows.forEachIndexed { ri, row ->
                txt.append("${ri + 1}. MĚŘENÍ")
                if (row.date.isNotBlank()) txt.append(" – ${row.date}")
                txt.append("\n")
                row.cells.forEachIndexed { ci, c ->
                    txt.append("Místo ${ci + 1}: ")
                    if (c.filled) {
                        txt.append("RGB ${c.r},${c.g},${c.b}")
                        txt.append(" | HEX #%02X%02X%02X".format(c.r, c.g, c.b))
                        txt.append(" | ${c.name}")
                        csv.append(csvField(card.id)).append(';')
                            .append(ri + 1).append(';')
                            .append(csvField(row.date)).append(';')
                            .append(ci + 1).append(';')
                            .append(c.r).append(';').append(c.g).append(';').append(c.b).append(';')
                            .append("#%02X%02X%02X".format(c.r, c.g, c.b)).append(';')
                            .append(csvField(c.name)).append('\n')
                    } else txt.append("prázdné")
                    txt.append("\n")
                }
                txt.append("\n")
            }
        }
        val txtOk = saveTextToMcbpFolder("MCBP_KARTY.txt", txt.toString())
        val csvOk = saveTextToMcbpFolder("MCBP_KARTY.csv", csv.toString(), "text/csv")
        if (txtOk && csvOk) {
            Toast.makeText(this, "ULOŽENO DO /storage/emulated/0/MCBP", Toast.LENGTH_LONG).show()
        }
    }

    private fun csvField(value: String): String = "\"${value.replace("\"", "\"\"")}\""

    private fun safeFilePart(value: String): String = value.replace(Regex("[^A-Za-z0-9._-]"), "_").take(60)

    private fun saveTextToMcbpFolder(fileName: String, text: String, mime: String = "text/plain"): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val resolver = contentResolver
                val collection = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                val relativePath = "MCBP/"
                resolver.query(
                    collection,
                    arrayOf(MediaStore.MediaColumns._ID),
                    "${MediaStore.MediaColumns.DISPLAY_NAME}=? AND ${MediaStore.MediaColumns.RELATIVE_PATH}=?",
                    arrayOf(fileName, relativePath),
                    null
                )?.use { c ->
                    while (c.moveToNext()) {
                        val id = c.getLong(0)
                        resolver.delete(android.content.ContentUris.withAppendedId(collection, id), null, null)
                    }
                }
                val values = android.content.ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, mime)
                    put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath)
                }
                val uri = resolver.insert(collection, values) ?: return false
                val wrote = resolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)); true } ?: false
                if (!wrote) {
                    resolver.delete(uri, null, null)
                    return false
                }
            } else {
                val dir = java.io.File(android.os.Environment.getExternalStorageDirectory(), "MCBP")
                if (!dir.exists() && !dir.mkdirs()) return false
                java.io.File(dir, fileName).writeText(text, Charsets.UTF_8)
            }
            true
        } catch (e: Exception) {
            Toast.makeText(this, "EXPORT SELHAL: ${e.message}", Toast.LENGTH_LONG).show()
            false
        }
    }

    private fun editRowDate(card: ColorCard, rowIndex: Int, dialog: AlertDialog) {
        val input = EditText(this).apply {
            setSingleLine(true)
            hint = "dd.MM.yyyy"
            setText(card.rows[rowIndex].date)
            inputType = InputType.TYPE_CLASS_TEXT
        }
        AlertDialog.Builder(this)
            .setTitle("Datum ${rowIndex + 1}. měření")
            .setView(input)
            .setNegativeButton("Zrušit", null)
            .setPositiveButton("ULOŽIT") { _, _ ->
                card.rows[rowIndex].date = input.text.toString().trim()
                val cards = loadCards()
                findCard(cards, card.id)?.rows?.set(rowIndex, card.rows[rowIndex])
                saveCards(cards)
                refreshCardsDialog()
            }.show().also { stylePopup(it) }
    }

    private fun editCardCell(card: ColorCard, rowIndex: Int, cellIndex: Int, dialog: AlertDialog) {
        val c = card.rows[rowIndex].cells[cellIndex]
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, dp(12), 0)
        }
        fun field(hint: String, value: String): EditText = EditText(this).apply {
            this.hint = hint; setSingleLine(true); setText(value)
        }
        val rIn = field("R 0–255", if (c.filled) c.r.toString() else "")
        val gIn = field("G 0–255", if (c.filled) c.g.toString() else "")
        val bIn = field("B 0–255", if (c.filled) c.b.toString() else "")
        val nIn = field("Název barvy", c.name)
        rIn.inputType = InputType.TYPE_CLASS_NUMBER
        gIn.inputType = InputType.TYPE_CLASS_NUMBER
        bIn.inputType = InputType.TYPE_CLASS_NUMBER
        box.addView(rIn); box.addView(gIn); box.addView(bIn); box.addView(nIn)
        AlertDialog.Builder(this)
            .setTitle("${rowIndex + 1}. řádek • místo ${cellIndex + 1}")
            .setView(box)
            .setNegativeButton("Zrušit", null)
            .setNeutralButton("VYMAZAT") { _, _ ->
                val cards = loadCards()
                val found = findCard(cards, card.id) ?: return@setNeutralButton
                found.rows[rowIndex].cells[cellIndex] = CardCell()
                saveCards(cards)
                refreshCardsDialog()
            }
            .setPositiveButton("ULOŽIT") { _, _ ->
                val rr = rIn.text.toString().toIntOrNull()?.coerceIn(0,255)
                val gg = gIn.text.toString().toIntOrNull()?.coerceIn(0,255)
                val bb = bIn.text.toString().toIntOrNull()?.coerceIn(0,255)
                if (rr == null || gg == null || bb == null) return@setPositiveButton
                val cards = loadCards()
                val found = findCard(cards, card.id) ?: return@setPositiveButton
                found.rows[rowIndex].cells[cellIndex] = CardCell(rr, gg, bb, nIn.text.toString().trim(), true)
                if (found.rows[rowIndex].date.isBlank()) found.rows[rowIndex].date = todayString()
                saveCards(cards)
                refreshCardsDialog()
            }.show().also { stylePopup(it) }
    }

    private fun editCardManually(card: ColorCard, dialog: AlertDialog) {
        // The card editor exposes ID and both measurement dates; individual cells are
        // editable from the card itself, including RGB and name.
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, dp(12), 0)
        }
        val idIn = EditText(this).apply {
            setSingleLine(true); setText(card.id); hint = "ID karty"
        }
        val d1 = EditText(this).apply {
            setSingleLine(true); setText(card.rows[0].date); hint = "Datum 1. měření"
        }
        val d2 = EditText(this).apply {
            setSingleLine(true); setText(card.rows[1].date); hint = "Datum 2. měření"
        }
        box.addView(idIn); box.addView(d1); box.addView(d2)
        AlertDialog.Builder(this)
            .setTitle("Upravit kartu")
            .setView(box)
            .setNegativeButton("Zrušit", null)
            .setPositiveButton("ULOŽIT") { _, _ ->
                val newId = idIn.text.toString().trim()
                if (newId.isBlank()) return@setPositiveButton
                val cards = loadCards()
                val found = findCard(cards, card.id) ?: return@setPositiveButton
                val clash = cards.any { it.id.equals(newId, true) && !it.id.equals(card.id, true) }
                if (clash) return@setPositiveButton
                found.id = newId
                found.rows[0].date = d1.text.toString().trim()
                found.rows[1].date = d2.text.toString().trim()
                if (activeCardId.equals(card.id, true)) activeCardId = newId
                saveCards(cards)
                refreshCardsDialog()
            }.show().also { stylePopup(it) }
    }

    private fun showColorDatabase() {
        if (colors.isEmpty()) {
            Toast.makeText(this, "Databáze barev ještě není načtená", Toast.LENGTH_SHORT).show()
            return
        }

        val dialog = AlertDialog.Builder(this).create()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(10))
        }
        box.addView(TextView(this).apply {
            text = "Databáze barev"
            textSize = 22f
            setPadding(0, 0, 0, dp(10))
        })

        val search = EditText(this).apply {
            hint = "RGB 255,0,0 / #FF0000 / název"
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
        }
        box.addView(search)

        val listView = ListView(this).apply {
            dividerHeight = dp(1)
            setPadding(0, dp(4), 0, 0)
        }
        box.addView(listView, LinearLayout.LayoutParams(-1, 0, 1f))
        dialog.setView(box)
        dialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Zavřít") { _, _ -> dialog.dismiss() }

        // Cache the displayed names once. The old implementation created ~2400 View
        // objects every time the database opened or the search text changed.
        // ListView recycles rows, so only the visible rows are actually created.
        val all = colors.map { it to displayName(it) }
            .sortedBy { it.second.lowercase(Locale.getDefault()) }

        val adapter = DatabaseAdapter(dialog, all)
        listView.adapter = adapter

        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                adapter.filter(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: android.text.Editable?) = Unit
        })

        dialog.show()
        stylePopup(dialog)
        dialog.window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.94).toInt(),
            (resources.displayMetrics.heightPixels * 0.88).toInt()
        )
    }

    private inner class DatabaseAdapter(
        private val dialog: AlertDialog,
        private val all: List<Pair<NamedColor, String>>
    ) : BaseAdapter() {
        private var shown = all

        override fun getCount(): Int = shown.size
        override fun getItem(position: Int): Pair<NamedColor, String> = shown[position]
        override fun getItemId(position: Int): Long = position.toLong()

        fun filter(queryRaw: String) {
            val q = queryRaw.trim().lowercase(Locale.getDefault())
            shown = if (q.isEmpty()) {
                all
            } else {
                val qCompact = q.replace(" ", "")
                val qHex = q.removePrefix("#")
                all.filter { (c, name) ->
                    val nameLower = name.lowercase(Locale.getDefault())
                    val rgb = "${c.r},${c.g},${c.b}"
                    val rgbSpaced = "${c.r} ${c.g} ${c.b}"
                    val hex = "%02x%02x%02x".format(c.r, c.g, c.b)
                    nameLower.contains(q) || rgb.contains(qCompact) ||
                        rgbSpaced.contains(q) || hex.contains(qHex)
                }
            }
            notifyDataSetChanged()
        }

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val row = (convertView as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(4), 0, dp(4))
            }

            val info = if (row.childCount > 0) row.getChildAt(0) as TextView else TextView(this@MainActivity).apply {
                textSize = 15f
                setTextColor(Color.BLACK)
                setPadding(dp(4), dp(4), dp(4), dp(4))
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            }
            val save = if (row.childCount > 1) row.getChildAt(1) as Button else Button(this@MainActivity).apply {
                layoutParams = LinearLayout.LayoutParams(dp(92), -2)
            }
            val rename = if (row.childCount > 2) row.getChildAt(2) as Button else Button(this@MainActivity).apply {
                layoutParams = LinearLayout.LayoutParams(dp(82), -2)
                text = "NÁZEV"
            }

            if (row.childCount == 0) {
                row.addView(info)
                row.addView(save)
                row.addView(rename)
            }

            val (c, name) = shown[position]
            info.text = "$name\nRGB ${c.r}, ${c.g}, ${c.b}   #%02X%02X%02X".format(c.r, c.g, c.b)
            save.text = if (isSaved(c)) "ULOŽENO" else "ULOŽIT"
            save.setOnClickListener {
                val now = !isSaved(c)
                setSaved(c, now)
                save.text = if (now) "ULOŽENO" else "ULOŽIT"
                Toast.makeText(
                    this@MainActivity,
                    if (now) "Barva uložena" else "Barva odebrána",
                    Toast.LENGTH_SHORT
                ).show()
            }
            rename.setOnClickListener { editColorName(c, dialog) }
            info.setOnClickListener {
                showColorOnMainScreen(c)
                dialog.dismiss()
                status.text = "Vybraná barva: ${displayName(c)}"
            }
            return row
        }
    }

    private fun editColorName(c: NamedColor, databaseDialog: AlertDialog) {
        val input = EditText(this).apply {
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setText(displayName(c))
            selectAll()
        }
        AlertDialog.Builder(this)
            .setTitle("Název barvy")
            .setView(input)
            .setNegativeButton("Zrušit", null)
            .setPositiveButton("ULOŽIT") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    prefs.edit().putString("name_${colorKey(c)}", name).apply()
                    databaseDialog.dismiss()
                    showColorDatabase()
                    Toast.makeText(this, "Název uložen: $name", Toast.LENGTH_SHORT).show()
                }
            }
            .show().also { stylePopup(it) }
    }

    private fun showSavedColors() {
        val saved = colors.filter(::isSaved).sortedBy { displayName(it).lowercase(Locale.getDefault()) }
        val dialog = AlertDialog.Builder(this).create()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(10))
        }
        box.addView(TextView(this).apply {
            text = "ULOŽENÉ BARVY"
            textSize = 22f
            setPadding(0, 0, 0, dp(10))
        })
        if (saved.isEmpty()) {
            box.addView(TextView(this).apply {
                text = "Zatím nemáš uloženou žádnou barvu."
                textSize = 17f
                setPadding(0, dp(12), 0, dp(12))
            })
        } else {
            val scroll = ScrollView(this)
            val listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            saved.forEach { c ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, dp(5), 0, dp(5))
                }
                val info = TextView(this).apply {
                    text = "${displayName(c)}\nRGB ${c.r}, ${c.g}, ${c.b}   #%02X%02X%02X".format(c.r, c.g, c.b)
                    textSize = 15f
                    setTextColor(Color.BLACK)
                    layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                    setOnClickListener {
                        showColorOnMainScreen(c)
                        dialog.dismiss()
                        status.text = "Vybraná uložená barva: ${displayName(c)}"
                    }
                }
                val remove = Button(this).apply {
                    text = "SMAZAT"
                    setOnClickListener {
                        setSaved(c, false)
                        dialog.dismiss()
                        showSavedColors()
                    }
                }
                row.addView(info)
                row.addView(remove, LinearLayout.LayoutParams(dp(90), -2))
                listBox.addView(row)
            }
            scroll.addView(listBox)
            box.addView(scroll, LinearLayout.LayoutParams(-1, dp(480)))
        }
        dialog.setView(box)
        dialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Zavřít") { _, _ -> dialog.dismiss() }
        dialog.show()
        stylePopup(dialog)
        dialog.window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.94).toInt(),
            (resources.displayMetrics.heightPixels * 0.82).toInt()
        )
    }

    private fun showColorOnMainScreen(c: NamedColor) {
        updateDisplayedColor(c.r, c.g, c.b, displayName(c), false)
    }

    private fun nearestColor(r: Int, g: Int, b: Int): NamedColor? {
        if (colors.isEmpty()) return null
        val lab = ColorMath.rgbToLab(r, g, b)
        return colors.minByOrNull { ColorMath.deltaE00(lab, it.lab) }
    }

    private fun updateDisplayedColor(r: Int, g: Int, b: Int, name: String?, resetNavigation: Boolean = true) {
        val rr = r.coerceIn(0, 255)
        val gg = g.coerceIn(0, 255)
        val bb = b.coerceIn(0, 255)
        updatingSliders = true
        redSeek.progress = rr
        greenSeek.progress = gg
        blueSeek.progress = bb
        updatingSliders = false
        result.setBackgroundColor(Color.rgb(rr, gg, bb))
        val brightness = (rr * 299 + gg * 587 + bb * 114) / 1000
        result.setTextColor(if (brightness < 140) Color.WHITE else Color.BLACK)
        rgbValues.text = "RGB $rr, $gg, $bb"
        result.text = if (name != null) "$name\nRGB $rr, $gg, $bb" else "RGB $rr, $gg, $bb"
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, r: ScanResult) {
            val name = try { r.device.name } catch (_: SecurityException) { null }
            if (name.isNullOrBlank() || !name.contains("LS170", true)) return
            stopScan(); ble?.close()
            ble = Ls170Ble(this@MainActivity, { rr, gg, bb ->
                val lab = ColorMath.rgbToLab(rr, gg, bb)
                val best = colors.minByOrNull { ColorMath.deltaE00(lab, it.lab) }
                runOnUiThread {
                    updateDisplayedColor(rr, gg, bb, best?.let(::displayName))
                    status.text = if (best != null) "Měření přijato • ΔE00 %.2f".format(ColorMath.deltaE00(lab, best.lab)) else "Měření přijato"
                    if (activeCardId != null) {
                        recordMeasurementToActiveCard(rr, gg, bb, best?.let(::displayName))
                    }
                }
            }, { s -> runOnUiThread { status.text = s } })
            ble?.connect(r.device)
        }
        override fun onScanFailed(errorCode: Int) {
            scanning = false
            runOnUiThread { status.text = "Skenování selhalo: $errorCode" }
        }
    }

    private fun startScan() {
        if (android.os.Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
            status.text = "Povol Bluetooth skenování a zkus znovu"; return
        }
        if (scanning) return
        scanning = true; status.text = "Hledám LS170…"; scanner.startScan(scanCallback)
    }

    private fun stopScan() {
        if (!scanning) return
        if (android.os.Build.VERSION.SDK_INT < 31 || checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED) scanner.stopScan(scanCallback)
        scanning = false
    }

    override fun onDestroy() {
        stopScan()
        ble?.close()
        super.onDestroy()
    }
}
