package cz.ls170.colormatcher

import android.Manifest
import android.app.*
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.le.*
import android.content.*
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.*
import java.util.concurrent.Executors
import kotlin.math.*

class MainActivity:Activity(){
    private lateinit var status:TextView
    private lateinit var result:TextView
    private lateinit var scan:Button
    private lateinit var measure:Button
    private var ble:Ls170Ble?=null
    private var colors:List<NamedColor> = emptyList()
    private var scanning=false
    private var scanCallback: ScanCallback?=null

    override fun onCreate(b:Bundle?){
        super.onCreate(b)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;padding=24}
        status=TextView(this).apply{text="Načítám databázi…";textSize=18f}
        result=TextView(this).apply{textSize=28f;padding=16}
        scan=Button(this).apply{text="Hledat LS170"}
        measure=Button(this).apply{text="MĚŘIT";isEnabled=false}
        box.addView(status); box.addView(result); box.addView(scan); box.addView(measure)
        setContentView(box)

        requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT),10)
        Executors.newSingleThreadExecutor().execute{
            try{ colors=ColorDb.load(); runOnUiThread{status.text="Databáze: ${colors.size} barev — připraveno"} }
            catch(e:Exception){runOnUiThread{status.text="Databázi se nepodařilo načíst: ${e.message}"}}
        }
        val mgr=getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
        val adapter=mgr.adapter
        val scanner=adapter.bluetoothLeScanner
        val cb=object:ScanCallback(){
            override fun onScanResult(t:Int,r:ScanResult){
                val n=r.device.name ?: return
                if(n.contains("LS170",true) || n.contains("LS",true)){
                    stop(scanner, this)
                    ble=Ls170Ble(this@MainActivity,{rr,gg,bb->
                        val lab=ColorMath.rgbToLab(rr,gg,bb)
                        val best=colors.minByOrNull{ColorMath.deltaE00(lab,it.lab)}
                        if(best!=null) runOnUiThread{
                            result.text="${best.name}\nRGB $rr,$gg,$bb\n#%02X%02X%02X".format(rr,gg,bb)
                            status.text="Nejbližší: ΔE00 %.2f".format(ColorMath.deltaE00(lab,best.lab))
                        }
                    },{s->runOnUiThread{status.text=s}})
                    ble!!.connect(r.device)
                    measure.isEnabled=true
                }
            }
        }
        scan.setOnClickListener{start(scanner,cb)}
        scanCallback=cb
        measure.setOnClickListener{ble?.measure()}
    }
    private fun start(s:BluetoothLeScanner,cb:ScanCallback){
        if(checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)!=PackageManager.PERMISSION_GRANTED)return
        if(scanning)return
        s.startScan(cb); scanning=true; status.text="Hledám LS170…"
    }
    private fun stop(s:BluetoothLeScanner,cb:ScanCallback){
        if(checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)==PackageManager.PERMISSION_GRANTED)s.stopScan(cb)
        scanning=false
    }
}
