# LS170 Color Matcher

První pracovní Android verze pro LS170.

- BLE služby/charakteristiky jsou převzaté z LSColor.
- Měřicí příkaz: `AB 44 00 00 00 00 36 00 18 64`
- RGB se čte z bytů 36..38 odpovědi.
- Název se hledá přes CIEDE2000.
- Databáze je 2398 barev z `color-names` JSON a stáhne se při prvním spuštění.

Poznámka: přesná hodnota `distanceMax` z původního Color Pickeru ještě není vložená jako limit; aplikace zatím vždy zobrazí nejbližší barvu. To je záměrně použitelné už teď, než dokončíme 1:1 reprodukci prahu.

Build:
`./gradlew assembleDebug`


## Stav
Aktuální build je záměrně bez falešného `distanceMax`: nejbližší barvu podle ΔE00 ukazuje vždy. Přesný práh z původní aplikace je stále předmětem reverzní analýzy; jakmile ho potvrdíme, bude možné zapnout 1:1 chování.
