package cz.ls170.colormatcher

import kotlin.math.*

data class Lab(val l: Double, val a: Double, val b: Double)

object ColorMath {
    fun rgbToLab(r0:Int,g0:Int,b0:Int): Lab {
        fun f(v:Int):Double {
            val x=v/255.0
            return if (x <= 0.04045) x/12.92 else ((x+0.055)/1.055).pow(2.4)
        }
        val r=f(r0); val g=f(g0); val b=f(b0)
        val x=(r*0.4124+g*0.3576+b*0.1805)/0.95047
        val y=(r*0.2126+g*0.7152+b*0.0722)/1.00000
        val z=(r*0.0193+g*0.1192+b*0.9505)/1.08883
        fun q(v:Double)=if(v>0.008856) v.pow(1.0/3.0) else 7.787*v+16.0/116.0
        val fx=q(x); val fy=q(y); val fz=q(z)
        return Lab(116*fy-16, 500*(fx-fy), 200*(fy-fz))
    }

    // CIEDE2000, K_L=K_C=K_H=1.
    fun deltaE00(x:Lab,y:Lab):Double {
        val c1=hypot(x.a,x.b); val c2=hypot(y.a,y.b); val cm=(c1+c2)/2
        val g=0.5*(1-sqrt(cm.pow(7)/(cm.pow(7)+25.0.pow(7))))
        val ap1=(1+g)*x.a; val ap2=(1+g)*y.a
        val cp1=hypot(ap1,x.b); val cp2=hypot(ap2,y.b)
        fun hp(a:Double,b:Double):Double {
            if (a==0.0 && b==0.0) return 0.0
            var h=Math.toDegrees(atan2(b,a)); if(h<0) h+=360; return h
        }
        val h1=hp(ap1,x.b); val h2=hp(ap2,y.b)
        val dl=y.l-x.l; val dc=cp2-cp1
        val dhRaw=h2-h1
        val dh=when {
            cp1*cp2==0.0 -> 0.0
            abs(dhRaw)<=180 -> dhRaw
            dhRaw>180 -> dhRaw-360
            else -> dhRaw+360
        }
        val dH=2*sqrt(cp1*cp2)*sin(Math.toRadians(dh/2))
        val lm=(x.l+y.l)/2; val cpm=(cp1+cp2)/2
        val hm=when {
            cp1*cp2==0.0 -> h1+h2
            abs(h1-h2)<=180 -> (h1+h2)/2
            h1+h2<360 -> (h1+h2+360)/2
            else -> (h1+h2-360)/2
        }
        val t=1 - 0.17*cos(Math.toRadians(hm-30)) + 0.24*cos(Math.toRadians(2*hm)) +
                0.32*cos(Math.toRadians(3*hm+6)) - 0.20*cos(Math.toRadians(4*hm-63))
        val dTheta=30*exp(-((hm-275)/25).pow(2))
        val rc=2*sqrt(cpm.pow(7)/(cpm.pow(7)+25.0.pow(7)))
        val sl=1+0.015*(lm-50).pow(2)/sqrt(20+(lm-50).pow(2))
        val sc=1+0.045*cpm
        val sh=1+0.015*cpm*t
        val rt=-sin(Math.toRadians(2*dTheta))*rc
        val l=dl/sl; val c=dc/sc; val h=dH/sh
        return sqrt(l*l+c*c+h*h+rt*c*h)
    }
}
