plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "cz.ls170.colormatcher"
    compileSdk = 35
    defaultConfig {
        applicationId = "cz.ls170.colormatcher"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1"
    }
}
