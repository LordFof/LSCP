package cz.ls170.colormatcher

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothManager
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var result: TextView
    private lateinit var scan: Button
    private lateinit var measure: Button
    private lateinit var database: Button
    private lateinit var savedColors: Button
    private lateinit var redSeek: SeekBar
    private lateinit var greenSeek: SeekBar
    private lateinit var blueSeek: SeekBar
    private lateinit var rgbValues: TextView
    private var updatingSliders = false
    private var ble: Ls170Ble? = null
    private var colors: List<NamedColor> = emptyList()
    private val savedPrefs by lazy { getSharedPreferences("saved_colors", MODE_PRIVATE) }
    private var scanning = false
    private lateinit var scanner: BluetoothLeScanner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this).apply { setBackgroundColor(Color.DKGRAY) }
        result = TextView(this).apply {
            text = "Zatím žádné měření"
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.DKGRAY)
            setPadding(24, 120, 24, 220)
        }
        root.addView(result, FrameLayout.LayoutParams(-1, -1))

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(0x66000000)
        }
        status = TextView(this).apply {
            text = "Načítám…"
            textSize = 18f
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, 18)
        }
        scan = Button(this).apply { text = "Hledat LS170" }
        measure = Button(this).apply { text = "Měřit (dálkově)" }
        database = Button(this).apply { text = "Databáze barev" }
        savedColors = Button(this).apply { text = "ULOŽENÉ BARVY" }
        controls.addView(status)
        controls.addView(scan)
        controls.addView(measure)
        controls.addView(database)
        controls.addView(savedColors)

        rgbValues = TextView(this).apply {
            text = "RGB 128, 128, 128   #808080"
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(0, 12, 0, 2)
        }
        controls.addView(rgbValues)

        fun addSlider(label: String, initial: Int): SeekBar {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val tv = TextView(this).apply {
                text = label
                textSize = 16f
                setTextColor(Color.WHITE)
                minWidth = 34
            }
            val sb = SeekBar(this).apply {
                max = 255
                progress = initial
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            row.addView(tv)
            row.addView(sb)
            controls.addView(row)
            return sb
        }
        redSeek = addSlider("R", 128)
        greenSeek = addSlider("G", 128)
        blueSeek = addSlider("B", 128)

        val sliderListener = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!updatingSliders && fromUser) {
                    val rr = redSeek.progress
                    val gg = greenSeek.progress
                    val bb = blueSeek.progress
                    val nearest = nearestColor(rr, gg, bb)
                    updateDisplayedColor(rr, gg, bb, nearest?.name)
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        }
        redSeek.setOnSeekBarChangeListener(sliderListener)
        greenSeek.setOnSeekBarChangeListener(sliderListener)
        blueSeek.setOnSeekBarChangeListener(sliderListener)
        root.addView(controls, FrameLayout.LayoutParams(-1, -2).apply { gravity = Gravity.TOP })

        val credit = TextView(this).apply {
            text = "Created by LordFof"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(12, 6, 12, 6)
            setBackgroundColor(0x66000000)
        }
        root.addView(credit, FrameLayout.LayoutParams(-2, -2).apply {
            gravity = Gravity.BOTTOM or Gravity.END
            setMargins(0, 0, 12, 12)
        })
        setContentView(root)

        if (android.os.Build.VERSION.SDK_INT >= 31) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT), 10)
        }

        Executors.newSingleThreadExecutor().execute {
            try {
                colors = ColorDb.load(this)
                runOnUiThread { status.text = "Databáze: ${colors.size} barev • připraveno" }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Databáze barev se nepodařila načíst" }
            }
        }

        val manager = getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
        scanner = manager.adapter.bluetoothLeScanner

        scan.setOnClickListener {
            ble?.close()
            stopScan()
            startScan()
        }
        measure.setOnClickListener {
            if (ble?.triggerMeasurement() == true) status.text = "Příkaz odeslán • čekám na měření…"
            else status.text = "LS170 není připravený — nejdřív ho připoj"
        }
        database.setOnClickListener { showColorDatabase() }
        savedColors.setOnClickListener { showSavedColors() }
    }

    private fun colorKey(c: NamedColor) = "%02X%02X%02X".format(c.r,c.g,c.b)

    private fun isSaved(c: NamedColor) = savedPrefs.getBoolean(colorKey(c), false)

    private fun toggleSaved(c: NamedColor) {
        savedPrefs.edit().putBoolean(colorKey(c), !isSaved(c)).apply()
    }

    private fun editColorName(c: NamedColor, onDone: () -> Unit) {
        val input = EditText(this).apply {
            setSingleLine(true)
            setText(c.name)
            selectAll()
        }
        AlertDialog.Builder(this)
            .setTitle("Upravit název barvy")
            .setView(input)
            .setNegativeButton("Zrušit", null)
            .setPositiveButton("ULOŽIT") { _, _ ->
                val name=input.text.toString().trim()
                if (name.isNotEmpty()) {
                    ColorDb.saveCustomName(this, c, name)
                    colors = colors.map { if (colorKey(it)==colorKey(c)) it.copy(name=name) else it }
                    onDone()
                }
            }.show()
    }

    private fun showColorDatabase() {
        if (colors.isEmpty()) { Toast.makeText(this, "Databáze barev ještě není načtená", Toast.LENGTH_SHORT).show(); return }
        showColorListDialog("Databáze barev", colors, false)
    }

    private fun showSavedColors() {
        val saved=colors.filter(::isSaved)
        if (saved.isEmpty()) { Toast.makeText(this, "Zatím nemáš uložené žádné barvy", Toast.LENGTH_SHORT).show(); return }
        showColorListDialog("Uložené barvy", saved, true)
    }

    private fun showColorListDialog(dialogTitle: String, source: List<NamedColor>, savedOnly: Boolean) {
        val dialog=AlertDialog.Builder(this).create()
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(18,12,18,8) }
        val title=TextView(this).apply { text=dialogTitle; textSize=22f; setPadding(0,0,0,10) }
        val search=EditText(this).apply { hint="RGB / #HEX / název"; inputType=InputType.TYPE_CLASS_TEXT; setSingleLine(true) }
        val list=ListView(this)
        box.addView(title); if (!savedOnly) box.addView(search); box.addView(list,LinearLayout.LayoutParams(-1,0,1f))
        dialog.setView(box)
        dialog.setButton(AlertDialog.BUTTON_NEGATIVE,"Zavřít") { _,_->dialog.dismiss() }

        var shown=source.sortedBy { it.name.lowercase(Locale.getDefault()) }
        val adapter=object: BaseAdapter() {
            override fun getCount()=shown.size
            override fun getItem(position:Int)=shown[position]
            override fun getItemId(position:Int)=position.toLong()
            override fun getView(position:Int, convertView:android.view.View?, parent:ViewGroup):android.view.View {
                val c=getItem(position)
                val row=LinearLayout(this@MainActivity).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(6,6,6,6) }
                val swatch=TextView(this@MainActivity).apply { setBackgroundColor(Color.rgb(c.r,c.g,c.b)); layoutParams=LinearLayout.LayoutParams(46,46).apply{setMargins(0,0,10,0)} }
                val info=TextView(this@MainActivity).apply { text="${c.name}\nRGB ${c.r}, ${c.g}, ${c.b}   #%02X%02X%02X".format(c.r,c.g,c.b,c.r,c.g,c.b); textSize=14f; layoutParams=LinearLayout.LayoutParams(0,-2,1f) }
                val edit=Button(this@MainActivity).apply { text="NÁZEV"; setOnClickListener { editColorName(c) { shown = shown.map { if (colorKey(it)==colorKey(c)) colors.first { cc -> colorKey(cc)==colorKey(c) } else it }; list.adapter.notifyDataSetChanged() } } }
                val save=Button(this@MainActivity).apply { text=if(isSaved(c)) "ULOŽENO" else "ULOŽIT"; setOnClickListener { toggleSaved(c); text=if(isSaved(c)) "ULOŽENO" else "ULOŽIT"; if(savedOnly && !isSaved(c)){ shown=shown.filter{colorKey(it)!=colorKey(c)}; list.adapter.notifyDataSetChanged() } } }
                row.addView(swatch); row.addView(info); row.addView(edit); row.addView(save); return row
            }
        }
        list.adapter=adapter
        list.setOnItemClickListener { _,_,position,_-> showColorOnMainScreen(shown[position]); status.text="Vybraná barva: ${shown[position].name}"; dialog.dismiss() }
        search.addTextChangedListener(object:android.text.TextWatcher{
            override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int)=Unit
            override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){
                val q=s?.toString()?.trim()?.lowercase(Locale.getDefault()).orEmpty()
                shown=if(q.isEmpty()) source.sortedBy{it.name.lowercase(Locale.getDefault())} else source.filter{c-> val rgb="${c.r},${c.g},${c.b}"; val spaced="${c.r} ${c.g} ${c.b}"; val hex="%02x%02x%02x".format(c.r,c.g,c.b); c.name.lowercase(Locale.getDefault()).contains(q)||rgb.contains(q.replace(" ",""))||spaced.contains(q)||hex.contains(q.removePrefix("#"))}
                adapter.notifyDataSetChanged()
            }
            override fun afterTextChanged(s:android.text.Editable?)=Unit
        })
        dialog.show(); dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.98).toInt(),(resources.displayMetrics.heightPixels*0.9).toInt())
    }

    private fun showColorOnMainScreen(c: NamedColor) {
        updateDisplayedColor(c.r, c.g, c.b, c.name)
    }

    // Uses exactly the same CIEDE2000 nearest-color logic as a real measurement.
    // This is intentionally recalculated on every slider step so the displayed
    // name follows the currently selected RGB value immediately.
    private fun nearestColor(r: Int, g: Int, b: Int): NamedColor? {
        if (colors.isEmpty()) return null
        val lab = ColorMath.rgbToLab(r, g, b)
        return colors.minByOrNull { ColorMath.deltaE00(lab, it.lab) }
    }

    private fun updateDisplayedColor(r: Int, g: Int, b: Int, name: String?) {
        val rr = r.coerceIn(0, 255)
        val gg = g.coerceIn(0, 255)
        val bb = b.coerceIn(0, 255)
        updatingSliders = true
        redSeek.progress = rr
        greenSeek.progress = gg
        blueSeek.progress = bb
        updatingSliders = false

        result.setBackgroundColor(Color.rgb(rr, gg, bb))
        val brightness = (rr * 299 + gg * 587 + bb * 114) / 1000
        result.setTextColor(if (brightness < 140) Color.WHITE else Color.BLACK)
        val hex = "#%02X%02X%02X".format(rr, gg, bb)
        rgbValues.text = "RGB $rr, $gg, $bb   $hex"
        result.text = if (name != null) "$name\nRGB $rr, $gg, $bb\n$hex"
        else "RGB $rr, $gg, $bb\n$hex"
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, r: ScanResult) {
            val name = try { r.device.name } catch (_: SecurityException) { null }
            if (name.isNullOrBlank() || !name.contains("LS170", true)) return
            stopScan(); ble?.close()
            ble = Ls170Ble(this@MainActivity, { rr, gg, bb ->
                val lab = ColorMath.rgbToLab(rr, gg, bb)
                val best = colors.minByOrNull { ColorMath.deltaE00(lab, it.lab) }
                runOnUiThread {
                    updateDisplayedColor(rr, gg, bb, best?.name)
                    status.text = if (best != null) "Měření přijato • ΔE00 %.2f".format(ColorMath.deltaE00(lab, best.lab)) else "Měření přijato"
                }
            }, { s -> runOnUiThread { status.text = s } })
            ble?.connect(r.device)
        }
        override fun onScanFailed(errorCode: Int) { scanning = false; runOnUiThread { status.text = "Skenování selhalo: $errorCode" } }
    }

    private fun startScan() {
        if (android.os.Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
            status.text = "Povol Bluetooth skenování a zkus znovu"; return
        }
        if (scanning) return
        scanning = true; status.text = "Hledám LS170…"; scanner.startScan(scanCallback)
    }
    private fun stopScan() {
        if (!scanning) return
        if (android.os.Build.VERSION.SDK_INT < 31 || checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED) scanner.stopScan(scanCallback)
        scanning = false
    }
    override fun onDestroy() { stopScan(); ble?.close(); super.onDestroy() }
}
