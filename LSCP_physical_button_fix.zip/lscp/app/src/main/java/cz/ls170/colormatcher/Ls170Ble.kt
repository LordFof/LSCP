package cz.ls170.colormatcher

import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothProfile
import android.content.Context
import java.util.UUID

class Ls170Ble(
    private val context: Context,
    private val onRgb: (Int, Int, Int, String) -> Unit,
    private val onState: (String) -> Unit
) {
    companion object {
        private val SERVICE_NOTIFY = UUID.fromString("0000FFE0-0000-1000-8000-00805F9B34FB")
        private val CHAR_NOTIFY = UUID.fromString("0000FFE4-0000-1000-8000-00805F9B34FB")
        private val SERVICE_WRITE = UUID.fromString("0000FFE5-0000-1000-8000-00805F9B34FB")
        private val CHAR_WRITE = UUID.fromString("0000FFE9-0000-1000-8000-00805F9B34FB")
        private val CCCD = UUID.fromString("00002902-0000-1000-8000-00805F9B34FB")
    }

    private var gatt: BluetoothGatt? = null
    private var notifyChar: BluetoothGattCharacteristic? = null
    private var deviceName = "LS170"
    private var ready = false
    private val packet = ArrayList<Byte>()

    private val callback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED && status == BluetoothGatt.GATT_SUCCESS) {
                gatt = g
                ready = false
                onState("PŘIPOJENO: $deviceName — zjišťuji služby…")
                g.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                ready = false
                notifyChar = null
                packet.clear()
                if (gatt === g) gatt = null
                g.close()
                onState("ODPOJENO: $deviceName — stiskni Hledat LS170")
            } else if (status != BluetoothGatt.GATT_SUCCESS) {
                ready = false
                onState("BLE chyba: $status")
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                ready = false
                onState("Chyba při zjišťování služeb: $status")
                g.close(); gatt = null
                return
            }

            val n = g.getService(SERVICE_NOTIFY)?.getCharacteristic(CHAR_NOTIFY)
            val w = g.getService(SERVICE_WRITE)?.getCharacteristic(CHAR_WRITE)
            if (n == null || w == null) {
                ready = false
                onState("LS170 připojeno, ale nenašel jsem FFE4/FFE9")
                g.close(); gatt = null
                return
            }

            notifyChar = n
            if (!g.setCharacteristicNotification(n, true)) {
                ready = false
                onState("Nepodařilo se zapnout BLE notifikace")
                return
            }

            val d = n.getDescriptor(CCCD)
            if (d == null) {
                ready = true
                onState("PŘIPRAVENO: stiskni tlačítko na LS170")
                return
            }
            d.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            if (!g.writeDescriptor(d)) {
                ready = false
                onState("Nepodařilo se zapnout BLE notifikace")
            } else {
                onState("PŘIPOJENO: čekám na měření z tlačítka LS170…")
            }
        }

        override fun onDescriptorWrite(g: BluetoothGatt, descriptor: BluetoothGattDescriptor, status: Int) {
            if (descriptor.uuid == CCCD) {
                ready = status == BluetoothGatt.GATT_SUCCESS
                onState(if (ready) "PŘIPRAVENO: stiskni tlačítko na LS170" else "Notifikace LS170 selhaly: $status")
            }
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            if (characteristic.uuid != CHAR_NOTIFY) return
            val data = characteristic.value ?: return
            if (data.isEmpty()) return

            packet.addAll(data.toList())
            // LS170 response contains RGB at zero-based bytes 36..38.
            // Keep a rolling buffer so fragmented BLE notifications are handled too.
            if (packet.size > 128) packet.subList(0, packet.size - 64).clear()
            if (packet.size >= 39) {
                val start = packet.size - 39
                val r = packet[start + 36].toInt() and 0xFF
                val gr = packet[start + 37].toInt() and 0xFF
                val b = packet[start + 38].toInt() and 0xFF
                val hex = packet.subList(start, start + 39).joinToString("") { "%02X".format(it.toInt() and 0xFF) }
                packet.clear()
                if (ready) onRgb(r, gr, b, hex)
            }
        }
    }

    fun connect(device: BluetoothDevice) {
        close(false)
        deviceName = device.name?.takeIf { it.isNotBlank() } ?: "LS170"
        onState("PŘIPOJUJI: $deviceName…")
        gatt = device.connectGatt(context, false, callback)
    }

    fun close() = close(true)

    private fun close(showState: Boolean) {
        ready = false
        notifyChar = null
        packet.clear()
        gatt?.disconnect()
        gatt?.close()
        gatt = null
        if (showState) onState("Odpojeno")
    }
}
