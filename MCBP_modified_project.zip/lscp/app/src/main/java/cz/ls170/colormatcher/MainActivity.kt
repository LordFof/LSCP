package cz.ls170.colormatcher

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothManager
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var result: TextView
    private lateinit var scan: Button
    private lateinit var measure: Button
    private lateinit var database: Button
    private lateinit var savedColorsButton: Button
    private lateinit var cardsButton: Button
    private lateinit var redSeek: SeekBar
    private lateinit var greenSeek: SeekBar
    private lateinit var blueSeek: SeekBar
    private lateinit var prevColorButton: TextView
    private lateinit var nextColorButton: TextView
    private var navigationColors: List<NamedColor> = emptyList()
    private var navigationIndex = -1
    private lateinit var rgbValues: TextView
    private var updatingSliders = false
    private var ble: Ls170Ble? = null
    private var colors: List<NamedColor> = emptyList()
    private var scanning = false
    private lateinit var scanner: BluetoothLeScanner
    private val prefs by lazy { getSharedPreferences("mcbp_colors", Context.MODE_PRIVATE) }
    private val cardsPrefs by lazy { getSharedPreferences("mcbp_cards", Context.MODE_PRIVATE) }
    private var activeCardId: String? = null

    private fun colorKey(c: NamedColor) = "%d,%d,%d".format(c.r, c.g, c.b)
    private fun displayName(c: NamedColor): String =
        prefs.getString("name_${colorKey(c)}", null)?.takeIf { it.isNotBlank() } ?: c.name

    private fun isSaved(c: NamedColor): Boolean = prefs.getBoolean("saved_${colorKey(c)}", false)

    private fun setSaved(c: NamedColor, saved: Boolean) {
        prefs.edit().putBoolean("saved_${colorKey(c)}", saved).apply()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this).apply { setBackgroundColor(Color.DKGRAY) }
        result = TextView(this).apply {
            text = "Zatím žádné měření"
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.DKGRAY)
            setPadding(24, 120, 24, 220)
        }
        root.addView(result, FrameLayout.LayoutParams(-1, -1))

        prevColorButton = makeNavigationButton("‹\n")
        nextColorButton = makeNavigationButton("›\n")
        root.addView(prevColorButton, FrameLayout.LayoutParams(dp(150), dp(90)).apply {
            gravity = Gravity.CENTER_VERTICAL or Gravity.START
            setMargins(dp(6), 0, 0, 0)
        })
        root.addView(nextColorButton, FrameLayout.LayoutParams(dp(150), dp(90)).apply {
            gravity = Gravity.CENTER_VERTICAL or Gravity.END
            setMargins(0, 0, dp(6), 0)
        })

        prevColorButton.setOnClickListener { showNavigationColor(-1) }
        nextColorButton.setOnClickListener { showNavigationColor(1) }

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(0x66000000)
        }
        status = TextView(this).apply {
            text = "Načítám…"
            textSize = 18f
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, 12)
        }
        scan = Button(this).apply { text = "Hledat LS170" }
        measure = Button(this).apply { text = "Měřit (dálkově)" }
        database = Button(this).apply { text = "Databáze barev" }
        savedColorsButton = Button(this).apply { text = "ULOŽENÉ BARVY" }
        cardsButton = Button(this).apply { text = "KARTY" }
        controls.addView(status)
        controls.addView(scan)
        controls.addView(measure)
        controls.addView(database)
        controls.addView(savedColorsButton)
        controls.addView(cardsButton)

        rgbValues = TextView(this).apply {
            text = "RGB 128, 128, 128   #808080"
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(0, 12, 0, 2)
        }
        controls.addView(rgbValues)

        fun addSlider(label: String, initial: Int): SeekBar {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val tv = TextView(this).apply {
                text = label
                textSize = 16f
                setTextColor(Color.WHITE)
                minWidth = 34
            }
            val sb = SeekBar(this).apply {
                max = 255
                progress = initial
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            row.addView(tv)
            row.addView(sb)
            controls.addView(row)
            return sb
        }
        redSeek = addSlider("R", 128)
        greenSeek = addSlider("G", 128)
        blueSeek = addSlider("B", 128)

        val sliderListener = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!updatingSliders && fromUser) {
                    val rr = redSeek.progress
                    val gg = greenSeek.progress
                    val bb = blueSeek.progress
                    val nearest = nearestColor(rr, gg, bb)
                    updateDisplayedColor(rr, gg, bb, nearest?.let(::displayName))
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        }
        redSeek.setOnSeekBarChangeListener(sliderListener)
        greenSeek.setOnSeekBarChangeListener(sliderListener)
        blueSeek.setOnSeekBarChangeListener(sliderListener)
        root.addView(controls, FrameLayout.LayoutParams(-1, -2).apply { gravity = Gravity.TOP })

        val credit = TextView(this).apply {
            text = "Created by LordFof"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(12, 6, 12, 6)
            setBackgroundColor(0x66000000)
        }
        root.addView(credit, FrameLayout.LayoutParams(-2, -2).apply {
            gravity = Gravity.BOTTOM or Gravity.END
            setMargins(0, 0, 12, 12)
        })
        setContentView(root)

        if (android.os.Build.VERSION.SDK_INT >= 31) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT), 10)
        }

        Executors.newSingleThreadExecutor().execute {
            try {
                colors = ColorDb.load()
                runOnUiThread { status.text = "Databáze: ${colors.size} barev • připraveno" }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Databáze barev se nepodařila načíst" }
            }
        }

        val manager = getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
        scanner = manager.adapter.bluetoothLeScanner

        scan.setOnClickListener {
            ble?.close()
            stopScan()
            startScan()
        }
        measure.setOnClickListener {
            if (ble?.triggerMeasurement() == true) status.text = "Příkaz odeslán • čekám na měření…"
            else status.text = "LS170 není připravený — nejdřív ho připoj"
        }
        database.setOnClickListener { showColorDatabase() }
        savedColorsButton.setOnClickListener { showSavedColors() }
        cardsButton.setOnClickListener { showCards() }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun makeNavigationButton(arrow: String): TextView = TextView(this).apply {
        text = arrow
        textSize = 15f
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        setBackgroundColor(0x66000000)
        visibility = View.GONE
        maxLines = 2
    }

    private fun prepareNavigation(r: Int, g: Int, b: Int) {
        if (colors.isEmpty()) {
            navigationColors = emptyList()
            navigationIndex = -1
            updateNavigationButtons()
            return
        }
        val lab = ColorMath.rgbToLab(r, g, b)
        navigationColors = colors.sortedBy { ColorMath.deltaE00(lab, it.lab) }
        navigationIndex = 0
        updateNavigationButtons()
    }

    private fun prepareNavigationForDatabaseColor(c: NamedColor) {
        if (colors.isEmpty()) return
        val lab = c.lab
        navigationColors = colors.sortedBy { ColorMath.deltaE00(lab, it.lab) }
        navigationIndex = navigationColors.indexOfFirst { it.r == c.r && it.g == c.g && it.b == c.b }
        if (navigationIndex < 0) navigationIndex = 0
        updateNavigationButtons()
    }

    private fun updateNavigationButtons() {
        if (navigationColors.size < 2 || navigationIndex < 0) {
            prevColorButton.visibility = View.GONE
            nextColorButton.visibility = View.GONE
            return
        }
        prevColorButton.visibility = if (navigationIndex > 0) View.VISIBLE else View.GONE
        nextColorButton.visibility = if (navigationIndex < navigationColors.lastIndex) View.VISIBLE else View.GONE
        if (navigationIndex > 0) {
            prevColorButton.text = "‹\n${displayName(navigationColors[navigationIndex - 1])}"
        }
        if (navigationIndex < navigationColors.lastIndex) {
            nextColorButton.text = "${displayName(navigationColors[navigationIndex + 1])}\n›"
        }
    }

    private fun showNavigationColor(step: Int) {
        val newIndex = navigationIndex + step
        if (newIndex !in navigationColors.indices) return
        navigationIndex = newIndex
        val c = navigationColors[navigationIndex]
        updateDisplayedColor(c.r, c.g, c.b, displayName(c), false)
        status.text = "Vybraná barva: ${displayName(c)}"
        updateNavigationButtons()
    }


    private data class CardCell(var r: Int = 0, var g: Int = 0, var b: Int = 0, var name: String = "", var filled: Boolean = false)
    private data class CardRow(var date: String = "", val cells: MutableList<CardCell> = MutableList(5) { CardCell() })
    private data class ColorCard(var id: String, val rows: MutableList<CardRow> = mutableListOf(CardRow(), CardRow()))

    private fun loadCards(): MutableList<ColorCard> {
        val result = mutableListOf<ColorCard>()
        val raw = cardsPrefs.getString("cards_json", "[]") ?: "[]"
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val card = ColorCard(o.optString("id"))
                val rows = o.optJSONArray("rows") ?: JSONArray()
                for (ri in 0 until 2) {
                    val row = CardRow()
                    if (ri < rows.length()) {
                        val ro = rows.getJSONObject(ri)
                        row.date = ro.optString("date")
                        val cells = ro.optJSONArray("cells") ?: JSONArray()
                        for (ci in 0 until minOf(5, cells.length())) {
                            val co = cells.getJSONObject(ci)
                            row.cells[ci] = CardCell(
                                co.optInt("r", 0), co.optInt("g", 0), co.optInt("b", 0),
                                co.optString("name"), co.optBoolean("filled", false)
                            )
                        }
                    }
                    card.rows[ri] = row
                }
                if (card.id.isNotBlank()) result.add(card)
            }
        } catch (_: Exception) {}
        return result
    }

    private fun saveCards(cards: List<ColorCard>) {
        val arr = JSONArray()
        cards.forEach { card ->
            val o = JSONObject().put("id", card.id)
            val rows = JSONArray()
            card.rows.take(2).forEach { row ->
                val ro = JSONObject().put("date", row.date)
                val cells = JSONArray()
                row.cells.take(5).forEach { c ->
                    cells.put(JSONObject()
                        .put("r", c.r).put("g", c.g).put("b", c.b)
                        .put("name", c.name).put("filled", c.filled))
                }
                ro.put("cells", cells)
                rows.put(ro)
            }
            o.put("rows", rows)
            arr.put(o)
        }
        cardsPrefs.edit().putString("cards_json", arr.toString()).apply()
    }

    private fun todayString(): String =
        java.text.SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(java.util.Date())

    private fun firstEmptyCell(row: CardRow): Int = row.cells.indexOfFirst { !it.filled }

    private fun findCard(cards: List<ColorCard>, id: String): ColorCard? =
        cards.firstOrNull { it.id.equals(id.trim(), ignoreCase = true) }

    private fun recordMeasurementToActiveCard(r: Int, g: Int, b: Int, name: String?) {
        val id = activeCardId ?: return
        val cards = loadCards()
        val card = findCard(cards, id) ?: return
        var rowIndex = firstEmptyCell(card.rows[0]).let { if (it >= 0) 0 else 1 }
        val row = card.rows[rowIndex]
        val slot = firstEmptyCell(row)
        if (slot < 0) {
            if (rowIndex == 0 && firstEmptyCell(card.rows[1]) >= 0) {
                rowIndex = 1
            } else {
                runOnUiThread { status.text = "Karta $id má už všech 10 měření vyplněných" }
                return
            }
        }
        val targetRow = card.rows[rowIndex]
        val targetSlot = firstEmptyCell(targetRow)
        if (targetRow.date.isBlank()) targetRow.date = todayString()
        val bestName = name ?: nearestColor(r, g, b)?.let(::displayName) ?: ""
        targetRow.cells[targetSlot] = CardCell(r, g, b, bestName, true)
        saveCards(cards)
        runOnUiThread { status.text = "Karta $id • ${rowIndex + 1}. řádek • místo ${targetSlot + 1} uloženo" }
    }

    private fun showCards() {
        val dialog = AlertDialog.Builder(this).create()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(8))
        }
        root.addView(TextView(this).apply {
            text = "KARTY"
            textSize = 22f
            setPadding(0, 0, 0, dp(8))
        })

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val newButton = Button(this).apply { text = "NOVÁ KARTA" }
        val idInput = EditText(this).apply {
            hint = "ID karty"
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT
        }
        top.addView(idInput, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(newButton, LinearLayout.LayoutParams(dp(125), -2))
        root.addView(top)

        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        fun refresh() {
            list.removeAllViews()
            val cards = loadCards()
            if (cards.isEmpty()) {
                list.addView(TextView(this).apply {
                    text = "Zatím není vytvořená žádná karta."
                    textSize = 16f
                    setPadding(dp(4), dp(18), dp(4), dp(18))
                })
            }
            cards.forEach { card -> addCardView(list, card, dialog) }
        }

        newButton.setOnClickListener {
            val id = idInput.text.toString().trim()
            if (id.isBlank()) {
                idInput.error = "Zadej ID karty"
                return@setOnClickListener
            }
            val cards = loadCards()
            if (findCard(cards, id) != null) {
                idInput.error = "Toto ID už existuje"
                return@setOnClickListener
            }
            cards.add(ColorCard(id))
            saveCards(cards)
            activeCardId = id
            idInput.text.clear()
            refresh()
        }

        dialog.setView(root)
        dialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Zavřít") { _, _ -> dialog.dismiss() }
        dialog.show()
        dialog.window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.98).toInt(),
            (resources.displayMetrics.heightPixels * 0.90).toInt()
        )
        refresh()
    }

    private fun addCardView(list: LinearLayout, card: ColorCard, dialog: AlertDialog) {
        val cardBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(5), dp(8), dp(5), dp(12))
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(TextView(this).apply {
            text = "ID: ${card.id}"
            textSize = 17f
            setTypeface(null, android.graphics.Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        })
        val use = Button(this).apply {
            text = if (activeCardId.equals(card.id, true)) "AKTIVNÍ" else "POUŽÍT"
            setOnClickListener {
                activeCardId = card.id
                Toast.makeText(this@MainActivity, "Karta ${card.id} je aktivní", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
        }
        val edit = Button(this).apply {
            text = "EDITOVAT"
            setOnClickListener { editCardManually(card, dialog) }
        }
        head.addView(use, LinearLayout.LayoutParams(dp(88), -2))
        head.addView(edit, LinearLayout.LayoutParams(dp(92), -2))
        cardBox.addView(head)

        for (ri in 0..1) {
            val row = card.rows[ri]
            val dateLine = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val date = TextView(this).apply {
                text = if (row.date.isBlank()) "${ri + 1}. měření – datum zatím není" else row.date
                textSize = 14f
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            }
            val dateEdit = Button(this).apply {
                text = "DATUM"
                setOnClickListener { editRowDate(card, ri, dialog) }
            }
            dateLine.addView(date)
            dateLine.addView(dateEdit, LinearLayout.LayoutParams(dp(82), -2))
            cardBox.addView(dateLine)

            val cells = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                weightSum = 5f
            }
            for (ci in 0..4) {
                val c = row.cells[ci]
                val cell = TextView(this).apply {
                    gravity = Gravity.CENTER
                    textSize = 10f
                    setPadding(dp(2), dp(5), dp(2), dp(5))
                    text = if (c.filled)
                        "${ci + 1}\nRGB\n${c.r},${c.g},${c.b}\n${c.name}"
                    else "${ci + 1}\nprázdné"
                    setBackgroundColor(if (c.filled) Color.rgb(c.r, c.g, c.b) else 0x22000000)
                    val bright = if (c.filled) (c.r * 299 + c.g * 587 + c.b * 114) / 1000 else 255
                    setTextColor(if (bright < 140) Color.WHITE else Color.BLACK)
                    setOnClickListener { editCardCell(card, ri, ci, dialog) }
                }
                cells.addView(cell, LinearLayout.LayoutParams(0, dp(82), 1f).apply {
                    setMargins(dp(2), dp(2), dp(2), dp(2))
                })
            }
            cardBox.addView(cells)
        }
        val del = Button(this).apply {
            text = "SMAZAT KARTU"
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Smazat kartu?")
                    .setMessage("Karta ${card.id} a všech jejích 10 měření budou odstraněny.")
                    .setNegativeButton("Zrušit", null)
                    .setPositiveButton("SMAZAT") { _, _ ->
                        val cards = loadCards()
                        cards.removeAll { it.id.equals(card.id, true) }
                        saveCards(cards)
                        if (activeCardId.equals(card.id, true)) activeCardId = null
                        dialog.dismiss()
                        showCards()
                    }.show()
            }
        }
        cardBox.addView(del)
        list.addView(cardBox)
        list.addView(View(this).apply { setBackgroundColor(0x55000000) },
            LinearLayout.LayoutParams(-1, dp(1)))
    }

    private fun editRowDate(card: ColorCard, rowIndex: Int, dialog: AlertDialog) {
        val input = EditText(this).apply {
            setSingleLine(true)
            hint = "dd.MM.yyyy"
            setText(card.rows[rowIndex].date)
            inputType = InputType.TYPE_CLASS_TEXT
        }
        AlertDialog.Builder(this)
            .setTitle("Datum ${rowIndex + 1}. měření")
            .setView(input)
            .setNegativeButton("Zrušit", null)
            .setPositiveButton("ULOŽIT") { _, _ ->
                card.rows[rowIndex].date = input.text.toString().trim()
                val cards = loadCards()
                findCard(cards, card.id)?.rows?.set(rowIndex, card.rows[rowIndex])
                saveCards(cards)
                dialog.dismiss()
                showCards()
            }.show()
    }

    private fun editCardCell(card: ColorCard, rowIndex: Int, cellIndex: Int, dialog: AlertDialog) {
        val c = card.rows[rowIndex].cells[cellIndex]
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, dp(12), 0)
        }
        fun field(hint: String, value: String): EditText = EditText(this).apply {
            this.hint = hint; setSingleLine(true); setText(value)
        }
        val rIn = field("R 0–255", if (c.filled) c.r.toString() else "")
        val gIn = field("G 0–255", if (c.filled) c.g.toString() else "")
        val bIn = field("B 0–255", if (c.filled) c.b.toString() else "")
        val nIn = field("Název barvy", c.name)
        rIn.inputType = InputType.TYPE_CLASS_NUMBER
        gIn.inputType = InputType.TYPE_CLASS_NUMBER
        bIn.inputType = InputType.TYPE_CLASS_NUMBER
        box.addView(rIn); box.addView(gIn); box.addView(bIn); box.addView(nIn)
        AlertDialog.Builder(this)
            .setTitle("${rowIndex + 1}. řádek • místo ${cellIndex + 1}")
            .setView(box)
            .setNegativeButton("Zrušit", null)
            .setNeutralButton("VYMAZAT") { _, _ ->
                val cards = loadCards()
                val found = findCard(cards, card.id) ?: return@setNeutralButton
                found.rows[rowIndex].cells[cellIndex] = CardCell()
                saveCards(cards)
                dialog.dismiss(); showCards()
            }
            .setPositiveButton("ULOŽIT") { _, _ ->
                val rr = rIn.text.toString().toIntOrNull()?.coerceIn(0,255)
                val gg = gIn.text.toString().toIntOrNull()?.coerceIn(0,255)
                val bb = bIn.text.toString().toIntOrNull()?.coerceIn(0,255)
                if (rr == null || gg == null || bb == null) return@setPositiveButton
                val cards = loadCards()
                val found = findCard(cards, card.id) ?: return@setPositiveButton
                found.rows[rowIndex].cells[cellIndex] = CardCell(rr, gg, bb, nIn.text.toString().trim(), true)
                if (found.rows[rowIndex].date.isBlank()) found.rows[rowIndex].date = todayString()
                saveCards(cards)
                dialog.dismiss(); showCards()
            }.show()
    }

    private fun editCardManually(card: ColorCard, dialog: AlertDialog) {
        // The card editor exposes ID and both measurement dates; individual cells are
        // editable from the card itself, including RGB and name.
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, dp(12), 0)
        }
        val idIn = EditText(this).apply {
            setSingleLine(true); setText(card.id); hint = "ID karty"
        }
        val d1 = EditText(this).apply {
            setSingleLine(true); setText(card.rows[0].date); hint = "Datum 1. měření"
        }
        val d2 = EditText(this).apply {
            setSingleLine(true); setText(card.rows[1].date); hint = "Datum 2. měření"
        }
        box.addView(idIn); box.addView(d1); box.addView(d2)
        AlertDialog.Builder(this)
            .setTitle("Upravit kartu")
            .setView(box)
            .setNegativeButton("Zrušit", null)
            .setPositiveButton("ULOŽIT") { _, _ ->
                val newId = idIn.text.toString().trim()
                if (newId.isBlank()) return@setPositiveButton
                val cards = loadCards()
                val found = findCard(cards, card.id) ?: return@setPositiveButton
                val clash = cards.any { it.id.equals(newId, true) && !it.id.equals(card.id, true) }
                if (clash) return@setPositiveButton
                found.id = newId
                found.rows[0].date = d1.text.toString().trim()
                found.rows[1].date = d2.text.toString().trim()
                if (activeCardId.equals(card.id, true)) activeCardId = newId
                saveCards(cards)
                dialog.dismiss(); showCards()
            }.show()
    }

    private fun showColorDatabase() {
        if (colors.isEmpty()) {
            Toast.makeText(this, "Databáze barev ještě není načtená", Toast.LENGTH_SHORT).show()
            return
        }

        val dialog = AlertDialog.Builder(this).create()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(10))
        }
        box.addView(TextView(this).apply {
            text = "Databáze barev"
            textSize = 22f
            setPadding(0, 0, 0, dp(10))
        })

        val search = EditText(this).apply {
            hint = "RGB 255,0,0 / #FF0000 / název"
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
        }
        box.addView(search)

        val listView = ListView(this).apply {
            dividerHeight = dp(1)
            setPadding(0, dp(4), 0, 0)
        }
        box.addView(listView, LinearLayout.LayoutParams(-1, 0, 1f))
        dialog.setView(box)
        dialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Zavřít") { _, _ -> dialog.dismiss() }

        // Cache the displayed names once. The old implementation created ~2400 View
        // objects every time the database opened or the search text changed.
        // ListView recycles rows, so only the visible rows are actually created.
        val all = colors.map { it to displayName(it) }
            .sortedBy { it.second.lowercase(Locale.getDefault()) }

        val adapter = DatabaseAdapter(dialog, all)
        listView.adapter = adapter

        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                adapter.filter(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: android.text.Editable?) = Unit
        })

        dialog.show()
        dialog.window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.94).toInt(),
            (resources.displayMetrics.heightPixels * 0.88).toInt()
        )
    }

    private inner class DatabaseAdapter(
        private val dialog: AlertDialog,
        private val all: List<Pair<NamedColor, String>>
    ) : BaseAdapter() {
        private var shown = all

        override fun getCount(): Int = shown.size
        override fun getItem(position: Int): Pair<NamedColor, String> = shown[position]
        override fun getItemId(position: Int): Long = position.toLong()

        fun filter(queryRaw: String) {
            val q = queryRaw.trim().lowercase(Locale.getDefault())
            shown = if (q.isEmpty()) {
                all
            } else {
                val qCompact = q.replace(" ", "")
                val qHex = q.removePrefix("#")
                all.filter { (c, name) ->
                    val nameLower = name.lowercase(Locale.getDefault())
                    val rgb = "${c.r},${c.g},${c.b}"
                    val rgbSpaced = "${c.r} ${c.g} ${c.b}"
                    val hex = "%02x%02x%02x".format(c.r, c.g, c.b)
                    nameLower.contains(q) || rgb.contains(qCompact) ||
                        rgbSpaced.contains(q) || hex.contains(qHex)
                }
            }
            notifyDataSetChanged()
        }

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val row = (convertView as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(4), 0, dp(4))
            }

            val info = if (row.childCount > 0) row.getChildAt(0) as TextView else TextView(this@MainActivity).apply {
                textSize = 15f
                setTextColor(Color.BLACK)
                setPadding(dp(4), dp(4), dp(4), dp(4))
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            }
            val save = if (row.childCount > 1) row.getChildAt(1) as Button else Button(this@MainActivity).apply {
                layoutParams = LinearLayout.LayoutParams(dp(92), -2)
            }
            val rename = if (row.childCount > 2) row.getChildAt(2) as Button else Button(this@MainActivity).apply {
                layoutParams = LinearLayout.LayoutParams(dp(82), -2)
                text = "NÁZEV"
            }

            if (row.childCount == 0) {
                row.addView(info)
                row.addView(save)
                row.addView(rename)
            }

            val (c, name) = shown[position]
            info.text = "$name\nRGB ${c.r}, ${c.g}, ${c.b}   #%02X%02X%02X".format(c.r, c.g, c.b)
            save.text = if (isSaved(c)) "ULOŽENO" else "ULOŽIT"
            save.setOnClickListener {
                val now = !isSaved(c)
                setSaved(c, now)
                save.text = if (now) "ULOŽENO" else "ULOŽIT"
                Toast.makeText(
                    this@MainActivity,
                    if (now) "Barva uložena" else "Barva odebrána",
                    Toast.LENGTH_SHORT
                ).show()
            }
            rename.setOnClickListener { editColorName(c, dialog) }
            info.setOnClickListener {
                showColorOnMainScreen(c)
                dialog.dismiss()
                status.text = "Vybraná barva: ${displayName(c)}"
            }
            return row
        }
    }

    private fun editColorName(c: NamedColor, databaseDialog: AlertDialog) {
        val input = EditText(this).apply {
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setText(displayName(c))
            selectAll()
        }
        AlertDialog.Builder(this)
            .setTitle("Název barvy")
            .setView(input)
            .setNegativeButton("Zrušit", null)
            .setPositiveButton("ULOŽIT") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    prefs.edit().putString("name_${colorKey(c)}", name).apply()
                    databaseDialog.dismiss()
                    showColorDatabase()
                    Toast.makeText(this, "Název uložen: $name", Toast.LENGTH_SHORT).show()
                }
            }
            .show()
    }

    private fun showSavedColors() {
        val saved = colors.filter(::isSaved).sortedBy { displayName(it).lowercase(Locale.getDefault()) }
        val dialog = AlertDialog.Builder(this).create()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(10))
        }
        box.addView(TextView(this).apply {
            text = "ULOŽENÉ BARVY"
            textSize = 22f
            setPadding(0, 0, 0, dp(10))
        })
        if (saved.isEmpty()) {
            box.addView(TextView(this).apply {
                text = "Zatím nemáš uloženou žádnou barvu."
                textSize = 17f
                setPadding(0, dp(12), 0, dp(12))
            })
        } else {
            val scroll = ScrollView(this)
            val listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            saved.forEach { c ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, dp(5), 0, dp(5))
                }
                val info = TextView(this).apply {
                    text = "${displayName(c)}\nRGB ${c.r}, ${c.g}, ${c.b}   #%02X%02X%02X".format(c.r, c.g, c.b)
                    textSize = 15f
                    setTextColor(Color.BLACK)
                    layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                    setOnClickListener {
                        showColorOnMainScreen(c)
                        dialog.dismiss()
                        status.text = "Vybraná uložená barva: ${displayName(c)}"
                    }
                }
                val remove = Button(this).apply {
                    text = "SMAZAT"
                    setOnClickListener {
                        setSaved(c, false)
                        dialog.dismiss()
                        showSavedColors()
                    }
                }
                row.addView(info)
                row.addView(remove, LinearLayout.LayoutParams(dp(90), -2))
                listBox.addView(row)
            }
            scroll.addView(listBox)
            box.addView(scroll, LinearLayout.LayoutParams(-1, dp(480)))
        }
        dialog.setView(box)
        dialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Zavřít") { _, _ -> dialog.dismiss() }
        dialog.show()
        dialog.window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.94).toInt(),
            (resources.displayMetrics.heightPixels * 0.82).toInt()
        )
    }

    private fun showColorOnMainScreen(c: NamedColor) {
        prepareNavigationForDatabaseColor(c)
        updateDisplayedColor(c.r, c.g, c.b, displayName(c), false)
    }

    private fun nearestColor(r: Int, g: Int, b: Int): NamedColor? {
        if (colors.isEmpty()) return null
        val lab = ColorMath.rgbToLab(r, g, b)
        return colors.minByOrNull { ColorMath.deltaE00(lab, it.lab) }
    }

    private fun updateDisplayedColor(r: Int, g: Int, b: Int, name: String?, resetNavigation: Boolean = true) {
        val rr = r.coerceIn(0, 255)
        val gg = g.coerceIn(0, 255)
        val bb = b.coerceIn(0, 255)
        if (resetNavigation) prepareNavigation(rr, gg, bb)
        updatingSliders = true
        redSeek.progress = rr
        greenSeek.progress = gg
        blueSeek.progress = bb
        updatingSliders = false
        result.setBackgroundColor(Color.rgb(rr, gg, bb))
        val brightness = (rr * 299 + gg * 587 + bb * 114) / 1000
        result.setTextColor(if (brightness < 140) Color.WHITE else Color.BLACK)
        val hex = "#%02X%02X%02X".format(rr, gg, bb)
        rgbValues.text = "RGB $rr, $gg, $bb   $hex"
        result.text = if (name != null) "$name\nRGB $rr, $gg, $bb\n$hex" else "RGB $rr, $gg, $bb\n$hex"
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, r: ScanResult) {
            val name = try { r.device.name } catch (_: SecurityException) { null }
            if (name.isNullOrBlank() || !name.contains("LS170", true)) return
            stopScan(); ble?.close()
            ble = Ls170Ble(this@MainActivity, { rr, gg, bb ->
                val lab = ColorMath.rgbToLab(rr, gg, bb)
                val best = colors.minByOrNull { ColorMath.deltaE00(lab, it.lab) }
                runOnUiThread {
                    updateDisplayedColor(rr, gg, bb, best?.let(::displayName))
                    status.text = if (best != null) "Měření přijato • ΔE00 %.2f".format(ColorMath.deltaE00(lab, best.lab)) else "Měření přijato"
                    if (activeCardId != null) {
                        recordMeasurementToActiveCard(rr, gg, bb, best?.let(::displayName))
                    }
                }
            }, { s -> runOnUiThread { status.text = s } })
            ble?.connect(r.device)
        }
        override fun onScanFailed(errorCode: Int) {
            scanning = false
            runOnUiThread { status.text = "Skenování selhalo: $errorCode" }
        }
    }

    private fun startScan() {
        if (android.os.Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
            status.text = "Povol Bluetooth skenování a zkus znovu"; return
        }
        if (scanning) return
        scanning = true; status.text = "Hledám LS170…"; scanner.startScan(scanCallback)
    }

    private fun stopScan() {
        if (!scanning) return
        if (android.os.Build.VERSION.SDK_INT < 31 || checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED) scanner.stopScan(scanCallback)
        scanning = false
    }

    override fun onDestroy() {
        stopScan()
        ble?.close()
        super.onDestroy()
    }
}
