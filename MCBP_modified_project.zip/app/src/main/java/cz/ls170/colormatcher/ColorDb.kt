package cz.ls170.colormatcher

import org.json.JSONObject
import java.net.URL

data class NamedColor(val name:String,val r:Int,val g:Int,val b:Int,val lab:Lab)

object ColorDb {
    // Public 2398-entry color-name JSON used as the source dataset.
    // Downloaded once at startup; the matcher itself is offline after loading.
    private const val URL_JSON =
        "https://gist.githubusercontent.com/gurkanakdeniz/dbbf7fd89d887ac4b56ef9e316e18fc6/raw/"

    fun load(): List<NamedColor> {
        val text=URL(URL_JSON).readText()
        val obj=JSONObject(text)
        val out=ArrayList<NamedColor>(obj.length())
        for (k in obj.keys()) {
            val h=k.removePrefix("#")
            if(h.length!=6) continue
            val r=h.substring(0,2).toInt(16)
            val g=h.substring(2,4).toInt(16)
            val b=h.substring(4,6).toInt(16)
            out += NamedColor(obj.getString(k),r,g,b,ColorMath.rgbToLab(r,g,b))
        }
        return out
    }
}
