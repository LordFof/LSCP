package cz.ls170.colormatcher

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothManager
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.pm.PackageManager
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.provider.Settings
import android.provider.DocumentsContract
import android.graphics.Color
import android.os.Bundle
import android.os.Build
import android.provider.MediaStore
import android.text.InputType
import android.text.TextWatcher
import android.text.Editable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.LinkedHashSet
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var result: TextView
    private lateinit var scan: Button
    private lateinit var measure: Button
    private lateinit var database: Button
    private lateinit var savedColorsButton: Button
    private lateinit var cardsButton: Button
    private lateinit var redSeek: SeekBar
    private lateinit var greenSeek: SeekBar
    private lateinit var blueSeek: SeekBar
    private var cardsListContainer: LinearLayout? = null
    private var cardsDialogRef: AlertDialog? = null
    private var databaseDialogRef: AlertDialog? = null
    private var databaseAdapterRef: DatabaseAdapter? = null
    private lateinit var rgbValues: TextView
    private var updatingSliders = false
    private var ble: Ls170Ble? = null
    private var colors: List<NamedColor> = emptyList()
    private var scanning = false
    private lateinit var scanner: BluetoothLeScanner
    private val prefs by lazy { getSharedPreferences("mcbp_colors", Context.MODE_PRIVATE) }
    private val cardsPrefs by lazy { getSharedPreferences("mcbp_cards", Context.MODE_PRIVATE) }
    private val uiPrefs by lazy { getSharedPreferences("mcbp_ui", Context.MODE_PRIVATE) }
    private val exportPrefs by lazy { getSharedPreferences("mcbp_export", Context.MODE_PRIVATE) }
    private val exportPathDefault = "/storage/emulated/0/MCBP"
    private val exportTreeRequestCode = 7101
    private var activeCardId: String? = null
    private lateinit var menuButtonRef: TextView
    private lateinit var rgbButtonRef: TextView
    private lateinit var menuPanelRef: View
    private lateinit var menuScrollRef: ScrollView
    private lateinit var menuControlsRef: LinearLayout
    private lateinit var rgbPanelRef: LinearLayout
    private lateinit var mainRootRef: FrameLayout
    private var settingsDialog: AlertDialog? = null
    private var previewOverlay: View? = null
    private var previewPopup: View? = null
    private var previewScroll: ScrollView? = null
    private var previewBox: LinearLayout? = null
    private var previewActiveRow: View? = null
    private var previewHiddenRows: MutableList<View> = mutableListOf()
    private var previewMenuWasVisible = false
    private var previewRgbWasVisible = false
    private var menuButtons: MutableList<Button> = mutableListOf()
    private var menuOpenState = false
    private var laboratoryOverlay: View? = null
    private var laboratoryPreview: TextView? = null
    private var laboratoryName: TextView? = null
    private var laboratoryRInput: EditText? = null
    private var laboratoryGInput: EditText? = null
    private var laboratoryBInput: EditText? = null
    private var laboratoryLastRgb: IntArray? = null
    private var laboratoryHeldPosition: HeldLabPosition? = null
    private var laboratoryMeasurementHandler: ((Int, Int, Int) -> Unit)? = null
    private val laboratoryHistory = mutableListOf<LabHistoryEntry>()

    private fun uiInt(key: String, default: Int, min: Int, max: Int): Int =
        uiPrefs.getInt(key, default).coerceIn(min, max)

    private fun uiSp(key: String, default: Float, min: Float, max: Float): Float =
        uiPrefs.getInt(key, default.toInt()).toFloat().coerceIn(min, max)

    private fun colorKey(c: NamedColor) = "%d,%d,%d".format(c.r, c.g, c.b)
    private fun displayName(c: NamedColor): String =
        prefs.getString("name_${colorKey(c)}", null)?.takeIf { it.isNotBlank() } ?: c.name

    private fun isSaved(c: NamedColor): Boolean = prefs.getBoolean("saved_${colorKey(c)}", false)

    private fun setSaved(c: NamedColor, saved: Boolean) {
        prefs.edit().putBoolean("saved_${colorKey(c)}", saved).apply()
    }

    private data class LabGroup(var name: String, val members: LinkedHashSet<String> = LinkedHashSet())

    private fun loadLabGroups(): MutableList<LabGroup> {
        val result = mutableListOf<LabGroup>()
        val raw = prefs.getString("lab_groups_json", "[]") ?: "[]"
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val name = obj.optString("name").trim()
                if (name.isEmpty()) continue
                val members = LinkedHashSet<String>()
                val ma = obj.optJSONArray("members")
                if (ma != null) for (j in 0 until ma.length()) ma.optString(j).takeIf { it.isNotBlank() }?.let(members::add)
                result.add(LabGroup(name, members))
            }
        } catch (_: Exception) {}
        return result
    }

    private fun saveLabGroups(groups: List<LabGroup>) {
        val arr = JSONArray()
        groups.forEach { g ->
            val obj = JSONObject().put("name", g.name)
            val members = JSONArray()
            g.members.forEach { members.put(it) }
            obj.put("members", members)
            arr.put(obj)
        }
        prefs.edit().putString("lab_groups_json", arr.toString()).apply()
    }

    private fun groupsForColor(c: NamedColor): List<String> =
        loadLabGroups().filter { colorKey(c) in it.members }.map { it.name }

    private fun groupSuffix(c: NamedColor): String {
        val groups = groupsForColor(c)
        return if (groups.isEmpty()) "" else "  •  Skupina ${groups.joinToString(", ")}"
    }

    private fun groupDisplayName(c: NamedColor): String = displayName(c) + groupSuffix(c)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this).apply { setBackgroundColor(Color.rgb(28, 32, 38)) }

        result = TextView(this).apply {
            text = "Zatím žádné měření"
            textSize = uiSp("main_text_size", if (resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE) 48f else 64f, 24f, 110f)
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(dp(18), dp(88), dp(18), dp(88))
            includeFontPadding = true
        }
        root.addView(result, FrameLayout.LayoutParams(-1, -1))

        // RGB controls are hidden behind their own floating button so they never cover the main result.
        val sliderPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(18), dp(10), dp(18), dp(8))
            background = aeroBackground(uiColor("menu_panel", 0xD0181818.toInt()), dp(24))
            elevation = dp(12).toFloat()
            visibility = View.GONE
        }

        rgbValues = TextView(this).apply {
            text = "RGB 128, 128, 128   #808080"
            textSize = uiSp("main_rgb_text_size", 20f, 10f, 36f)
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, dp(4))
        }
        sliderPanel.addView(rgbValues, LinearLayout.LayoutParams(-1, dp(34)))

        fun addMainSlider(label: String, initial: Int): SeekBar {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val tv = TextView(this).apply {
                text = label
                textSize = uiSp("main_slider_text_size", 20f, 10f, 36f)
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                minWidth = dp(38)
            }
            val sb = SeekBar(this).apply {
                max = 255
                progress = initial
                minHeight = dp(34)
                layoutParams = LinearLayout.LayoutParams(0, dp(46), 1f)
            }
            row.addView(tv, LinearLayout.LayoutParams(dp(42), dp(46)))
            row.addView(sb)
            sliderPanel.addView(row, LinearLayout.LayoutParams(-1, dp(46)))
            return sb
        }

        redSeek = addMainSlider("R", 128)
        greenSeek = addMainSlider("G", 128)
        blueSeek = addMainSlider("B", 128)

        val mainOverlay = FrameLayout(this)
        mainOverlay.addView(sliderPanel, FrameLayout.LayoutParams(dp(310), dp(190)).apply {
            gravity = Gravity.TOP or Gravity.START
            setMargins(dp(12), dp(78), 0, 0)
        })

        val rgbButton = TextView(this).apply {
            text = "RGB"
            textSize = uiSp("rgb_icon_text_size", 13f, 10f, 30f)
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = aeroBackground(uiColor("rgb", 0x66000000.toInt()), dp(30))
            elevation = dp(10).toFloat()
            contentDescription = "RGB posuvníky"
        }
        rgbButtonRef = rgbButton
        mainOverlay.addView(rgbButton, FrameLayout.LayoutParams(dp(62), dp(58)).apply {
            gravity = Gravity.TOP or Gravity.START
            setMargins(dp(12), dp(10), 0, 0)
        })
        root.addView(mainOverlay, FrameLayout.LayoutParams(-1, -1))
        mainRootRef = root

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = aeroBackground(uiColor("menu_panel", 0xD0181818.toInt()), dp(24))
            elevation = dp(12).toFloat()
            visibility = View.GONE
        }
        status = TextView(this).apply {
            text = "Načítám…"
            textSize = uiSp("menu_status_text_size", 16f, 10f, 30f)
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, dp(8))
        }
        scan = makeAeroButton("Hledat LS170")
        measure = makeAeroButton("Měřit")
        database = makeAeroButton("Databáze barev")
        savedColorsButton = makeAeroButton("ULOŽENÉ BARVY")
        cardsButton = makeAeroButton("KARTY")
        val settingsButton = makeAeroButton("NASTAVENÍ")
        val laboratoryButton = makeAeroButton("LABORATOŘ")
        controls.addView(status)
        controls.addView(scan, LinearLayout.LayoutParams(-1, dp(40)).apply { bottomMargin = dp(5) })
        controls.addView(measure, LinearLayout.LayoutParams(-1, dp(40)).apply { bottomMargin = dp(5) })
        controls.addView(database, LinearLayout.LayoutParams(-1, dp(40)).apply { bottomMargin = dp(5) })
        controls.addView(savedColorsButton, LinearLayout.LayoutParams(-1, dp(40)).apply { bottomMargin = dp(5) })
        controls.addView(cardsButton, LinearLayout.LayoutParams(-1, dp(40)).apply { bottomMargin = dp(5) })
        controls.addView(laboratoryButton, LinearLayout.LayoutParams(-1, dp(40)).apply { bottomMargin = dp(5) })
        controls.addView(settingsButton, LinearLayout.LayoutParams(-1, dp(40)))
        menuButtons = mutableListOf(scan, measure, database, savedColorsButton, cardsButton, laboratoryButton, settingsButton)

        val menuWrap = FrameLayout(this)
        val menuScroll = ScrollView(this).apply {
            isFillViewport = false
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
            background = null
            addView(controls, ViewGroup.LayoutParams(-1, -2))
        }
        val menuMaxHeight = minOf(dp(430), (resources.displayMetrics.heightPixels * 0.65f).toInt())
        menuWrap.addView(menuScroll, FrameLayout.LayoutParams(dp(245), menuMaxHeight).apply {
            gravity = Gravity.TOP or Gravity.END
            setMargins(0, dp(78), dp(12), 0)
        })
        val menuButton = TextView(this).apply {
            text = "☰"
            textSize = uiSp("menu_icon_text_size", 23f, 10f, 40f)
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = aeroBackground(uiColor("menu", 0x66000000.toInt()), dp(30))
            elevation = dp(10).toFloat()
            contentDescription = "Nabídka"
        }
        menuButtonRef = menuButton
        menuControlsRef = controls
        menuScrollRef = menuScroll
        menuWrap.addView(menuButton, FrameLayout.LayoutParams(dp(58), dp(58)).apply {
            gravity = Gravity.TOP or Gravity.END
            setMargins(0, dp(10), dp(12), 0)
        })
        root.addView(menuWrap, FrameLayout.LayoutParams(-1, -1))

        // Style/preview the actual menu panel, not the transparent ScrollView container.
        // The ScrollView only provides scrolling and must never draw an always-visible rectangle.
        menuPanelRef = controls
        rgbPanelRef = sliderPanel

        menuButton.setOnClickListener {
            menuOpenState = !menuOpenState
            controls.visibility = if (menuOpenState) View.VISIBLE else View.GONE
            menuButton.text = if (menuOpenState) "×" else "☰"
        }
        var rgbOpen = false
        rgbButton.setOnClickListener {
            rgbOpen = !rgbOpen
            sliderPanel.visibility = if (rgbOpen) View.VISIBLE else View.GONE
            rgbButton.text = if (rgbOpen) "×" else "RGB"
        }

        val sliderListener = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!updatingSliders && fromUser) {
                    val rr = redSeek.progress
                    val gg = greenSeek.progress
                    val bb = blueSeek.progress
                    val nearest = nearestColor(rr, gg, bb)
                    updateDisplayedColor(rr, gg, bb, nearest?.let(::displayName))
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        }
        redSeek.setOnSeekBarChangeListener(sliderListener)
        greenSeek.setOnSeekBarChangeListener(sliderListener)
        blueSeek.setOnSeekBarChangeListener(sliderListener)

        val credit = TextView(this).apply {
            text = "Created by LordFof"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(0xCCFFFFFF.toInt())
        }
        root.addView(credit, FrameLayout.LayoutParams(-2, -2).apply {
            gravity = Gravity.BOTTOM or Gravity.START
            setMargins(dp(12), 0, 0, dp(14))
        })
        setContentView(root)

        if (android.os.Build.VERSION.SDK_INT >= 31) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT), 10)
        } else if (android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 11)
        }

        Executors.newSingleThreadExecutor().execute {
            try {
                colors = ColorDb.load()
                runOnUiThread {
                    status.text = "Databáze: ${colors.size} barev • připraveno"
                    // If Laboratoř was opened while the database was still loading,
                    // rebuild it now so the current RGB immediately gets its color,
                    // tolerance ranges and slider overlays. Keep the last RGB position.
                    if (laboratoryOverlay != null && ::mainRootRef.isInitialized) {
                        showLaboratory(mainRootRef)
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Databáze barev se nepodařila načíst" }
            }
        }

        val manager = getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
        scanner = manager.adapter.bluetoothLeScanner

        scan.setOnClickListener {
            ble?.close()
            stopScan()
            startScan()
        }
        measure.setOnClickListener {
            if (ble?.triggerMeasurement() == true) status.text = "Příkaz odeslán • čekám na měření…"
            else status.text = "LS170 není připravený — nejdřív ho připoj"
        }
        database.setOnClickListener { showColorDatabase() }
        savedColorsButton.setOnClickListener { showSavedColors() }
        cardsButton.setOnClickListener { showCards() }
        laboratoryButton.setOnClickListener {
            menuOpenState = false
            menuControlsRef.visibility = View.GONE
            menuButtonRef.text = "☰"
            showLaboratory(root)
        }
        settingsButton.setOnClickListener {
            menuOpenState = false
            menuControlsRef.visibility = View.GONE
            menuButtonRef.text = "☰"
            showUiSettings()
        }

        applyUiSettings()
    }

    override fun onBackPressed() {
        laboratoryOverlay?.let {
            (it.parent as? ViewGroup)?.removeView(it)
            laboratoryOverlay = null
            laboratoryMeasurementHandler = null
            return
        }
        super.onBackPressed()
    }

    private fun showLaboratory(root: FrameLayout) {
        laboratoryOverlay?.let { root.removeView(it) }

        val overlay = FrameLayout(this).apply {
            setBackgroundColor(Color.rgb(28, 32, 38))
            elevation = dp(30).toFloat()
        }

        val content = FrameLayout(this).apply {
            clipChildren = true
            clipToPadding = true
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(12), dp(72), dp(12), dp(8))
        }
        val landscape = resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
        if (landscape) {
            val scroll = ScrollView(this).apply {
                isFillViewport = false
                overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
                clipToPadding = false
            }
            scroll.addView(box, FrameLayout.LayoutParams(-1, -2))
            content.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        } else {
            content.addView(box, FrameLayout.LayoutParams(-1, -2))
        }
        overlay.addView(content, FrameLayout.LayoutParams(-1, -1))

        val backButton = TextView(this).apply {
            text = "←"
            textSize = uiSp("menu_icon_text_size", 23f, 10f, 40f)
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = aeroBackground(uiColor("menu", 0x66000000.toInt()), dp(30))
            elevation = dp(12).toFloat()
            contentDescription = "Zpět na hlavní obrazovku"
            setOnClickListener { closeLaboratory(root) }
        }
        overlay.addView(backButton, FrameLayout.LayoutParams(dp(58), dp(58)).apply {
            gravity = Gravity.TOP or Gravity.END
            setMargins(0, dp(10), dp(12), 0)
        })

        fun labCard(): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(7), dp(7), dp(7), dp(7))
            background = aeroBackground(uiColor("menu_panel", 0xD0181818.toInt()), dp(22))
            elevation = dp(5).toFloat()
        }
        fun labText(text: String, size: Float = 13f, bold: Boolean = false): TextView = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(Color.WHITE)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        fun input(value: Int): EditText = EditText(this).apply {
            setText(value.toString())
            inputType = InputType.TYPE_CLASS_NUMBER
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(Color.BLACK)
            setSingleLine(true)
            background = aeroBackground(0xFFE8EAED.toInt(), dp(12))
            setPadding(dp(6), 0, dp(6), 0)
        }

        val savedLabRgb = laboratoryLastRgb
        val initialR = savedLabRgb?.getOrNull(0)?.coerceIn(0, 255) ?: redSeek.progress.coerceIn(0, 255)
        val initialG = savedLabRgb?.getOrNull(1)?.coerceIn(0, 255) ?: greenSeek.progress.coerceIn(0, 255)
        val initialB = savedLabRgb?.getOrNull(2)?.coerceIn(0, 255) ?: blueSeek.progress.coerceIn(0, 255)
        val state = LabUiState(initialR, initialG, initialB, nearestColor(initialR, initialG, initialB), false)
        var updatingInputs = false
        var suppressRefresh = false

        val top = labCard()
        val preview = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 16f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            minHeight = dp(82)
        }
        laboratoryPreview = preview

        val right = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, 0, 0)
        }
        val name = labText(state.nearest?.let(::displayName) ?: "Neurčeno", 19f, true)
        laboratoryName = name
        right.addView(name, LinearLayout.LayoutParams(-1, dp(28)))
        val inputs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val rIn = input(initialR); val gIn = input(initialG); val bIn = input(initialB)
        laboratoryRInput = rIn; laboratoryGInput = gIn; laboratoryBInput = bIn
        listOf("R" to rIn, "G" to gIn, "B" to bIn).forEach { (label, edit) ->
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            col.addView(labText(label, 10f), LinearLayout.LayoutParams(-1, dp(15)))
            col.addView(edit, LinearLayout.LayoutParams(-1, dp(34)))
            inputs.addView(col, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginEnd = dp(4) })
        }
        right.addView(inputs)
        val hex = labText("HEX / RGB", 10f)
        right.addView(hex, LinearLayout.LayoutParams(-1, dp(18)))
        val topRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        topRow.addView(preview, LinearLayout.LayoutParams(0, dp(104), 1f))
        topRow.addView(right, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(topRow, LinearLayout.LayoutParams(-1, -2))

        val tolCard = labCard()
        tolCard.addView(labText("TOLERANCE", 14f, true), LinearLayout.LayoutParams(-1, dp(24)))
        val tolLabels = listOf(labText("R−G", 13f), labText("G−B", 13f), labText("R−B", 13f))
        val tolValues = listOf(labText("", 14f), labText("", 14f), labText("", 14f))
        val tolRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (i in 0..2) {
            val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
            c.addView(tolLabels[i]); c.addView(tolValues[i])
            tolRow.addView(c, LinearLayout.LayoutParams(0, dp(43), 1f))
        }
        tolCard.addView(tolRow)
        box.addView(top, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        box.addView(tolCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })

        val labMeasureButton = Button(this).apply {
            text = "Měřit"
            textSize = 13.5f
            isAllCaps = false
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(Color.WHITE)
            background = aeroBackground(uiColor("menu", 0x66000000.toInt()), dp(14))
        }
        labMeasureButton.setOnClickListener {
            if (ble?.triggerMeasurement() == true) {
                status.text = "Příkaz odeslán • čekám na měření…"
            } else {
                Toast.makeText(this, "LS170 není připravený — nejdřív ho připoj", Toast.LENGTH_SHORT).show()
            }
        }
        box.addView(labMeasureButton, LinearLayout.LayoutParams(-1, dp(42)).apply { bottomMargin = dp(6) })

        val sliderCard = labCard()
        fun rangeOverlay(color: Int): View = View(this).apply {
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0x22000000)
                setStroke(dp(2), color)
                cornerRadius = dp(5).toFloat()
            }
            isClickable = false
            isFocusable = false
        }
        class SliderParts(val seek: SeekBar, val range: View, val label: TextView)
        val sliderParts = ArrayList<SliderParts>()

        fun gradientSeek(channel: Char, value: Int): SeekBar {
            val seek = SeekBar(this).apply {
                max = 255
                progress = value.coerceIn(0, 255)
                splitTrack = false
                minHeight = dp(34)
                setPadding(dp(4), 0, dp(4), 0)
                isFocusable = true
            }
            val colorsFor = when (channel) {
                'R' -> intArrayOf(Color.rgb(0, 90, 0), Color.RED)
                'G' -> intArrayOf(Color.rgb(100, 0, 100), Color.GREEN)
                else -> intArrayOf(Color.rgb(110, 100, 0), Color.BLUE)
            }
            seek.progressDrawable = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, colorsFor
            ).apply { cornerRadius = dp(10).toFloat() }
            seek.thumb = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                setColor(0xFFF5F5F5.toInt())
                setStroke(dp(2), 0xFF555555.toInt())
                cornerRadius = dp(4).toFloat()
                setSize(dp(16), dp(38))
            }
            return seek
        }

        fun addSlider(channel: Char, value: Int): SliderParts {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val channelLabel = labText(channel.toString(), 14f, true)
            row.addView(channelLabel, LinearLayout.LayoutParams(dp(22), dp(40)))
            val track = FrameLayout(this)
            val seek = gradientSeek(channel, value)
            val range = rangeOverlay(when (channel) {
                'R' -> 0xFFFF4444.toInt()
                'G' -> 0xFF55FF55.toInt()
                else -> 0xFF5588FF.toInt()
            })
            track.addView(seek, FrameLayout.LayoutParams(-1, dp(40)))
            track.addView(range, FrameLayout.LayoutParams(dp(10), dp(38)).apply { gravity = Gravity.CENTER_VERTICAL })
            row.addView(track, LinearLayout.LayoutParams(0, dp(40), 1f))
            val valueLabel = labText("", 13f)
            valueLabel.gravity = Gravity.CENTER_VERTICAL
            row.addView(valueLabel, LinearLayout.LayoutParams(dp(72), dp(40)))
            sliderCard.addView(row)
            return SliderParts(seek, range, valueLabel)
        }

        sliderParts += addSlider('R', state.r)
        sliderParts += addSlider('G', state.g)
        sliderParts += addSlider('B', state.b)
        box.addView(sliderCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })

        val lockRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val lock = CheckBox(this).apply { text = "Zámek odstínu"; setTextColor(Color.WHITE); textSize = 14f; setTypeface(typeface, android.graphics.Typeface.BOLD) }
        val lockHint = labText("RGB se pohybují spolu pouze při zapnutí zámku", 10f)
        lockRow.addView(lock, LinearLayout.LayoutParams(-2, dp(38)))
        lockRow.addView(lockHint, LinearLayout.LayoutParams(0, dp(38), 1f))
        box.addView(lockRow)

        // Temporary held color. Tapping the colored held-color button returns to it.
        val holdRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val holdButton = Button(this).apply {
            text = "Podržet"
            textSize = 13.5f
            isAllCaps = false
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(Color.WHITE)
            background = aeroBackground(uiColor("menu", 0x66000000.toInt()), dp(14))
        }
        val heldLabel = Button(this).apply {
            text = "—"
            textSize = 11.5f
            isAllCaps = false
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(Color.WHITE)
            isEnabled = false
            background = aeroBackground(uiColor("menu", 0x44000000.toInt()), dp(14))
            setPadding(dp(4), 0, dp(4), 0)
        }
        val releaseHeldButton = Button(this).apply {
            text = "Pustit"
            textSize = 13.5f
            isAllCaps = false
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(Color.WHITE)
            background = aeroBackground(uiColor("menu", 0x66000000.toInt()), dp(14))
        }
        holdRow.addView(holdButton, LinearLayout.LayoutParams(0, dp(44), 0.72f).apply { marginEnd = dp(5) })
        holdRow.addView(heldLabel, LinearLayout.LayoutParams(0, dp(44), 1.48f).apply { marginEnd = dp(5) })
        holdRow.addView(releaseHeldButton, LinearLayout.LayoutParams(0, dp(44), 0.72f))
        box.addView(holdRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(5) })

        val actionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        fun labActionButton(label: String): Button = Button(this).apply {
            text = label
            textSize = 10.5f
            isAllCaps = false
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(Color.WHITE)
            background = aeroBackground(uiColor("menu", 0x66000000.toInt()), dp(14))
            minWidth = 0
            setPadding(dp(3), 0, dp(3), 0)
        }
        val createGroupButton = labActionButton("Vytvořit skupinu")
        val addGroupButton = labActionButton("Přidat do skupiny")
        val saveLabButton = labActionButton("Uložit")
        val compareButton = labActionButton("Porovnat")
        actionRow.addView(createGroupButton, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(3) })
        actionRow.addView(addGroupButton, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(3) })
        actionRow.addView(saveLabButton, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(3) })
        actionRow.addView(compareButton, LinearLayout.LayoutParams(0, dp(44), 1f))
        box.addView(actionRow, LinearLayout.LayoutParams(-1, dp(44)).apply { bottomMargin = dp(5) })

        val groupsButton = labActionButton("Skupiny")
        box.addView(groupsButton, LinearLayout.LayoutParams(-1, dp(42)).apply { bottomMargin = dp(4) })

        val nearbyLButton = labActionButton("Odstíny ±4 L")
        box.addView(nearbyLButton, LinearLayout.LayoutParams(-1, dp(38)).apply { bottomMargin = dp(6) })

        val lCard = labCard()
        lCard.addView(labText("L  –  SVĚTLOST", 14f, true), LinearLayout.LayoutParams(-1, dp(24)))
        val lTrack = FrameLayout(this)
        val initialLab = ColorMath.rgbToLab(state.r, state.g, state.b)
        val lSeek = SeekBar(this).apply {
            max = 100
            progress = initialLab.l.roundToInt().coerceIn(0, 100)
            splitTrack = false
            minHeight = dp(34)
            setPadding(dp(4), 0, dp(4), 0)
        }
        lSeek.progressDrawable = android.graphics.drawable.GradientDrawable(
            android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.BLACK, 0xFF777777.toInt(), Color.WHITE)
        ).apply { cornerRadius = dp(10).toFloat() }
        lSeek.thumb = android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            setColor(0xFFF5F5F5.toInt()); setStroke(dp(2), 0xFF555555.toInt()); cornerRadius = dp(4).toFloat(); setSize(dp(16), dp(38))
        }
        val lRangeBox = rangeOverlay(0xFFCCCCCC.toInt())
        lTrack.addView(lSeek, FrameLayout.LayoutParams(-1, dp(40)))
        lTrack.addView(lRangeBox, FrameLayout.LayoutParams(dp(10), dp(38)).apply { gravity = Gravity.CENTER_VERTICAL })
        lCard.addView(lTrack, LinearLayout.LayoutParams(-1, dp(40)))
        val lRange = labText("", 12f)
        lCard.addView(lRange)
        box.addView(lCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })

        val neighborsCard = labCard()
        neighborsCard.addView(labText("OKOLNÍ ODSTÍNY", 14f, true), LinearLayout.LayoutParams(-1, dp(24)))
        val neighbors = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val dark = labText("Tmavší", 13f); val current = labText("Aktuální", 13f); val light = labText("Světlejší", 13f)
        listOf(dark, current, light).forEach { it.gravity = Gravity.CENTER; it.setPadding(dp(3), dp(4), dp(3), dp(4)); neighbors.addView(it, LinearLayout.LayoutParams(0, dp(68), 1f).apply { marginEnd = dp(3) }) }
        neighborsCard.addView(neighbors)
        box.addView(neighborsCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })

        val historyCard = labCard()
        historyCard.addView(labText("HISTORIE MĚŘENÍ", 14f, true), LinearLayout.LayoutParams(-1, dp(24)))
        val historyRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val historyViews = listOf(0, 1, 2).map {
            labText("—", 12.5f).apply {
                gravity = Gravity.CENTER
                setPadding(dp(3), dp(4), dp(3), dp(4))
                historyRow.addView(this, LinearLayout.LayoutParams(0, dp(68), 1f).apply { marginEnd = dp(3) })
            }
        }
        historyCard.addView(historyRow)
        box.addView(historyCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })

        fun updateHistoryUi() {
            val entries = laboratoryHistory.takeLast(3)
            for (i in 0..2) {
                val view = historyViews[i]
                val entry = entries.getOrNull(i)
                if (entry == null) {
                    view.text = "—"
                    view.setBackgroundColor(0x22000000)
                    view.setTextColor(Color.WHITE)
                } else {
                    view.text = "${displayName(entry.anchor)}\nRGB ${entry.r}, ${entry.g}, ${entry.b}"
                    view.setBackgroundColor(Color.rgb(entry.r, entry.g, entry.b))
                    val lum = (entry.r * 299 + entry.g * 587 + entry.b * 114) / 1000
                    view.setTextColor(if (lum < 140) Color.WHITE else Color.BLACK)
                }
            }
        }

        fun setInputValues() {
            if (updatingInputs) return
            updatingInputs = true
            if (rIn.text.toString() != state.r.toString()) rIn.setText(state.r.toString())
            if (gIn.text.toString() != state.g.toString()) gIn.setText(state.g.toString())
            if (bIn.text.toString() != state.b.toString()) bIn.setText(state.b.toString())
            updatingInputs = false
        }
        fun setRgb(r: Int, g: Int, b: Int) {
            state.r = r.coerceIn(0, 255)
            state.g = g.coerceIn(0, 255)
            state.b = b.coerceIn(0, 255)
            laboratoryLastRgb = intArrayOf(state.r, state.g, state.b)
            setInputValues()
        }
        fun colorRange(c: NamedColor): Pair<Double, Double> {
            val tol = 4.0
            return Pair(maxOf(0.0, c.lab.l - tol), minOf(100.0, c.lab.l + tol))
        }
        fun updateRangeBox(seek: SeekBar, boxView: View, lo: Double, hi: Double) {
            // The range overlay lives in the same FrameLayout as the SeekBar.  Map
            // 0..max to the actual thumb-center track, including the thumb offset.
            // Using only paddingLeft/paddingRight makes the overlay drift, especially
            // after a landscape re-layout, because the SeekBar thumb does not travel
            // from the raw view edge to the raw view edge.
            boxView.post {
                val max = seek.max.coerceAtLeast(1)
                val thumbOffset = seek.thumbOffset.coerceAtLeast(0)
                val start = seek.paddingLeft + thumbOffset
                val end = seek.width - seek.paddingRight - thumbOffset
                val usable = (end - start).coerceAtLeast(1)
                val clampedLo = lo.coerceIn(0.0, max.toDouble())
                val clampedHi = hi.coerceIn(0.0, max.toDouble())
                val x0 = start + (clampedLo / max.toDouble() * usable).roundToInt()
                val x1 = start + (clampedHi / max.toDouble() * usable).roundToInt()
                val lp = boxView.layoutParams as FrameLayout.LayoutParams
                lp.leftMargin = minOf(x0, x1)
                lp.width = maxOf(dp(8), kotlin.math.abs(x1 - x0))
                lp.topMargin = dp(5)
                lp.height = dp(38)
                boxView.layoutParams = lp
            }
        }
        fun updatePreviewAndData() {
            val c = Color.rgb(state.r, state.g, state.b)
            preview.setBackgroundColor(c)
            val lum = (state.r * 299 + state.g * 587 + state.b * 114) / 1000
            preview.setTextColor(if (lum < 140) Color.WHITE else Color.BLACK)
            name.text = state.nearest?.let(::groupDisplayName) ?: "Neurčeno"
            preview.text = "RGB ${state.r}  ${state.g}  ${state.b}\n#%02X%02X%02X".format(state.r, state.g, state.b)
            hex.text = "HEX / RGB   #%02X%02X%02X".format(state.r, state.g, state.b)
            tolValues[0].text = "${state.r - state.g}"
            tolValues[1].text = "${state.g - state.b}"
            tolValues[2].text = "${state.r - state.b}"
        }

        fun refreshUi(updatePositions: Boolean = true) {
            if (updatePositions) {
                sliderParts[0].seek.progress = state.r
                sliderParts[1].seek.progress = state.g
                sliderParts[2].seek.progress = state.b
            }
            val anchor = state.nearest
            val currentLab = ColorMath.rgbToLab(state.r, state.g, state.b)
            lSeek.progress = currentLab.l.roundToInt().coerceIn(0, 100)
            if (anchor != null) {
                // Tolerance belongs to the current shade, not to the live slider position.
                // Cache it and replace it only when the current shade actually changes.
                val tol = state.tolerance ?: toleranceForColor(anchor).also { state.tolerance = it }
                val lows = intArrayOf(tol.rLo, tol.gLo, tol.bLo)
                val highs = intArrayOf(tol.rHi, tol.gHi, tol.bHi)
                for (i in 0..2) {
                    sliderParts[i].label.text = "${lows[i]}–${highs[i]}"
                    updateRangeBox(sliderParts[i].seek, sliderParts[i].range, lows[i].toDouble(), highs[i].toDouble())
                }
                val lab = ColorMath.rgbToLab(state.r, state.g, state.b).l
                lRange.text = "L ${tol.lLo.roundToInt()}–${tol.lHi.roundToInt()}   (aktuální ${lab.roundToInt()})"
                updateRangeBox(lSeek, lRangeBox, tol.lLo, tol.lHi)
            }
            val darkColor = anchor?.let { nearestLightnessColorForAnchor(it, false) }
            val lightColor = anchor?.let { nearestLightnessColorForAnchor(it, true) }
            dark.setBackgroundColor(darkColor?.let { Color.rgb(it.r, it.g, it.b) } ?: labScaleColor(state.r, state.g, state.b, 0.78))
            current.setBackgroundColor(Color.rgb(state.r, state.g, state.b))
            light.setBackgroundColor(lightColor?.let { Color.rgb(it.r, it.g, it.b) } ?: labScaleColor(state.r, state.g, state.b, 1.22))
            dark.text = "${darkColor?.let(::displayName) ?: "Tmavší"}\n${darkColor?.let { "RGB ${it.r}, ${it.g}, ${it.b}" } ?: ""}"
            current.text = "${anchor?.let(::displayName) ?: "Aktuální"}\nRGB ${state.r}, ${state.g}, ${state.b}"
            light.text = "${lightColor?.let(::displayName) ?: "Světlejší"}\n${lightColor?.let { "RGB ${it.r}, ${it.g}, ${it.b}" } ?: ""}"
            val bright = (state.r * 299 + state.g * 587 + state.b * 114) / 1000
            listOf(dark, current, light).forEach { it.setTextColor(if (bright < 140) Color.WHITE else Color.BLACK) }
            updatePreviewAndData()
        }
        fun selectNeighborColor(target: NamedColor?) {
            if (target == null) return
            suppressRefresh = true
            setRgb(target.r, target.g, target.b)
            state.nearest = target
            state.tolerance = toleranceForColor(target)
            suppressRefresh = false
            refreshUi()
        }

        dark.setOnClickListener {
            selectNeighborColor(state.nearest?.let { nearestLightnessColorForAnchor(it, false) })
        }
        light.setOnClickListener {
            selectNeighborColor(state.nearest?.let { nearestLightnessColorForAnchor(it, true) })
        }

        fun applyLaboratoryMeasurement(rr: Int, gg: Int, bb: Int) {
            val r = rr.coerceIn(0, 255)
            val g = gg.coerceIn(0, 255)
            val b = bb.coerceIn(0, 255)
            val best = nearestColor(r, g, b)
            suppressRefresh = true
            setRgb(r, g, b)
            state.nearest = best
            state.tolerance = best?.let(::toleranceForColor)
            sliderParts[0].seek.progress = r
            sliderParts[1].seek.progress = g
            sliderParts[2].seek.progress = b
            lSeek.progress = ColorMath.rgbToLab(r, g, b).l.roundToInt().coerceIn(0, 100)
            suppressRefresh = false
            if (best != null) {
                if (laboratoryHistory.size >= 3) laboratoryHistory.removeAt(0)
                laboratoryHistory.add(LabHistoryEntry(best, r, g, b))
            }
            refreshUi()
            updateHistoryUi()
            status.text = if (best != null) {
                val lab = ColorMath.rgbToLab(r, g, b)
                "Laboratoř: ${groupDisplayName(best)} • ΔE00 %.2f".format(ColorMath.deltaE00(lab, best.lab))
            } else "Laboratoř: měření přijato"
        }

        laboratoryMeasurementHandler = ::applyLaboratoryMeasurement
        updateHistoryUi()

        fun commitInput() {
            val r = rIn.text.toString().toIntOrNull() ?: state.r
            val g = gIn.text.toString().toIntOrNull() ?: state.g
            val b = bIn.text.toString().toIntOrNull() ?: state.b
            setRgb(r, g, b)
            state.nearest = nearestColor(state.r, state.g, state.b)
            state.tolerance = state.nearest?.let(::toleranceForColor)
            refreshUi()
        }

        val inputWatcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (updatingInputs) return
                val r = rIn.text.toString().toIntOrNull()
                val g = gIn.text.toString().toIntOrNull()
                val b = bIn.text.toString().toIntOrNull()
                if (r != null && g != null && b != null) {
                    setRgb(r, g, b)
                    state.nearest = nearestColor(state.r, state.g, state.b)
                    state.tolerance = state.nearest?.let(::toleranceForColor)
                    refreshUi()
                }
            }
            override fun afterTextChanged(s: Editable?) = Unit
        }
        rIn.addTextChangedListener(inputWatcher); gIn.addTextChangedListener(inputWatcher); bIn.addTextChangedListener(inputWatcher)
        listOf(rIn, gIn, bIn).forEach { it.setOnFocusChangeListener { _, has -> if (!has) commitInput() } }
        rIn.setOnEditorActionListener { _, _, _ -> commitInput(); false }
        gIn.setOnEditorActionListener { _, _, _ -> commitInput(); false }
        bIn.setOnEditorActionListener { _, _, _ -> commitInput(); false }

        for (i in 0..2) {
            sliderParts[i].seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (!fromUser || suppressRefresh) return
                    val old = intArrayOf(state.r, state.g, state.b)
                    val target = old.copyOf()
                    if (!lock.isChecked) {
                        target[i] = p
                    } else {
                        val delta = (p - old[i]).coerceIn(old.maxOf { -it }, old.minOf { 255 - it })
                        for (j in 0..2) target[j] = old[j] + delta
                    }
                    setRgb(target[0], target[1], target[2])
                    val anchor = state.nearest
                    if (anchor != null) {
                        val tol = state.tolerance ?: toleranceForColor(anchor).also { state.tolerance = it }
                        // Only the slider being dragged decides when the current
                        // shade changes.  The other channel tolerances are display
                        // ranges; they must not make the anchor jump while this
                        // slider is still inside its own range.  This is especially
                        // important in landscape and when the RGB lock moves all
                        // three channels together.
                        val channelOutside = when (i) {
                            0 -> state.r !in tol.rLo..tol.rHi
                            1 -> state.g !in tol.gLo..tol.gHi
                            else -> state.b !in tol.bLo..tol.bHi
                        }
                        if (channelOutside) {
                            val newAnchor = nearestColor(state.r, state.g, state.b)
                            state.nearest = newAnchor
                            state.tolerance = newAnchor?.let(::toleranceForColor)
                        }
                    } else {
                        val newAnchor = nearestColor(state.r, state.g, state.b)
                        state.nearest = newAnchor
                        state.tolerance = newAnchor?.let(::toleranceForColor)
                    }
                    refreshUi()
                }
                override fun onStartTrackingTouch(s: SeekBar?) = Unit
                override fun onStopTrackingTouch(s: SeekBar?) = Unit
            })
        }

        lSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (!fromUser || suppressRefresh) return

                val anchor = state.nearest ?: nearestColor(state.r, state.g, state.b) ?: return
                if (state.nearest == null) {
                    state.nearest = anchor
                    state.tolerance = toleranceForColor(anchor)
                }
                val tol = state.tolerance ?: toleranceForColor(anchor).also { state.tolerance = it }

                if (lock.isChecked) {
                    // Locked L uses the same common RGB movement as the RGB sliders: all
                    // channels move by the same delta, preserving their differences.
                    val old = intArrayOf(state.r, state.g, state.b)
                    val minDelta = -old.minOrNull()!!.toDouble()
                    val maxDelta = (255 - old.maxOrNull()!!).toDouble()
                    fun lightnessForDelta(delta: Double): Double {
                        val rr = (old[0] + delta).roundToInt().coerceIn(0, 255)
                        val gg = (old[1] + delta).roundToInt().coerceIn(0, 255)
                        val bb = (old[2] + delta).roundToInt().coerceIn(0, 255)
                        return ColorMath.rgbToLab(rr, gg, bb).l
                    }
                    val targetL = p.toDouble().coerceIn(0.0, 100.0)
                    val minL = lightnessForDelta(minDelta)
                    val maxL = lightnessForDelta(maxDelta)
                    val clampedL = targetL.coerceIn(minOf(minL, maxL), maxOf(minL, maxL))
                    var lo = minDelta
                    var hi = maxDelta
                    repeat(28) {
                        val mid = (lo + hi) / 2.0
                        if (lightnessForDelta(mid) < clampedL) lo = mid else hi = mid
                    }
                    val delta = ((lo + hi) / 2.0).coerceIn(minDelta, maxDelta)
                    setRgb(
                        (old[0] + delta).roundToInt().coerceIn(0, 255),
                        (old[1] + delta).roundToInt().coerceIn(0, 255),
                        (old[2] + delta).roundToInt().coerceIn(0, 255)
                    )

                    // With the L lock, L itself is the boundary that controls the
                    // shade transition.  RGB are being moved as a consequence of L;
                    // they must not independently force a new anchor and make the RGB
                    // tolerance boxes jump around.
                    val newL = ColorMath.rgbToLab(state.r, state.g, state.b).l
                    val lOutside = newL < tol.lLo || newL > tol.lHi
                    if (lOutside) {
                        // Keep the normal prediction algorithm. It changes only after the
                        // cached L tolerance is actually crossed; no prediction on micro-moves.
                        val newAnchor = nearestColor(state.r, state.g, state.b)
                        state.nearest = newAnchor
                        state.tolerance = newAnchor?.let(::toleranceForColor)
                    }
                    refreshUi()
                    return
                }

                // Unlocked L: independent lightness control. The current shade stays fixed
                // inside its cached L interval and changes only after crossing the boundary.
                val targetL = p.toDouble()
                var currentAnchor = anchor
                var range = Pair(tol.lLo, tol.lHi)
                var guard = 0
                while ((targetL < range.first || targetL > range.second) && guard++ < 20) {
                    val lighter = targetL > range.second
                    val next = nearestLightnessColorForAnchor(currentAnchor, lighter) ?: break
                    if (next == currentAnchor) break
                    currentAnchor = next
                    val nt = toleranceForColor(currentAnchor)
                    range = Pair(nt.lLo, nt.lHi)
                }
                state.nearest = currentAnchor
                state.tolerance = toleranceForColor(currentAnchor)
                val base = currentAnchor.lab
                val newRgb = ColorMath.labToRgb(targetL.coerceIn(0.0, 100.0), base.a, base.b)
                setRgb(newRgb[0], newRgb[1], newRgb[2])
                refreshUi()
            }
            override fun onStartTrackingTouch(s: SeekBar?) = Unit
            override fun onStopTrackingTouch(s: SeekBar?) = Unit
        })

        fun returnToHeld() {
            val held = laboratoryHeldPosition ?: return
            suppressRefresh = true
            setRgb(held.r, held.g, held.b)
            state.nearest = held.anchor
            state.tolerance = toleranceForColor(held.anchor)
            sliderParts[0].seek.progress = held.r
            sliderParts[1].seek.progress = held.g
            sliderParts[2].seek.progress = held.b
            lSeek.progress = ColorMath.rgbToLab(held.r, held.g, held.b).l.roundToInt().coerceIn(0, 100)
            suppressRefresh = false
            refreshUi()
        }

        fun updateHeldUi() {
            val held = laboratoryHeldPosition
            if (held == null) {
                heldLabel.text = "—"
                heldLabel.isEnabled = false
                heldLabel.setTextColor(Color.WHITE)
                heldLabel.background = aeroBackground(uiColor("menu", 0x44000000.toInt()), dp(14))
            } else {
                heldLabel.text = "${displayName(held.anchor)}\nRGB ${held.r}, ${held.g}, ${held.b}"
                heldLabel.isEnabled = true
                val lum = (held.r * 299 + held.g * 587 + held.b * 114) / 1000
                heldLabel.setTextColor(if (lum < 140) Color.WHITE else Color.BLACK)
                heldLabel.background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(Color.rgb(held.r, held.g, held.b))
                    setStroke(dp(1), if (lum < 140) 0x66FFFFFF else 0x66000000)
                    cornerRadius = dp(14).toFloat()
                }
            }
            heldLabel.alpha = if (held != null) 1f else 0.45f
            releaseHeldButton.isEnabled = held != null
            releaseHeldButton.alpha = if (held != null) 1f else 0.45f
        }

        holdButton.setOnClickListener {
            val anchor = state.nearest ?: nearestColor(state.r, state.g, state.b) ?: return@setOnClickListener
            laboratoryHeldPosition = HeldLabPosition(anchor, state.r, state.g, state.b)
            updateHeldUi()
        }

        heldLabel.setOnClickListener { returnToHeld() }

        createGroupButton.setOnClickListener {
            val source = laboratoryHeldPosition?.anchor ?: state.nearest ?: nearestColor(state.r, state.g, state.b)
            if (source == null) {
                Toast.makeText(this, "Nejdřív vyber barvu", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val input = EditText(this).apply {
                setSingleLine(true)
                hint = "Např. Bronco"
                setText(displayName(source))
                selectAll()
            }
            AlertDialog.Builder(this)
                .setTitle("Vytvořit skupinu")
                .setView(input)
                .setNegativeButton("Zrušit", null)
                .setPositiveButton("VYTVOŘIT") { _, _ ->
                    val groupName = input.text.toString().trim()
                    if (groupName.isEmpty()) return@setPositiveButton
                    val groups = loadLabGroups()
                    if (groups.any { it.name.equals(groupName, true) }) {
                        Toast.makeText(this, "Skupina už existuje", Toast.LENGTH_SHORT).show()
                    } else {
                        groups.add(LabGroup(groupName, linkedSetOf(colorKey(source))))
                        saveLabGroups(groups)
                        refreshUi()
                        Toast.makeText(this, "Skupina $groupName vytvořena", Toast.LENGTH_SHORT).show()
                    }
                }
                .show().also { stylePopup(it) }
        }

        addGroupButton.setOnClickListener {
            val target = state.nearest ?: nearestColor(state.r, state.g, state.b)
            if (target == null) {
                Toast.makeText(this, "Nejdřív vyber barvu", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val groups = loadLabGroups()
            if (groups.isEmpty()) {
                Toast.makeText(this, "Nejdřív vytvoř skupinu", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val names = groups.map { it.name }.toTypedArray()
            AlertDialog.Builder(this)
                .setTitle("Přidat ${displayName(target)} do skupiny")
                .setItems(names) { _, which ->
                    val group = groups.getOrNull(which) ?: return@setItems
                    group.members.add(colorKey(target))
                    saveLabGroups(groups)
                    refreshUi()
                    Toast.makeText(this, "${displayName(target)} přidána do ${group.name}", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Zrušit", null)
                .show().also { stylePopup(it) }
        }

        groupsButton.setOnClickListener { showLabGroups() }

        nearbyLButton.setOnClickListener {
            val anchor = state.nearest ?: nearestColor(state.r, state.g, state.b)
            if (anchor == null) {
                Toast.makeText(this, "Nejdřív vyber barvu", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val minL = maxOf(0.0, anchor.lab.l - 4.0)
            val maxL = minOf(100.0, anchor.lab.l + 4.0)
            val nearby = colors
                .asSequence()
                .filter { it != anchor && it.lab.l >= minL && it.lab.l <= maxL }
                .distinctBy { colorKey(it) }
                .sortedWith(compareBy<NamedColor> { kotlin.math.abs(it.lab.l - anchor.lab.l) }.thenBy { displayName(it) })
                .toList()

            if (nearby.isEmpty()) {
                Toast.makeText(this, "V okolí ±4 L nejsou další barvy", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val scroll = ScrollView(this)
            val list = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(6), dp(4), dp(6), dp(4))
            }
            nearby.forEach { candidate ->
                val row = Button(this).apply {
                    text = "${displayName(candidate)}\nRGB ${candidate.r}, ${candidate.g}, ${candidate.b}   L ${candidate.lab.l.roundToInt()}"
                    textSize = 12.5f
                    isAllCaps = false
                    setTypeface(typeface, android.graphics.Typeface.BOLD)
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(10), dp(5), dp(10), dp(5))
                    val lum = (candidate.r * 299 + candidate.g * 587 + candidate.b * 114) / 1000
                    setTextColor(if (lum < 140) Color.WHITE else Color.BLACK)
                    background = android.graphics.drawable.GradientDrawable().apply {
                        setColor(Color.rgb(candidate.r, candidate.g, candidate.b))
                        setStroke(dp(1), if (lum < 140) 0x66FFFFFF else 0x66000000)
                        cornerRadius = dp(12).toFloat()
                    }
                    setOnClickListener {
                        selectNeighborColor(candidate)
                        val groups = loadLabGroups()
                        if (groups.isEmpty()) {
                            Toast.makeText(this@MainActivity, "${displayName(candidate)} vybrána", Toast.LENGTH_SHORT).show()
                        } else {
                            val names = groups.map { it.name }.toTypedArray()
                            AlertDialog.Builder(this@MainActivity)
                                .setTitle("Přidat ${displayName(candidate)} do skupiny?")
                                .setItems(names) { _, which ->
                                    val selected = groups.getOrNull(which) ?: return@setItems
                                    selected.members.add(colorKey(candidate))
                                    saveLabGroups(groups)
                                    refreshUi()
                                    Toast.makeText(this@MainActivity, "${displayName(candidate)} přidána do ${selected.name}", Toast.LENGTH_SHORT).show()
                                }
                                .setNegativeButton("Jen vybrat", null)
                                .show().also { stylePopup(it) }
                            }
                        }
                }
                list.addView(row, LinearLayout.LayoutParams(-1, dp(58)).apply { bottomMargin = dp(5) })
            }
            scroll.addView(list)
            val dialog = AlertDialog.Builder(this)
                .setTitle("Odstíny ±4 L • ${displayName(anchor)}")
                .setView(scroll)
                .setNegativeButton("Zavřít", null)
                .create()
            dialog.show()
            stylePopup(dialog)
        }

        saveLabButton.setOnClickListener {
            val anchor = state.nearest ?: nearestColor(state.r, state.g, state.b)
            if (anchor != null) {
                setSaved(anchor, true)
                prefs.edit().putBoolean("saved_lab_${colorKey(anchor)}", true).apply()
                Toast.makeText(this, "Barva uložena do ULOŽENÉ BARVY jako LAB", Toast.LENGTH_SHORT).show()
            }
        }

        compareButton.setOnClickListener {
            val held = laboratoryHeldPosition
            if (held == null) {
                Toast.makeText(this, "Nejdřív podrž první barvu", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val current = state.nearest ?: nearestColor(state.r, state.g, state.b)
            val currentName = current?.let(::displayName) ?: "Neurčeno"
            val heldName = displayName(held.anchor)
            val dr = state.r - held.r
            val dg = state.g - held.g
            val db = state.b - held.b
            val heldLab = ColorMath.rgbToLab(held.r, held.g, held.b)
            val currentLab = ColorMath.rgbToLab(state.r, state.g, state.b)
            val dL = currentLab.l - heldLab.l
            val deltaE = ColorMath.deltaE00(heldLab, currentLab)

            val content = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(16), dp(4), dp(16), dp(4))
            }
            fun comparisonColorView(name: String, r: Int, g: Int, b: Int): TextView = TextView(this).apply {
                text = "$name\nRGB $r, $g, $b"
                textSize = 14f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                gravity = Gravity.CENTER
                setPadding(dp(8), dp(10), dp(8), dp(10))
                setTextColor(if ((r * 299 + g * 587 + b * 114) / 1000 < 140) Color.WHITE else Color.BLACK)
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(Color.rgb(r, g, b))
                    setStroke(dp(1), 0x66000000)
                    cornerRadius = dp(12).toFloat()
                }
            }
            content.addView(comparisonColorView("Podržená: $heldName", held.r, held.g, held.b), LinearLayout.LayoutParams(-1, dp(62)).apply { bottomMargin = dp(6) })
            content.addView(comparisonColorView("Aktuální: $currentName", state.r, state.g, state.b), LinearLayout.LayoutParams(-1, dp(62)).apply { bottomMargin = dp(10) })
            content.addView(TextView(this).apply {
                text = "Rozdíl RGB: R ${if (dr >= 0) "+$dr" else dr}, G ${if (dg >= 0) "+$dg" else dg}, B ${if (db >= 0) "+$db" else db}\n" +
                    "Rozdíl L: ${if (dL >= 0) "+%.1f".format(Locale.getDefault(), dL) else "%.1f".format(Locale.getDefault(), dL)}\n" +
                    "ΔE00: %.2f".format(Locale.getDefault(), deltaE)
                textSize = 14f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                setPadding(dp(4), dp(4), dp(4), dp(8))
            })

            AlertDialog.Builder(this)
                .setTitle("POROVNÁNÍ BAREV")
                .setView(content)
                .setPositiveButton("ZAVŘÍT", null)
                .show().also { stylePopup(it) }
        }

        releaseHeldButton.setOnClickListener {
            laboratoryHeldPosition = null
            updateHeldUi()
        }

        lock.setOnCheckedChangeListener { _, _ -> refreshUi() }

        // Quick color-name search in the upper-left corner. Suggestions update
        // while typing and selecting one immediately switches the Lab to it.
        val labSearchButton = TextView(this).apply {
            text = "🔍"
            textSize = uiSp("menu_icon_text_size", 23f, 10f, 40f)
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = aeroBackground(uiColor("menu", 0x66000000.toInt()), dp(30))
            elevation = dp(12).toFloat()
            contentDescription = "Hledat barvu"
        }
        labSearchButton.setOnClickListener {
            val dialog = AlertDialog.Builder(this).create()
            val searchBox = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(16), dp(12), dp(16), dp(8))
            }
            val searchInput = EditText(this).apply {
                hint = "Název barvy"
                inputType = InputType.TYPE_CLASS_TEXT
                setSingleLine(true)
                textSize = 16f
            }
            searchBox.addView(searchInput, LinearLayout.LayoutParams(-1, dp(48)))
            val list = ListView(this).apply {
                dividerHeight = dp(1)
                setPadding(0, dp(4), 0, 0)
            }
            searchBox.addView(list, LinearLayout.LayoutParams(-1, dp(330)))
            dialog.setView(searchBox)
            dialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Zavřít") { _, _ -> dialog.dismiss() }

            val all = colors.map { it to displayName(it) }
                .sortedBy { it.second.lowercase(Locale.getDefault()) }
            val shown = ArrayList(all)
            val adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1) {
                override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                    val v = super.getView(position, convertView, parent)
                    (v as TextView).apply {
                        textSize = 16f
                        setTextColor(Color.BLACK)
                        setPadding(dp(10), dp(7), dp(10), dp(7))
                    }
                    return v
                }
            }
            fun refreshSuggestions(queryRaw: String) {
                val q = queryRaw.trim().lowercase(Locale.getDefault())
                shown.clear()
                shown.addAll(if (q.isEmpty()) all.take(40) else all.filter { it.second.lowercase(Locale.getDefault()).contains(q) }.take(40))
                adapter.clear()
                shown.forEach { adapter.add(it.second) }
                adapter.notifyDataSetChanged()
            }
            list.adapter = adapter
            refreshSuggestions("")
            searchInput.addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { refreshSuggestions(s?.toString().orEmpty()) }
                override fun afterTextChanged(s: android.text.Editable?) = Unit
            })
            list.setOnItemClickListener { _, _, position, _ ->
                val selected = shown.getOrNull(position)?.first ?: return@setOnItemClickListener
                suppressRefresh = true
                setRgb(selected.r, selected.g, selected.b)
                state.nearest = selected
                state.tolerance = toleranceForColor(selected)
                sliderParts[0].seek.progress = selected.r
                sliderParts[1].seek.progress = selected.g
                sliderParts[2].seek.progress = selected.b
                lSeek.progress = ColorMath.rgbToLab(selected.r, selected.g, selected.b).l.roundToInt().coerceIn(0, 100)
                suppressRefresh = false
                refreshUi()
                dialog.dismiss()
            }
            dialog.show()
            stylePopup(dialog)
            dialog.window?.setLayout(
                (resources.displayMetrics.widthPixels * 0.88f).toInt(),
                (resources.displayMetrics.heightPixels * 0.58f).toInt()
            )
            searchInput.requestFocus()
            dialog.window?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE)
        }
        overlay.addView(labSearchButton, FrameLayout.LayoutParams(dp(58), dp(58)).apply {
            gravity = Gravity.TOP or Gravity.START
            setMargins(dp(12), dp(10), 0, 0)
        })

        updatePreviewAndData()
        updateHeldUi()
        refreshUi()
        laboratoryOverlay = overlay
        root.addView(overlay, FrameLayout.LayoutParams(-1, -1))
        // The Lab is intentionally non-scrollable. On shorter displays, compact the
        // complete column just enough to keep every control visible at once.
        overlay.post {
            val available = (overlay.height - dp(78)).coerceAtLeast(1)
            if (box.height > available) {
                val scale = (available.toFloat() / box.height.toFloat()).coerceIn(0.78f, 1f)
                box.pivotY = 0f
                box.scaleY = scale
            }
        }
    }

    private data class HeldLabPosition(
        val anchor: NamedColor,
        val r: Int,
        val g: Int,
        val b: Int
    )

    private data class LabHistoryEntry(
        val anchor: NamedColor,
        val r: Int,
        val g: Int,
        val b: Int
    )

    private data class LabTolerance(
        val rLo:Int, val rHi:Int,
        val gLo:Int, val gHi:Int,
        val bLo:Int, val bHi:Int,
        val lLo:Double, val lHi:Double
    )

    private data class LabUiState(
        var r:Int,var g:Int,var b:Int,var nearest:NamedColor?,var locked:Boolean,
        var tolerance:LabTolerance? = null
    )

    private fun channelTolerance(anchor: NamedColor, channel: Char): Int {
        val values = colors.filter {
            kotlin.math.abs(it.r-anchor.r)<=5 && kotlin.math.abs(it.g-anchor.g)<=5 && kotlin.math.abs(it.b-anchor.b)<=5
        }
        if(values.size<2) return 6
        val min=when(channel){'R'->values.minOf{it.r};'G'->values.minOf{it.g};else->values.minOf{it.b}}
        val max=when(channel){'R'->values.maxOf{it.r};'G'->values.maxOf{it.g};else->values.maxOf{it.b}}
        val cur=when(channel){'R'->anchor.r;'G'->anchor.g;else->anchor.b}
        return maxOf(2,maxOf(cur-min,max-cur))
    }

    private fun toleranceForColor(anchor: NamedColor): LabTolerance {
        val rt = channelTolerance(anchor, 'R')
        val gt = channelTolerance(anchor, 'G')
        val bt = channelTolerance(anchor, 'B')
        val lt = 4.0
        return LabTolerance(
            (anchor.r-rt).coerceAtLeast(0), (anchor.r+rt).coerceAtMost(255),
            (anchor.g-gt).coerceAtLeast(0), (anchor.g+gt).coerceAtMost(255),
            (anchor.b-bt).coerceAtLeast(0), (anchor.b+bt).coerceAtMost(255),
            maxOf(0.0, anchor.lab.l-lt), minOf(100.0, anchor.lab.l+lt)
        )
    }

    private fun labRangeText(value:Int,tol:Int):String = "${(value-tol).coerceAtLeast(0)}–${(value+tol).coerceAtMost(255)}"

    private fun nearestLightnessColorForAnchor(anchor: NamedColor, lighter: Boolean): NamedColor? {
        if (colors.isEmpty()) return null
        val target = anchor.lab
        return colors.asSequence()
            .filter { candidate: NamedColor -> candidate != anchor && if (lighter) candidate.lab.l > target.l + 0.5 else candidate.lab.l < target.l - 0.5 }
            .minByOrNull { candidate: NamedColor ->
                val hueDistance = ColorMath.deltaE00(target, candidate.lab)
                val lightnessDistance = kotlin.math.abs(candidate.lab.l - target.l)
                hueDistance * 3.0 + lightnessDistance
            }
    }

    private fun nearestLightnessColor(r: Int, g: Int, b: Int, lighter: Boolean): NamedColor? {
        return nearestLightnessColorForAnchor(nearestColor(r, g, b) ?: return null, lighter)
    }

    private fun labScaleColor(r:Int,g:Int,b:Int,scale:Double):Int = Color.rgb((r*scale).roundToInt().coerceIn(0,255),(g*scale).roundToInt().coerceIn(0,255),(b*scale).roundToInt().coerceIn(0,255))

    private fun updateToleranceLabels(state: LabUiState, box: LinearLayout) { /* live labels are refreshed by the laboratory slider block */ }

    private fun closeLaboratory(root: FrameLayout) {
        laboratoryOverlay?.let { root.removeView(it) }
        laboratoryOverlay = null
        laboratoryMeasurementHandler = null
    }

    private fun uiColor(prefix: String, default: Int): Int {
        val r = uiPrefs.getInt("${prefix}_r", Color.red(default))
        val g = uiPrefs.getInt("${prefix}_g", Color.green(default))
        val b = uiPrefs.getInt("${prefix}_b", Color.blue(default))
        val a = uiPrefs.getInt("${prefix}_a", Color.alpha(default))
        return Color.argb(a, r, g, b)
    }

    private fun applyUiSettings() {
        if (!::menuButtonRef.isInitialized) return
        val menuSize = uiInt("menu_size", 58, 44, 120)
        val rgbSize = uiInt("rgb_size", 62, 44, 120)
        val menuColor = uiColor("menu", 0x66000000)
        val rgbColor = uiColor("rgb", 0x66000000)
        menuButtonRef.background = aeroBackground(menuColor, dp(menuSize / 2))
        rgbButtonRef.background = aeroBackground(rgbColor, dp(rgbSize / 2))
        menuButtonRef.textSize = uiSp("menu_icon_text_size", 23f, 10f, 40f)
        rgbButtonRef.textSize = uiSp("rgb_icon_text_size", 13f, 10f, 30f)
        // The panel background belongs to the actual menu content. The ScrollView itself stays transparent.
        menuPanelRef.background = aeroBackground(uiColor("menu_panel", 0xD0181818.toInt()), dp(24))
        (menuScrollRef.layoutParams as? FrameLayout.LayoutParams)?.let { lp ->
            lp.width = dp(uiInt("menu_panel_width", 245, 180, 360))
            menuScrollRef.layoutParams = lp
        }
        val buttonColor = uiColor("menu_button", 0xA02D73B7.toInt())
        menuButtons.forEach {
            it.background = aeroBackground(buttonColor, dp(18))
            it.textSize = uiSp("menu_button_text_size", 13f, 10f, 28f)
        }
        (menuButtonRef.layoutParams as? FrameLayout.LayoutParams)?.let { lp ->
            lp.width = dp(menuSize); lp.height = dp(menuSize); menuButtonRef.layoutParams = lp
        }
        (rgbButtonRef.layoutParams as? FrameLayout.LayoutParams)?.let { lp ->
            lp.width = dp(rgbSize); lp.height = dp(rgbSize); rgbButtonRef.layoutParams = lp
        }
        (rgbPanelRef.layoutParams as? FrameLayout.LayoutParams)?.let { lp ->
            lp.width = dp(uiInt("rgb_panel_width", 310, 240, 440)); rgbPanelRef.layoutParams = lp
        }
        result.textSize = uiSp("main_text_size", if (resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE) 48f else 64f, 24f, 110f)
        rgbValues.textSize = uiSp("main_rgb_text_size", 20f, 10f, 36f)
        redSeek.parent?.let { parent ->
            if (parent is ViewGroup) {
                for (i in 0 until parent.childCount) {
                    val v = parent.getChildAt(i)
                    if (v is TextView && v.text.toString() in listOf("R", "G", "B")) {
                        v.textSize = uiSp("main_slider_text_size", 20f, 10f, 36f)
                    }
                }
            }
        }
        previewPopup?.let { view ->
            view.background = aeroBackground(uiColor("popup", 0xD0A6A6A6.toInt()), dp(24))
            fun refreshPreview(v: View) {
                when (v) {
                    is Button -> {
                        v.background = aeroBackground(uiColor("popup_button", 0xBFE0E0E0.toInt()), dp(18))
                        v.textSize = uiSp("popup_button_text_size", 13f, 10f, 28f)
                    }
                    is TextView -> v.textSize = uiSp("popup_text_size", 15f, 10f, 30f)
                }
                if (v is ViewGroup) for (i in 0 until v.childCount) refreshPreview(v.getChildAt(i))
            }
            refreshPreview(view)
        }
        cardsDialogRef?.let { if (it.isShowing) refreshCardsDialog() }
        databaseAdapterRef?.let { it.notifyDataSetChanged() }
    }

    private fun showUiSettings() {
        menuOpenState = false
        menuControlsRef.visibility = View.GONE
        menuButtonRef.text = "☰"
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(4), dp(10), dp(8))
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(root, ViewGroup.LayoutParams(-1, -1))
        }

        fun put(prefix: String, key: String, value: Int) {
            uiPrefs.edit().putInt("${prefix}_$key", value).apply()
        }
        fun color(prefix: String, def: Int) = uiColor(prefix, def)
        fun setColor(prefix: String, c: Int) = uiPrefs.edit()
            .putInt("${prefix}_r", Color.red(c)).putInt("${prefix}_g", Color.green(c))
            .putInt("${prefix}_b", Color.blue(c)).putInt("${prefix}_a", Color.alpha(c)).apply()

        fun previewFor(target: String?) {
            when (target) {
                "menu_panel", "menu_button" -> {
                    menuScrollRef.visibility = View.VISIBLE
                    menuControlsRef.visibility = View.VISIBLE
                    menuScrollRef.bringToFront()
                    menuButtonRef.bringToFront()
                }
                "rgb_panel" -> {
                    rgbPanelRef.visibility = View.VISIBLE
                    rgbPanelRef.bringToFront()
                }
                "popup", "popup_button", "database", "cards" -> showStylePreviewPopup()
            }
        }

        // One compact, expandable setting. The slider is hidden until the user opens it.
        fun setting(
            label: String,
            min: Int,
            max: Int,
            initial: Int,
            resetValue: Int,
            reset: () -> Unit,
            change: (Int) -> Unit,
            preview: String? = null
        ): LinearLayout {
            val outer = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(4), dp(1), dp(4), dp(1))
            }
            val head = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = aeroBackground(0x18000000, dp(12))
                setPadding(dp(8), 0, dp(4), 0)
            }
            val arrow = TextView(this).apply {
                text = "›"
                textSize = 18f
                setTextColor(Color.BLACK)
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(dp(22), dp(36))
            }
            val title = TextView(this).apply {
                text = label
                textSize = 13f
                setTextColor(Color.BLACK)
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, dp(36), 1f)
            }
            var seek: SeekBar? = null
            val resetButton = Button(this).apply {
                text = "↶"
                textSize = 12f
                minWidth = 0
                minimumWidth = 0
                setPadding(0, 0, 0, 0)
                layoutParams = LinearLayout.LayoutParams(dp(32), dp(30))
                setOnClickListener {
                    reset()
                    seek?.progress = (resetValue - min).coerceIn(0, max - min)
                    applyUiSettings()
                    previewFor(preview)
                }
            }
            head.addView(arrow)
            head.addView(title)
            head.addView(resetButton)

            val sliderBox = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                visibility = View.GONE
                setPadding(dp(4), 0, dp(4), dp(2))
            }
            seek = SeekBar(this).apply {
                this.max = max - min
                progress = (initial.coerceIn(min, max) - min)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                        if (fromUser) change(p + min)
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) {
                        startLivePreview(label, preview, outer, s)
                    }
                    override fun onStopTrackingTouch(s: SeekBar?) {
                        stopLivePreview()
                    }
                })
            }
            sliderBox.addView(seek, LinearLayout.LayoutParams(-1, dp(42)))
            outer.addView(head)
            outer.addView(sliderBox)

            head.setOnClickListener {
                val open = sliderBox.visibility != View.VISIBLE
                sliderBox.visibility = if (open) View.VISIBLE else View.GONE
                arrow.text = if (open) "⌄" else "›"
            }
            return outer
        }

        fun section(titleText: String): Pair<LinearLayout, LinearLayout> {
            val holder = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, dp(4), 0, dp(4))
            }
            val head = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = aeroBackground(0x25000000, dp(16))
                setPadding(dp(10), 0, dp(6), 0)
            }
            val arrow = TextView(this).apply {
                text = "›"
                textSize = 21f
                setTextColor(Color.BLACK)
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(dp(28), dp(42))
            }
            head.addView(arrow)
            head.addView(TextView(this).apply {
                text = titleText
                textSize = 15f
                setTextColor(Color.BLACK)
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f)
            })
            val content = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                visibility = View.GONE
                setPadding(dp(4), dp(2), dp(4), 0)
            }
            holder.addView(head)
            holder.addView(content)
            head.setOnClickListener {
                val open = content.visibility != View.VISIBLE
                content.visibility = if (open) View.VISIBLE else View.GONE
                arrow.text = if (open) "⌄" else "›"
            }
            return holder to content
        }

        lateinit var settingToImpl: (LinearLayout, String, Int, Int, Int, Int, () -> Unit, (Int) -> Unit, String?) -> Unit

        fun addColor(content: LinearLayout, prefix: String, title: String, def: Int, preview: String) {
            val current = color(prefix, def)
            settingToImpl(content, "$title – PRŮHLEDNOST", 10, 100,
                Color.alpha(current) * 100 / 255, Color.alpha(def) * 100 / 255,
                { setColor(prefix, def) }, { v ->
                    val c = Color.argb(v * 255 / 100, Color.red(color(prefix, def)), Color.green(color(prefix, def)), Color.blue(color(prefix, def)))
                    setColor(prefix, c); applyUiSettings(); previewFor(preview)
                }, preview)
            settingToImpl(content, "$title – ČERVENÁ", 0, 255, Color.red(current), Color.red(def),
                { setColor(prefix, def) }, { v ->
                    val c0 = color(prefix, def)
                    setColor(prefix, Color.argb(Color.alpha(c0), v, Color.green(c0), Color.blue(c0))); applyUiSettings(); previewFor(preview)
                }, preview)
            settingToImpl(content, "$title – ZELENÁ", 0, 255, Color.green(current), Color.green(def),
                { setColor(prefix, def) }, { v ->
                    val c0 = color(prefix, def)
                    setColor(prefix, Color.argb(Color.alpha(c0), Color.red(c0), v, Color.blue(c0))); applyUiSettings(); previewFor(preview)
                }, preview)
            settingToImpl(content, "$title – MODRÁ", 0, 255, Color.blue(current), Color.blue(def),
                { setColor(prefix, def) }, { v ->
                    val c0 = color(prefix, def)
                    setColor(prefix, Color.argb(Color.alpha(c0), Color.red(c0), Color.green(c0), v)); applyUiSettings(); previewFor(preview)
                }, preview)
        }

        // Helper kept outside addColor so every setting can live in a category content panel.
        fun addSetting(content: LinearLayout, view: LinearLayout) {
            content.addView(view, LinearLayout.LayoutParams(-1, -2))
        }

        settingToImpl = {
            content: LinearLayout,
            label: String,
            min: Int,
            max: Int,
            initial: Int,
            resetValue: Int,
            reset: () -> Unit,
            change: (Int) -> Unit,
            preview: String?
            -> addSetting(content, setting(label, min, max, initial, resetValue, reset, change, preview))
        }

        // Export/storage settings are kept outside the appearance tree.
        val (exportHolder, exportContent) = section("EXPORT / ÚLOŽIŠTĚ")
        root.addView(exportHolder)

        val pathRow = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(6), dp(4), dp(6), dp(6))
        }
        pathRow.addView(TextView(this).apply {
            text = "CESTA PRO EXPORT"
            textSize = 13f
            setTextColor(Color.BLACK)
        })
        val pathInput = EditText(this).apply {
            setSingleLine(true)
            hint = exportPathDefault
            setText(exportPrefs.getString("path", exportPathDefault))
            inputType = InputType.TYPE_CLASS_TEXT
            setTextColor(Color.BLACK)
            setHintTextColor(0x88000000.toInt())
            background = aeroBackground(0x22000000, dp(12))
            setPadding(dp(10), 0, dp(10), 0)
        }
        pathRow.addView(pathInput, LinearLayout.LayoutParams(-1, dp(42)).apply { bottomMargin = dp(5) })

        val savePathButton = makePopupButton("ULOŽIT CESTU")
        val chooseFolderButton = makePopupButton("VYBRAT SLOŽKU")
        val allFilesButton = makePopupButton("POVOLIT PŘÍSTUP KE VŠEM SOUBORŮM")
        val pathButtons = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(savePathButton, LinearLayout.LayoutParams(-1, dp(40)).apply { bottomMargin = dp(5) })
            addView(chooseFolderButton, LinearLayout.LayoutParams(-1, dp(40)).apply { bottomMargin = dp(5) })
            addView(allFilesButton, LinearLayout.LayoutParams(-1, dp(40)))
        }
        pathRow.addView(pathButtons)
        exportContent.addView(pathRow)

        savePathButton.setOnClickListener {
            val path = pathInput.text.toString().trim().ifBlank { exportPathDefault }
            exportPrefs.edit().putString("path", path).apply()
            Toast.makeText(this, "Cesta uložena: $path", Toast.LENGTH_SHORT).show()
        }
        chooseFolderButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }
            startActivityForResult(intent, exportTreeRequestCode)
        }
        allFilesButton.setOnClickListener { requestAllFilesAccess() }

        val (appearanceHolder, appearance) = section("VZHLED")
        root.addView(appearanceHolder)

        fun addSize(content: LinearLayout, label: String, prefix: String, default: Int, preview: String) {
            addSetting(content, setting(label, 44, 100, uiPrefs.getInt("${prefix}_size", default), default,
                { put(prefix, "size", default); applyUiSettings() },
                { put(prefix, "size", it); applyUiSettings() }, preview))
        }

        val (menuHolder, menuContent) = section("MENU")
        appearance.addView(menuHolder)
        addSize(menuContent, "VELIKOST IKONY MENU", "menu", 58, "menu")
        addColor(menuContent, "menu", "MENU IKONA", 0x66000000, "menu")
        addSetting(menuContent, setting("VELIKOST TEXTU TLAČÍTEK MENU", 10, 28, uiInt("menu_button_text_size", 13, 10, 28), 13,
            { put("menu", "button_text_size", 13); applyUiSettings() }, { put("menu", "button_text_size", it); applyUiSettings() }, "menu_button"))

        val (menuPanelHolder, menuPanelContent) = section("VYSOUVACÍ MENU")
        appearance.addView(menuPanelHolder)
        addSetting(menuPanelContent, setting("ŠÍŘKA VYSOUVACÍHO MENU", 180, 360, uiInt("menu_panel_width", 245, 180, 360), 245,
            { put("menu_panel", "width", 245); applyUiSettings() }, { put("menu_panel", "width", it); applyUiSettings() }, "menu_panel"))
        addColor(menuPanelContent, "menu_panel", "VYSOUVACÍ MENU", 0xD0181818.toInt(), "menu_panel")

        val (menuButtonHolder, menuButtonContent) = section("TLAČÍTKA MENU")
        appearance.addView(menuButtonHolder)
        addColor(menuButtonContent, "menu_button", "TLAČÍTKA MENU", 0xA02D73B7.toInt(), "menu_button")

        val (rgbHolder, rgbContent) = section("RGB")
        appearance.addView(rgbHolder)
        addSize(rgbContent, "VELIKOST IKONY RGB", "rgb", 62, "rgb")
        addColor(rgbContent, "rgb", "RGB IKONA", 0x66000000, "rgb")

        val (rgbPanelHolder, rgbPanelContent) = section("RGB VYSOUVACÍ OKNO")
        appearance.addView(rgbPanelHolder)
        addSetting(rgbPanelContent, setting("ŠÍŘKA RGB OKNA", 240, 440, uiInt("rgb_panel_width", 310, 240, 440), 310,
            { put("rgb_panel", "width", 310); applyUiSettings() }, { put("rgb_panel", "width", it); applyUiSettings() }, "rgb_panel"))
        addColor(rgbPanelContent, "rgb_panel", "RGB VYSOUVACÍ OKNO", 0xD0181818.toInt(), "rgb_panel")

        val (mainHolder, mainContent) = section("HLAVNÍ OBRAZOVKA")
        appearance.addView(mainHolder)
        addSetting(mainContent, setting("VELIKOST HLAVNÍHO TEXTU", 24, 110, uiInt("main_text_size", 64, 24, 110), 64,
            { put("main", "text_size", 64); applyUiSettings() },
            { put("main", "text_size", it); applyUiSettings() }, "main"))
        addSetting(mainContent, setting("VELIKOST RGB TEXTU", 10, 36, uiInt("main_rgb_text_size", 20, 10, 36), 20,
            { put("main", "rgb_text_size", 20); applyUiSettings() },
            { put("main", "rgb_text_size", it); applyUiSettings() }, "main"))
        addSetting(mainContent, setting("VELIKOST R/G/B TEXTU", 10, 36, uiInt("main_slider_text_size", 20, 10, 36), 20,
            { put("main", "slider_text_size", 20); applyUiSettings() },
            { put("main", "slider_text_size", it); applyUiSettings() }, "main"))

        val (cardHolder, cardContent) = section("KARTY")
        appearance.addView(cardHolder)
        addSetting(cardContent, setting("VELIKOST TEXTU KART", 10, 24, uiInt("card_text_size", 14, 10, 24), 14,
            { put("card", "text_size", 14) }, { put("card", "text_size", it) }, "cards"))
        addSetting(cardContent, setting("VELIKOST TEXTU BUNĚK", 8, 20, uiInt("card_cell_text_size", 10, 8, 20), 10,
            { put("card", "cell_text_size", 10) }, { put("card", "cell_text_size", it) }, "cards"))
        addSetting(cardContent, setting("VÝŠKA TLAČÍTEK KART", 28, 70, uiInt("card_button_height", 38, 28, 70), 38,
            { put("card", "button_height", 38) }, { put("card", "button_height", it) }, "cards"))
        addSetting(cardContent, setting("VÝŠKA BUNĚK", 48, 110, uiInt("card_cell_height", 82, 48, 110), 82,
            { put("card", "cell_height", 82) }, { put("card", "cell_height", it) }, "cards"))

        val (dbHolder, dbContent) = section("DATABÁZE")
        appearance.addView(dbHolder)
        addSetting(dbContent, setting("VELIKOST TEXTU DATABÁZE", 10, 24, uiInt("db_text_size", 15, 10, 24), 15,
            { put("db", "text_size", 15) }, { put("db", "text_size", it) }, "database"))
        addSetting(dbContent, setting("ŠÍŘKA TLAČÍTEK DATABÁZE", 60, 130, uiInt("db_button_width", 92, 60, 130), 92,
            { put("db", "button_width", 92) }, { put("db", "button_width", it) }, "database"))
        addSetting(dbContent, setting("ŠÍŘKA OKNA DATABÁZE", 75, 100, uiInt("db_dialog_width", 94, 75, 100), 94,
            { put("db", "dialog_width", 94) }, { put("db", "dialog_width", it) }, "database"))
        addSetting(dbContent, setting("VÝŠKA OKNA DATABÁZE", 60, 95, uiInt("db_dialog_height", 88, 60, 95), 88,
            { put("db", "dialog_height", 88) }, { put("db", "dialog_height", it) }, "database"))

        val (popupHolder, popupContent) = section("OSTATNÍ VYSOUVACÍ OKNA")
        appearance.addView(popupHolder)
        addColor(popupContent, "popup", "OSTATNÍ VYSOUVACÍ OKNA", 0xD0A6A6A6.toInt(), "popup")

        val (popupButtonHolder, popupButtonContent) = section("TLAČÍTKA V OKNECH")
        appearance.addView(popupButtonHolder)
        addColor(popupButtonContent, "popup_button", "TLAČÍTKA V OKNECH", 0xBFE0E0E0.toInt(), "popup_button")
        addSetting(popupButtonContent, setting("VELIKOST TEXTU TLAČÍTEK", 10, 28, uiInt("popup_button_text_size", 13, 10, 28), 13,
            { put("popup_button", "text_size", 13); applyUiSettings() }, { put("popup_button", "text_size", it); applyUiSettings(); previewFor("popup_button") }, "popup_button"))
        addSetting(popupContent, setting("VELIKOST TEXTU V OKNECH", 10, 30, uiInt("popup_text_size", 15, 10, 30), 15,
            { put("popup", "text_size", 15); applyUiSettings() }, { put("popup", "text_size", it); applyUiSettings(); previewFor("popup") }, "popup"))

        previewScroll = scroll
        previewBox = root
        val dialog = AlertDialog.Builder(this)
            .setTitle("NASTAVENÍ")
            .setView(scroll)
            .setPositiveButton("HOTOVO", null)
            .create()
        settingsDialog = dialog
        dialog.setOnDismissListener {
            stopLivePreview()
            menuPanelRef.visibility = View.GONE
            menuButtonRef.text = "☰"
            settingsDialog = null
        }
        dialog.show()
        stylePopup(dialog)
        dialog.window?.setLayout(-1, (resources.displayMetrics.heightPixels * 0.82f).toInt())
    }

    private fun startLivePreview(label: String, target: String?, activeRow: View, seek: SeekBar?) {
        val dialog = settingsDialog ?: return
        previewActiveRow = activeRow
        previewHiddenRows.clear()

        // Hide everything except the actual slider and its required parent chain.
        // This keeps the live preview clean even with nested expandable sections.
        previewBox?.let { box ->
            fun isAncestorOf(view: View, child: View): Boolean {
                var p = child.parent
                while (p is View) {
                    if (p === view) return true
                    p = p.parent
                }
                return false
            }
            fun hideTree(parent: ViewGroup) {
                for (i in 0 until parent.childCount) {
                    val child = parent.getChildAt(i)
                    if (child === seek || isAncestorOf(child, seek ?: activeRow)) {
                        if (child is ViewGroup) hideTree(child)
                    } else {
                        if (child.visibility != View.GONE) {
                            previewHiddenRows.add(child)
                            child.visibility = View.GONE
                        }
                    }
                }
            }
            hideTree(box)
            activeRow.visibility = View.VISIBLE
            seek?.visibility = View.VISIBLE
        }

        dialog.window?.setDimAmount(0f)
        dialog.window?.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.visibility = View.GONE
        previewMenuWasVisible = menuOpenState
        previewRgbWasVisible = rgbPanelRef.visibility == View.VISIBLE
        previewForLiveTarget(target)
        seek?.post {
            val y = (seek.parent as? View)?.top ?: activeRow.top
            previewScroll?.scrollTo(0, (y - dp(80)).coerceAtLeast(0))
        }
    }

    private fun stopLivePreview() {
        previewHiddenRows.forEach { it.visibility = View.VISIBLE }
        previewHiddenRows.clear()
        previewActiveRow = null
        previewPopup?.let { mainRootRef.removeView(it) }
        previewPopup = null
        menuOpenState = previewMenuWasVisible
        menuControlsRef.visibility = if (previewMenuWasVisible) View.VISIBLE else View.GONE
        menuScrollRef.visibility = View.VISIBLE
        menuButtonRef.text = if (menuOpenState) "×" else "☰"
        rgbPanelRef.visibility = if (previewRgbWasVisible) View.VISIBLE else View.GONE
        previewMenuWasVisible = false
        previewRgbWasVisible = false
        settingsDialog?.let { dialog ->
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.visibility = View.VISIBLE
            dialog.window?.setBackgroundDrawable(
                aeroBackground(uiColor("popup", 0xD0A6A6A6.toInt()), dp(24))
            )
            dialog.window?.setDimAmount(0.10f)
            stylePopup(dialog)
        }
    }

    private fun previewForLiveTarget(target: String?) {
        when (target) {
            "menu_panel", "menu_button" -> {
                menuScrollRef.visibility = View.VISIBLE
                menuControlsRef.visibility = View.VISIBLE
                menuScrollRef.bringToFront()
                menuButtonRef.bringToFront()
            }
            "rgb_panel" -> rgbPanelRef.visibility = View.VISIBLE
            "popup", "popup_button", "database", "cards" -> showStylePreviewPopup()
        }
    }

    private fun showStylePreviewPopup() {
        if (previewPopup != null) {
            applyUiSettings()
            return
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = aeroBackground(uiColor("popup", 0xD0A6A6A6.toInt()), dp(24))
            elevation = dp(18).toFloat()
        }
        box.addView(TextView(this).apply {
            text = "ŽIVÝ NÁHLED OKNA"
            tag = "preview_popup_text"
            textSize = uiSp("popup_text_size", 15f, 10f, 30f)
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
        })
        box.addView(TextView(this).apply {
            text = "Databáze barev"
            tag = "preview_popup_text"
            textSize = uiSp("popup_text_size", 15f, 10f, 30f)
            setTextColor(Color.BLACK)
            setPadding(dp(4), dp(8), dp(4), dp(4))
        })
        val dbRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = aeroBackground(0x22000000, dp(12))
            setPadding(dp(5), dp(4), dp(5), dp(4))
        }
        dbRow.addView(TextView(this).apply {
            text = "Aero Blue\nRGB 201,255,229"
            tag = "preview_popup_text"
            textSize = uiSp("popup_text_size", 15f, 10f, 30f)
            setTextColor(Color.BLACK)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        })
        dbRow.addView(makePopupButton("ULOŽIT"), LinearLayout.LayoutParams(dp(78), dp(40)))
        dbRow.addView(makePopupButton("NÁZEV"), LinearLayout.LayoutParams(dp(78), dp(40)))
        box.addView(dbRow)

        box.addView(TextView(this).apply {
            text = "Karty"
            tag = "preview_popup_text"
            textSize = uiSp("popup_text_size", 15f, 10f, 30f)
            setTextColor(Color.BLACK)
            setPadding(dp(4), dp(8), dp(4), dp(4))
        })
        val cardHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = aeroBackground(0x22000000, dp(12))
            setPadding(dp(7), dp(5), dp(7), dp(5))
        }
        cardHeader.addView(TextView(this).apply {
            text = "▶  JEBEA"
            tag = "preview_popup_text"
            textSize = uiSp("popup_text_size", 15f, 10f, 30f)
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(Color.BLACK)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        })
        cardHeader.addView(TextView(this).apply {
            text = "1: 25.09.2026\n2: —"
            tag = "preview_popup_text"
            textSize = uiSp("popup_text_size", 15f, 10f, 30f)
            gravity = Gravity.CENTER_VERTICAL or Gravity.END
            setTextColor(Color.BLACK)
        })
        box.addView(cardHeader)
        box.addView(makePopupButton("EDITOVAT KARTU"), LinearLayout.LayoutParams(-1, dp(40)).apply { topMargin = dp(5) })
        box.addView(makePopupButton("SMAZAT KARTU"), LinearLayout.LayoutParams(-1, dp(40)).apply { topMargin = dp(5) })

        val lp = FrameLayout.LayoutParams(dp(350), -2).apply { gravity = Gravity.CENTER }
        mainRootRef.addView(box, lp)
        previewPopup = box
        applyUiSettings()
    }

    private fun stylePopupIfOpen() { }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun aeroBackground(color: Int, radius: Int): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
            setStroke(dp(1), 0x33FFFFFF)
        }

    private fun makePopupButton(label: String): Button = Button(this).apply {
        text = label
        textSize = uiSp("popup_button_text_size", 13f, 10f, 28f)
        setTextColor(Color.BLACK)
        background = aeroBackground(uiColor("popup_button", 0xBFE0E0E0.toInt()), dp(18))
        stateListAnimator = null
        minWidth = 0
        minimumWidth = 0
        setPadding(dp(8), 0, dp(8), 0)
    }

    private fun makeAeroButton(label: String): Button = Button(this).apply {
        text = label.uppercase(Locale.getDefault())
        textSize = uiSp("menu_button_text_size", 13f, 10f, 28f)
        setTextColor(Color.WHITE)
        isAllCaps = false
        background = aeroBackground(0xA02D73B7.toInt(), dp(18))
        stateListAnimator = null
        elevation = dp(2).toFloat()
        setPadding(dp(8), 0, dp(8), 0)
    }

    private data class CardCell(var r: Int = 0, var g: Int = 0, var b: Int = 0, var name: String = "", var filled: Boolean = false)
    private data class CardRow(var date: String = "", val cells: MutableList<CardCell> = MutableList(5) { CardCell() })
    private data class ColorCard(var id: String, val rows: MutableList<CardRow> = mutableListOf(CardRow(), CardRow()))

    private fun loadCards(): MutableList<ColorCard> {
        val result = mutableListOf<ColorCard>()
        val raw = cardsPrefs.getString("cards_json", "[]") ?: "[]"
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val card = ColorCard(o.optString("id"))
                val rows = o.optJSONArray("rows") ?: JSONArray()
                for (ri in 0 until 2) {
                    val row = CardRow()
                    if (ri < rows.length()) {
                        val ro = rows.getJSONObject(ri)
                        row.date = ro.optString("date")
                        val cells = ro.optJSONArray("cells") ?: JSONArray()
                        for (ci in 0 until minOf(5, cells.length())) {
                            val co = cells.getJSONObject(ci)
                            row.cells[ci] = CardCell(
                                co.optInt("r", 0), co.optInt("g", 0), co.optInt("b", 0),
                                co.optString("name"), co.optBoolean("filled", false)
                            )
                        }
                    }
                    card.rows[ri] = row
                }
                if (card.id.isNotBlank()) result.add(card)
            }
        } catch (_: Exception) {}
        return result
    }

    private fun saveCards(cards: List<ColorCard>) {
        val arr = JSONArray()
        cards.forEach { card ->
            val o = JSONObject().put("id", card.id)
            val rows = JSONArray()
            card.rows.take(2).forEach { row ->
                val ro = JSONObject().put("date", row.date)
                val cells = JSONArray()
                row.cells.take(5).forEach { c ->
                    cells.put(JSONObject()
                        .put("r", c.r).put("g", c.g).put("b", c.b)
                        .put("name", c.name).put("filled", c.filled))
                }
                ro.put("cells", cells)
                rows.put(ro)
            }
            o.put("rows", rows)
            arr.put(o)
        }
        cardsPrefs.edit().putString("cards_json", arr.toString()).apply()
    }

    private fun todayString(): String =
        java.text.SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(java.util.Date())

    private fun firstEmptyCell(row: CardRow): Int = row.cells.indexOfFirst { !it.filled }

    private fun findCard(cards: List<ColorCard>, id: String): ColorCard? =
        cards.firstOrNull { it.id.equals(id.trim(), ignoreCase = true) }

    private fun recordMeasurementToActiveCard(r: Int, g: Int, b: Int, name: String?) {
        val id = activeCardId ?: return
        val cards = loadCards()
        val card = findCard(cards, id) ?: return
        var rowIndex = firstEmptyCell(card.rows[0]).let { if (it >= 0) 0 else 1 }
        val row = card.rows[rowIndex]
        val slot = firstEmptyCell(row)
        if (slot < 0) {
            if (rowIndex == 0 && firstEmptyCell(card.rows[1]) >= 0) {
                rowIndex = 1
            } else {
                runOnUiThread { status.text = "Karta $id má už všech 10 měření vyplněných" }
                return
            }
        }
        val targetRow = card.rows[rowIndex]
        val targetSlot = firstEmptyCell(targetRow)
        if (targetRow.date.isBlank()) targetRow.date = todayString()
        val bestName = name ?: nearestColor(r, g, b)?.let(::displayName) ?: ""
        targetRow.cells[targetSlot] = CardCell(r, g, b, bestName, true)
        saveCards(cards)
        runOnUiThread {
            refreshCardsDialog()
            status.text = "Karta $id • ${rowIndex + 1}. řádek • místo ${targetSlot + 1} uloženo"
        }
    }

    private fun stylePopup(dialog: AlertDialog) {
        dialog.window?.setBackgroundDrawable(aeroBackground(uiColor("popup", 0xD0A6A6A6.toInt()), dp(24)))
        dialog.window?.setDimAmount(0.10f)

        fun styleView(v: View) {
            when (v) {
                is Button -> {
                    v.setTextColor(Color.BLACK)
                    v.textSize = uiSp("popup_button_text_size", 13f, 10f, 28f)
                    v.background = aeroBackground(uiColor("popup_button", 0xBFE0E0E0.toInt()), dp(18))
                    v.stateListAnimator = null
                }
                is EditText -> {
                    v.setTextColor(Color.BLACK)
                    v.setHintTextColor(0x99000000.toInt())
                }
                is TextView -> {
                    v.setTextColor(Color.BLACK)
                    if (v !is EditText) v.textSize = uiSp("popup_text_size", v.textSize, 10f, 30f)
                }
            }
            if (v is ViewGroup) {
                for (i in 0 until v.childCount) styleView(v.getChildAt(i))
            }
        }

        dialog.window?.decorView?.let { styleView(it) }
        listOf(
            AlertDialog.BUTTON_POSITIVE,
            AlertDialog.BUTTON_NEGATIVE,
            AlertDialog.BUTTON_NEUTRAL
        ).forEach { which ->
            dialog.getButton(which)?.apply {
                setTextColor(Color.BLACK)
                background = aeroBackground(uiColor("popup_button", 0xBFE0E0E0.toInt()), dp(18))
                stateListAnimator = null
            }
        }
    }

    private fun showCards() {
        val dialog = AlertDialog.Builder(this).create()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(8))
        }
        root.addView(TextView(this).apply {
            text = "KARTY"
            textSize = 22f
            setPadding(0, 0, 0, dp(8))
        })

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val idInput = EditText(this).apply {
            hint = "ID karty"
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT
        }
        val newButton = makePopupButton("NOVÁ KARTA")
        val exportButton = makePopupButton("EXPORT")
        top.addView(idInput, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(newButton, LinearLayout.LayoutParams(dp(118), -2))
        top.addView(exportButton, LinearLayout.LayoutParams(dp(105), -2))
        root.addView(top)

        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        fun refresh() {
            list.removeAllViews()
            val cards = loadCards()
            if (cards.isEmpty()) {
                list.addView(TextView(this).apply {
                    text = "Zatím není vytvořená žádná karta."
                    textSize = 16f
                    setPadding(dp(4), dp(18), dp(4), dp(18))
                })
            }
            cards.forEach { card -> addCardView(list, card, dialog) }
        }

        newButton.setOnClickListener {
            val id = idInput.text.toString().trim()
            if (id.isBlank()) {
                idInput.error = "Zadej ID karty"
                return@setOnClickListener
            }
            val cards = loadCards()
            if (findCard(cards, id) != null) {
                idInput.error = "Toto ID už existuje"
                return@setOnClickListener
            }
            cards.add(ColorCard(id))
            saveCards(cards)
            activeCardId = id
            idInput.text.clear()
            refresh()
        }

        exportButton.setOnClickListener { exportCardsFiles() }

        cardsListContainer = list
        cardsDialogRef = dialog
        dialog.setView(root)
        dialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Zavřít") { _, _ -> dialog.dismiss() }
        dialog.setOnDismissListener {
            activeCardId = null
            status.text = "Připraveno"
            cardsDialogRef = null
            cardsListContainer = null
        }
        dialog.show()
        stylePopup(dialog)
        dialog.window?.setLayout(
            (resources.displayMetrics.widthPixels * uiInt("card_dialog_width", 98, 80, 100) / 100f).toInt(),
            (resources.displayMetrics.heightPixels * uiInt("card_dialog_height", 90, 60, 95) / 100f).toInt()
        )
        refresh()
    }

    private fun refreshCardsDialog() {
        val list = cardsListContainer ?: return
        val dialog = cardsDialogRef ?: return
        list.removeAllViews()
        val cards = loadCards()
        if (cards.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "Zatím není vytvořená žádná karta."
                textSize = 16f
                setPadding(dp(4), dp(18), dp(4), dp(18))
            })
        } else {
            cards.forEach { card -> addCardView(list, card, dialog) }
        }
    }

    private fun addCardView(list: LinearLayout, card: ColorCard, dialog: AlertDialog) {
        val cardBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(5), dp(5), dp(5), dp(8))
            background = aeroBackground(0x18000000, dp(16))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
            background = aeroBackground(0x22000000, dp(14))
        }
        val arrow = TextView(this).apply {
            text = "▶"
            textSize = 15f
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(dp(20), -2)
        }
        val idText = TextView(this).apply {
            text = card.id
            textSize = uiSp("card_text_size", 14f, 10f, 24f)
            setTypeface(null, android.graphics.Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        val headerDate = TextView(this).apply {
            text = "1: ${card.rows[0].date.ifBlank { "—" }}\n2: ${card.rows[1].date.ifBlank { "—" }}"
            textSize = uiSp("card_text_size", 14f, 10f, 24f)
            gravity = Gravity.CENTER_VERTICAL or Gravity.END
            setTextColor(Color.BLACK)
            setPadding(dp(4), 0, dp(6), 0)
            layoutParams = LinearLayout.LayoutParams(dp(112), -2)
        }
        val exportOne = makePopupButton("TXT")
        exportOne.setOnClickListener { exportCardTxt(card) }
        header.addView(arrow)
        header.addView(idText)
        header.addView(headerDate)
        header.addView(exportOne, LinearLayout.LayoutParams(dp(44), dp(uiInt("card_button_height", 38, 28, 70))))
        cardBox.addView(header)

        val details = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = if (activeCardId.equals(card.id, true)) View.VISIBLE else View.GONE
            setPadding(dp(3), dp(3), dp(3), dp(3))
        }

        val edit = makePopupButton("EDITOVAT KARTU")
        edit.setOnClickListener { editCardManually(card, dialog) }
        details.addView(edit, LinearLayout.LayoutParams(-1, dp(uiInt("card_button_height", 38, 28, 70))))

        for (ri in 0..1) {
            val row = card.rows[ri]
            val dateLine = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val date = TextView(this).apply {
                text = if (row.date.isBlank()) "${ri + 1}. měření – datum zatím není" else row.date
                textSize = uiSp("card_text_size", 14f, 10f, 24f)
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            }
            val dateEdit = makePopupButton("DATUM")
            dateEdit.setOnClickListener { editRowDate(card, ri, dialog) }
            dateLine.addView(date)
            dateLine.addView(dateEdit, LinearLayout.LayoutParams(dp(72), dp(uiInt("card_button_height", 38, 28, 70))))
            details.addView(dateLine)

            val cells = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                weightSum = 5f
            }
            for (ci in 0..4) {
                val c = row.cells[ci]
                val cell = TextView(this).apply {
                    gravity = Gravity.CENTER
                    textSize = uiSp("card_cell_text_size", 10f, 8f, 20f)
                    setPadding(dp(2), dp(5), dp(2), dp(5))
                    text = if (c.filled)
                        "${ci + 1}\nRGB\n${c.r},${c.g},${c.b}\n${c.name}"
                    else "${ci + 1}\nprázdné"
                    background = aeroBackground(if (c.filled) Color.rgb(c.r, c.g, c.b) else 0x22000000, dp(10))
                    val bright = if (c.filled) (c.r * 299 + c.g * 587 + c.b * 114) / 1000 else 255
                    setTextColor(if (bright < 140) Color.WHITE else Color.BLACK)
                    setOnClickListener { editCardCell(card, ri, ci, dialog) }
                }
                cells.addView(cell, LinearLayout.LayoutParams(0, dp(uiInt("card_cell_height", 82, 48, 110)), 1f).apply {
                    setMargins(dp(2), dp(2), dp(2), dp(2))
                })
            }
            details.addView(cells)
        }

        val del = makePopupButton("SMAZAT KARTU").apply {
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Smazat kartu?")
                    .setMessage("Karta ${card.id} a všech jejích 10 měření budou odstraněny.")
                    .setNegativeButton("Zrušit", null)
                    .setPositiveButton("SMAZAT") { _, _ ->
                        val cards = loadCards()
                        cards.removeAll { it.id.equals(card.id, true) }
                        saveCards(cards)
                        if (activeCardId.equals(card.id, true)) activeCardId = null
                        dialog.dismiss()
                        showCards()
                    }.show().also { stylePopup(it) }
            }
        }
        details.addView(del, LinearLayout.LayoutParams(-1, dp(uiInt("card_button_height", 38, 28, 70))))
        cardBox.addView(details)

        header.setOnClickListener {
            val open = details.visibility != View.VISIBLE
            details.visibility = if (open) View.VISIBLE else View.GONE
            arrow.text = if (open) "▼" else "▶"
            if (open) {
                activeCardId = card.id
                status.text = "Aktivní karta: ${card.id}"
            } else if (activeCardId.equals(card.id, true)) {
                activeCardId = null
            }
        }

        list.addView(cardBox)
        list.addView(View(this).apply { setBackgroundColor(0x55000000) },
            LinearLayout.LayoutParams(-1, dp(1)))
    }

    private fun exportCardTxt(card: ColorCard) {
        val sb = StringBuilder()
        sb.append("MCBP – KARTA\n")
        sb.append("ID: ${card.id}\n\n")
        card.rows.forEachIndexed { ri, row ->
            sb.append("${ri + 1}. MĚŘENÍ")
            if (row.date.isNotBlank()) sb.append(" – ${row.date}")
            sb.append("\n")
            row.cells.forEachIndexed { ci, c ->
                sb.append("Místo ${ci + 1}: ")
                if (c.filled) {
                    sb.append("RGB ${c.r},${c.g},${c.b}")
                    sb.append(" | HEX #%02X%02X%02X".format(c.r, c.g, c.b))
                    sb.append(" | ${c.name}")
                } else sb.append("prázdné")
                sb.append("\n")
            }
            sb.append("\n")
        }
        saveTextToMcbpFolder("MCBP_${safeFilePart(card.id)}.txt", sb.toString())
    }

    private fun exportCardsFiles() {
        val cards = loadCards()
        if (cards.isEmpty()) {
            Toast.makeText(this, "NENÍ CO EXPORTOVAT", Toast.LENGTH_SHORT).show()
            return
        }
        val txt = StringBuilder()
        val csv = StringBuilder()
        csv.append("KARTA;ŘÁDEK;DATUM;MÍSTO;R;G;B;HEX;NÁZEV\n")
        cards.forEachIndexed { i, card ->
            if (i > 0) txt.append("\n==============================\n\n")
            txt.append("MCBP – KARTA\nID: ${card.id}\n\n")
            card.rows.forEachIndexed { ri, row ->
                txt.append("${ri + 1}. MĚŘENÍ")
                if (row.date.isNotBlank()) txt.append(" – ${row.date}")
                txt.append("\n")
                row.cells.forEachIndexed { ci, c ->
                    txt.append("Místo ${ci + 1}: ")
                    if (c.filled) {
                        txt.append("RGB ${c.r},${c.g},${c.b}")
                        txt.append(" | HEX #%02X%02X%02X".format(c.r, c.g, c.b))
                        txt.append(" | ${c.name}")
                        csv.append(csvField(card.id)).append(';')
                            .append(ri + 1).append(';')
                            .append(csvField(row.date)).append(';')
                            .append(ci + 1).append(';')
                            .append(c.r).append(';').append(c.g).append(';').append(c.b).append(';')
                            .append("#%02X%02X%02X".format(c.r, c.g, c.b)).append(';')
                            .append(csvField(c.name)).append('\n')
                    } else txt.append("prázdné")
                    txt.append("\n")
                }
                txt.append("\n")
            }
        }
        val txtOk = saveTextToMcbpFolder("MCBP_KARTY.txt", txt.toString())
        val csvOk = saveTextToMcbpFolder("MCBP_KARTY.csv", csv.toString(), "text/csv")
        if (txtOk && csvOk) {
            Toast.makeText(this, "ULOŽENO DO /storage/emulated/0/MCBP", Toast.LENGTH_LONG).show()
        }
    }

    private fun csvField(value: String): String = "\"${value.replace("\"", "\"\"")}\""

    private fun safeFilePart(value: String): String = value.replace(Regex("[^A-Za-z0-9._-]"), "_").take(60)

    private fun requestAllFilesAccess() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 11)
        } else {
            Toast.makeText(this, "Přístup k úložišti už je povolený", Toast.LENGTH_SHORT).show()
        }
    }

    private fun hasAllFilesAccess(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.R || Environment.isExternalStorageManager()

    private fun exportPath(): String =
        exportPrefs.getString("path", exportPathDefault)?.trim().orEmpty().ifBlank { exportPathDefault }

    private fun saveTextViaTree(fileName: String, text: String, mime: String): Boolean {
        val tree = exportPrefs.getString("tree_uri", null)?.let(Uri::parse) ?: return false
        return try {
            val resolver = contentResolver
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(
                tree, DocumentsContract.getTreeDocumentId(tree)
            )
            resolver.query(children, arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME
            ), null, null, null)?.use { c ->
                val idIndex = c.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
                val nameIndex = c.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
                while (c.moveToNext()) {
                    if (nameIndex >= 0 && c.getString(nameIndex) == fileName && idIndex >= 0) {
                        val id = c.getString(idIndex)
                        val oldUri = DocumentsContract.buildDocumentUriUsingTree(tree, id)
                        try { DocumentsContract.deleteDocument(resolver, oldUri) } catch (_: Exception) {}
                        break
                    }
                }
            }
            val uri = DocumentsContract.createDocument(resolver, tree, mime, fileName) ?: return false
            resolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) } ?: return false
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun saveTextToMcbpFolder(fileName: String, text: String, mime: String = "text/plain"): Boolean {
        return try {
            // If the user granted full file access, honor the manually entered absolute path.
            if (hasAllFilesAccess()) {
                val dir = java.io.File(exportPath())
                if (!dir.exists() && !dir.mkdirs()) return false
                if (!dir.isDirectory) return false
                java.io.File(dir, fileName).writeText(text, Charsets.UTF_8)
                return true
            }

            // Otherwise use the user-selected SAF folder if one was granted.
            if (saveTextViaTree(fileName, text, mime)) return true

            // Last-resort scoped-storage export to the default MCBP folder on Android 10+.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val resolver = contentResolver
                val collection = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                val relativePath = "MCBP/"
                resolver.query(
                    collection,
                    arrayOf(MediaStore.MediaColumns._ID),
                    "${MediaStore.MediaColumns.DISPLAY_NAME}=? AND ${MediaStore.MediaColumns.RELATIVE_PATH}=?",
                    arrayOf(fileName, relativePath),
                    null
                )?.use { c ->
                    while (c.moveToNext()) {
                        val id = c.getLong(0)
                        resolver.delete(android.content.ContentUris.withAppendedId(collection, id), null, null)
                    }
                }
                val values = android.content.ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, mime)
                    put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath)
                }
                val uri = resolver.insert(collection, values) ?: return false
                val wrote = resolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)); true } ?: false
                if (!wrote) resolver.delete(uri, null, null)
                return wrote
            }

            val dir = java.io.File(Environment.getExternalStorageDirectory(), "MCBP")
            if (!dir.exists() && !dir.mkdirs()) return false
            java.io.File(dir, fileName).writeText(text, Charsets.UTF_8)
            true
        } catch (e: Exception) {
            Toast.makeText(this, "EXPORT SELHAL: ${e.message}", Toast.LENGTH_LONG).show()
            false
        }
    }

    private fun editRowDate(card: ColorCard, rowIndex: Int, dialog: AlertDialog) {
        val input = EditText(this).apply {
            setSingleLine(true)
            hint = "dd.MM.yyyy"
            setText(card.rows[rowIndex].date)
            inputType = InputType.TYPE_CLASS_TEXT
        }
        AlertDialog.Builder(this)
            .setTitle("Datum ${rowIndex + 1}. měření")
            .setView(input)
            .setNegativeButton("Zrušit", null)
            .setPositiveButton("ULOŽIT") { _, _ ->
                card.rows[rowIndex].date = input.text.toString().trim()
                val cards = loadCards()
                findCard(cards, card.id)?.rows?.set(rowIndex, card.rows[rowIndex])
                saveCards(cards)
                refreshCardsDialog()
            }.show().also { stylePopup(it) }
    }

    private fun editCardCell(card: ColorCard, rowIndex: Int, cellIndex: Int, dialog: AlertDialog) {
        val c = card.rows[rowIndex].cells[cellIndex]
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, dp(12), 0)
        }
        fun field(hint: String, value: String): EditText = EditText(this).apply {
            this.hint = hint; setSingleLine(true); setText(value)
        }
        val rIn = field("R 0–255", if (c.filled) c.r.toString() else "")
        val gIn = field("G 0–255", if (c.filled) c.g.toString() else "")
        val bIn = field("B 0–255", if (c.filled) c.b.toString() else "")
        val nIn = field("Název barvy", c.name)
        rIn.inputType = InputType.TYPE_CLASS_NUMBER
        gIn.inputType = InputType.TYPE_CLASS_NUMBER
        bIn.inputType = InputType.TYPE_CLASS_NUMBER
        box.addView(rIn); box.addView(gIn); box.addView(bIn); box.addView(nIn)
        AlertDialog.Builder(this)
            .setTitle("${rowIndex + 1}. řádek • místo ${cellIndex + 1}")
            .setView(box)
            .setNegativeButton("Zrušit", null)
            .setNeutralButton("VYMAZAT") { _, _ ->
                val cards = loadCards()
                val found = findCard(cards, card.id) ?: return@setNeutralButton
                found.rows[rowIndex].cells[cellIndex] = CardCell()
                saveCards(cards)
                refreshCardsDialog()
            }
            .setPositiveButton("ULOŽIT") { _, _ ->
                val rr = rIn.text.toString().toIntOrNull()?.coerceIn(0,255)
                val gg = gIn.text.toString().toIntOrNull()?.coerceIn(0,255)
                val bb = bIn.text.toString().toIntOrNull()?.coerceIn(0,255)
                if (rr == null || gg == null || bb == null) return@setPositiveButton
                val cards = loadCards()
                val found = findCard(cards, card.id) ?: return@setPositiveButton
                found.rows[rowIndex].cells[cellIndex] = CardCell(rr, gg, bb, nIn.text.toString().trim(), true)
                if (found.rows[rowIndex].date.isBlank()) found.rows[rowIndex].date = todayString()
                saveCards(cards)
                refreshCardsDialog()
            }.show().also { stylePopup(it) }
    }

    private fun editCardManually(card: ColorCard, dialog: AlertDialog) {
        // The card editor exposes ID and both measurement dates; individual cells are
        // editable from the card itself, including RGB and name.
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, dp(12), 0)
        }
        val idIn = EditText(this).apply {
            setSingleLine(true); setText(card.id); hint = "ID karty"
        }
        val d1 = EditText(this).apply {
            setSingleLine(true); setText(card.rows[0].date); hint = "Datum 1. měření"
        }
        val d2 = EditText(this).apply {
            setSingleLine(true); setText(card.rows[1].date); hint = "Datum 2. měření"
        }
        box.addView(idIn); box.addView(d1); box.addView(d2)
        AlertDialog.Builder(this)
            .setTitle("Upravit kartu")
            .setView(box)
            .setNegativeButton("Zrušit", null)
            .setPositiveButton("ULOŽIT") { _, _ ->
                val newId = idIn.text.toString().trim()
                if (newId.isBlank()) return@setPositiveButton
                val cards = loadCards()
                val found = findCard(cards, card.id) ?: return@setPositiveButton
                val clash = cards.any { it.id.equals(newId, true) && !it.id.equals(card.id, true) }
                if (clash) return@setPositiveButton
                found.id = newId
                found.rows[0].date = d1.text.toString().trim()
                found.rows[1].date = d2.text.toString().trim()
                if (activeCardId.equals(card.id, true)) activeCardId = newId
                saveCards(cards)
                refreshCardsDialog()
            }.show().also { stylePopup(it) }
    }

    private fun showColorDatabase() {
        if (colors.isEmpty()) {
            Toast.makeText(this, "Databáze barev ještě není načtená", Toast.LENGTH_SHORT).show()
            return
        }

        val dialog = AlertDialog.Builder(this).create()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(10))
        }
        box.addView(TextView(this).apply {
            text = "Databáze barev"
            textSize = 22f
            setPadding(0, 0, 0, dp(10))
        })

        val search = EditText(this).apply {
            hint = "RGB 255,0,0 / #FF0000 / název"
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
        }
        box.addView(search)

        val listView = ListView(this).apply {
            dividerHeight = dp(1)
            setPadding(0, dp(4), 0, 0)
        }
        box.addView(listView, LinearLayout.LayoutParams(-1, 0, 1f))
        dialog.setView(box)
        dialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Zavřít") { _, _ -> dialog.dismiss() }

        // Cache the displayed names once. The old implementation created ~2400 View
        // objects every time the database opened or the search text changed.
        // ListView recycles rows, so only the visible rows are actually created.
        val all = colors.map { it to displayName(it) }
            .sortedBy { it.second.lowercase(Locale.getDefault()) }

        val adapter = DatabaseAdapter(dialog, all)
        databaseDialogRef = dialog
        databaseAdapterRef = adapter
        dialog.setOnDismissListener { databaseDialogRef = null; databaseAdapterRef = null }
        listView.adapter = adapter

        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                adapter.filter(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: android.text.Editable?) = Unit
        })

        dialog.show()
        stylePopup(dialog)
        dialog.window?.setLayout(
            (resources.displayMetrics.widthPixels * uiInt("db_dialog_width", 94, 75, 100) / 100f).toInt(),
            (resources.displayMetrics.heightPixels * uiInt("db_dialog_height", 88, 60, 95) / 100f).toInt()
        )
    }

    private inner class DatabaseAdapter(
        private val dialog: AlertDialog,
        private val all: List<Pair<NamedColor, String>>
    ) : BaseAdapter() {
        private var shown = all

        override fun getCount(): Int = shown.size
        override fun getItem(position: Int): Pair<NamedColor, String> = shown[position]
        override fun getItemId(position: Int): Long = position.toLong()

        fun filter(queryRaw: String) {
            val q = queryRaw.trim().lowercase(Locale.getDefault())
            shown = if (q.isEmpty()) {
                all
            } else {
                val qCompact = q.replace(" ", "")
                val qHex = q.removePrefix("#")
                all.filter { (c, name) ->
                    val nameLower = name.lowercase(Locale.getDefault())
                    val rgb = "${c.r},${c.g},${c.b}"
                    val rgbSpaced = "${c.r} ${c.g} ${c.b}"
                    val hex = "%02x%02x%02x".format(c.r, c.g, c.b)
                    nameLower.contains(q) || rgb.contains(qCompact) ||
                        rgbSpaced.contains(q) || hex.contains(qHex)
                }
            }
            notifyDataSetChanged()
        }

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val row = (convertView as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(4), 0, dp(4))
            }

            val info = if (row.childCount > 0) row.getChildAt(0) as TextView else TextView(this@MainActivity).apply {
                textSize = uiSp("db_text_size", 15f, 10f, 24f)
                setTextColor(Color.BLACK)
                setPadding(dp(4), dp(4), dp(4), dp(4))
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            }
            val save = if (row.childCount > 1) row.getChildAt(1) as Button else makePopupButton("ULOŽIT").apply {
                layoutParams = LinearLayout.LayoutParams(dp(uiInt("db_button_width", 92, 60, 130)), dp(uiInt("card_button_height", 38, 28, 70)))
            }
            val rename = if (row.childCount > 2) row.getChildAt(2) as Button else makePopupButton("NÁZEV").apply {
                layoutParams = LinearLayout.LayoutParams(dp(uiInt("db_button_width", 92, 60, 130)), dp(uiInt("card_button_height", 38, 28, 70)))
                text = "NÁZEV"
            }

            if (row.childCount == 0) {
                row.addView(info)
                row.addView(save)
                row.addView(rename)
            }

            save.background = aeroBackground(uiColor("popup_button", 0xBFE0E0E0.toInt()), dp(18))
            save.textSize = uiSp("popup_button_text_size", 13f, 10f, 28f)
            rename.background = aeroBackground(uiColor("popup_button", 0xBFE0E0E0.toInt()), dp(18))
            rename.textSize = uiSp("popup_button_text_size", 13f, 10f, 28f)
            save.layoutParams.width = dp(uiInt("db_button_width", 92, 60, 130))
            rename.layoutParams.width = dp(uiInt("db_button_width", 92, 60, 130))
            val (c, name) = shown[position]
            info.textSize = uiSp("db_text_size", 15f, 10f, 24f)
            info.text = "$name\nRGB ${c.r}, ${c.g}, ${c.b}   #%02X%02X%02X".format(c.r, c.g, c.b)
            save.text = if (isSaved(c)) "ULOŽENO" else "ULOŽIT"
            save.setOnClickListener {
                val now = !isSaved(c)
                setSaved(c, now)
                save.text = if (now) "ULOŽENO" else "ULOŽIT"
                Toast.makeText(
                    this@MainActivity,
                    if (now) "Barva uložena" else "Barva odebrána",
                    Toast.LENGTH_SHORT
                ).show()
            }
            rename.setOnClickListener { editColorName(c, dialog) }
            info.setOnClickListener {
                showColorOnMainScreen(c)
                dialog.dismiss()
                status.text = "Vybraná barva: ${displayName(c)}"
            }
            return row
        }
    }

    private fun editColorName(c: NamedColor, databaseDialog: AlertDialog) {
        val input = EditText(this).apply {
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setText(displayName(c))
            selectAll()
        }
        AlertDialog.Builder(this)
            .setTitle("Název barvy")
            .setView(input)
            .setNegativeButton("Zrušit", null)
            .setPositiveButton("ULOŽIT") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    prefs.edit().putString("name_${colorKey(c)}", name).apply()
                    databaseDialog.dismiss()
                    showColorDatabase()
                    Toast.makeText(this, "Název uložen: $name", Toast.LENGTH_SHORT).show()
                }
            }
            .show().also { stylePopup(it) }
    }

    private fun editSavedColorName(c: NamedColor, savedDialog: AlertDialog) {
        val input = EditText(this).apply {
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setText(displayName(c))
            selectAll()
        }
        AlertDialog.Builder(this)
            .setTitle("Přejmenovat uloženou barvu")
            .setView(input)
            .setNegativeButton("Zrušit", null)
            .setPositiveButton("ULOŽIT") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    prefs.edit().putString("name_${colorKey(c)}", name).apply()
                    savedDialog.dismiss()
                    showSavedColors()
                    Toast.makeText(this, "Název uložen: $name", Toast.LENGTH_SHORT).show()
                }
            }
            .show().also { stylePopup(it) }
    }

    private fun showLabGroups() {
        val groups = loadLabGroups()
        val dialog = AlertDialog.Builder(this).create()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(10))
        }
        box.addView(TextView(this).apply {
            text = "SKUPINY"
            textSize = 22f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 0, 0, dp(10))
        })
        if (groups.isEmpty()) {
            box.addView(TextView(this).apply {
                text = "Zatím nemáš vytvořenou žádnou skupinu."
                textSize = 16f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setPadding(0, dp(12), 0, dp(12))
            })
        } else {
            val scroll = ScrollView(this).apply { isFillViewport = true }
            val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            groups.forEachIndexed { index, group ->
                val container = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(0, dp(3), 0, dp(3))
                }
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(4), dp(7), dp(4), dp(7))
                    isClickable = true
                    setBackgroundColor(Color.TRANSPARENT)
                }
                val arrow = TextView(this).apply {
                    text = "▶"
                    textSize = 15f
                    setTypeface(typeface, android.graphics.Typeface.BOLD)
                    gravity = Gravity.CENTER
                    layoutParams = LinearLayout.LayoutParams(dp(28), dp(44))
                }
                val title = TextView(this).apply {
                    text = group.name
                    textSize = 17f
                    setTextColor(Color.BLACK)
                    setTypeface(typeface, android.graphics.Typeface.BOLD)
                    gravity = Gravity.CENTER_VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f)
                }
                val edit = makePopupButton("UPRAVIT").apply { setTypeface(typeface, android.graphics.Typeface.BOLD) }
                val del = makePopupButton("SMAZAT").apply { setTypeface(typeface, android.graphics.Typeface.BOLD) }
                val details = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    visibility = View.GONE
                    setPadding(dp(34), 0, 0, dp(8))
                }
                val memberNames = group.members.mapNotNull { key ->
                    colors.find { colorKey(it) == key }?.let(::displayName)
                }
                if (memberNames.isEmpty()) {
                    details.addView(TextView(this).apply {
                        text = "(prázdná skupina)"
                        textSize = 14f
                        setTypeface(typeface, android.graphics.Typeface.BOLD)
                        setTextColor(Color.DKGRAY)
                        setPadding(0, dp(4), 0, dp(4))
                    })
                } else {
                    memberNames.forEach { memberName ->
                        details.addView(TextView(this).apply {
                            text = "• $memberName"
                            textSize = 15f
                            setTypeface(typeface, android.graphics.Typeface.BOLD)
                            setTextColor(Color.BLACK)
                            setPadding(0, dp(3), 0, dp(3))
                        })
                    }
                }
                fun toggleDetails() {
                    val open = details.visibility != View.VISIBLE
                    details.visibility = if (open) View.VISIBLE else View.GONE
                    arrow.text = if (open) "▼" else "▶"
                }
                row.setOnClickListener { toggleDetails() }
                edit.setOnClickListener { editLabGroup(index, dialog) }
                del.setOnClickListener {
                    val current = loadLabGroups()
                    if (index in current.indices) {
                        current.removeAt(index)
                        saveLabGroups(current)
                    }
                    dialog.dismiss()
                    showLabGroups()
                }
                row.addView(arrow)
                row.addView(title)
                row.addView(edit, LinearLayout.LayoutParams(dp(88), dp(38)).apply { marginEnd = dp(4) })
                row.addView(del, LinearLayout.LayoutParams(dp(88), dp(38)))
                container.addView(row)
                container.addView(details)
                list.addView(container)
            }
            scroll.addView(list)
            box.addView(scroll, LinearLayout.LayoutParams(-1, dp(430)))
        }
        dialog.setView(box)
        dialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Zavřít") { _, _ -> dialog.dismiss() }
        dialog.show()
        stylePopup(dialog)
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.94).toInt(), (resources.displayMetrics.heightPixels * 0.78).toInt())
    }

    private fun editLabGroup(index: Int, parent: AlertDialog) {
        val groups = loadLabGroups()
        val group = groups.getOrNull(index) ?: return
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(6), dp(4), dp(6), dp(2)) }
        val nameInput = EditText(this).apply {
            setSingleLine(true)
            setText(group.name)
            selectAll()
        }
        box.addView(nameInput, LinearLayout.LayoutParams(-1, dp(48)))
        box.addView(TextView(this).apply {
            text = "Členové – klepnutím odebereš barvu:"
            textSize = 13f
            setTextColor(Color.BLACK)
            setPadding(0, dp(8), 0, dp(6))
        })
        val memberList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        group.members.toList().forEach { key ->
            val c = colors.find { colorKey(it) == key } ?: return@forEach
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val label = TextView(this).apply {
                text = "${displayName(c)}\nRGB ${c.r}, ${c.g}, ${c.b}"
                textSize = 14f
                setTextColor(Color.BLACK)
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            }
            val remove = makePopupButton("ODEBRAT").apply { setTypeface(typeface, android.graphics.Typeface.BOLD) }
            remove.setOnClickListener {
                group.members.remove(key)
                saveLabGroups(groups)
                parent.dismiss()
                showLabGroups()
            }
            row.addView(label)
            row.addView(remove, LinearLayout.LayoutParams(dp(100), dp(38)))
            memberList.addView(row)
        }
        box.addView(memberList)
        AlertDialog.Builder(this)
            .setTitle("Upravit skupinu")
            .setView(box)
            .setNegativeButton("Zrušit", null)
            .setPositiveButton("ULOŽIT") { _, _ ->
                val newName = nameInput.text.toString().trim()
                if (newName.isNotEmpty()) {
                    group.name = newName
                    saveLabGroups(groups)
                    parent.dismiss()
                    showLabGroups()
                }
            }
            .show().also { stylePopup(it) }
    }

    private fun showSavedColors() {
        val saved = colors.filter(::isSaved).sortedBy { displayName(it).lowercase(Locale.getDefault()) }
        val dialog = AlertDialog.Builder(this).create()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(10))
        }
        box.addView(TextView(this).apply {
            text = "ULOŽENÉ BARVY"
            textSize = 22f
            setPadding(0, 0, 0, dp(10))
        })
        if (saved.isEmpty()) {
            box.addView(TextView(this).apply {
                text = "Zatím nemáš uloženou žádnou barvu."
                textSize = 17f
                setPadding(0, dp(12), 0, dp(12))
            })
        } else {
            val scroll = ScrollView(this)
            val listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            saved.forEach { c ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, dp(5), 0, dp(5))
                }
                val info = TextView(this).apply {
                    text = "${displayName(c)}${if (prefs.getBoolean("saved_lab_${colorKey(c)}", false)) " LAB" else ""}\nRGB ${c.r}, ${c.g}, ${c.b}   #%02X%02X%02X".format(c.r, c.g, c.b)
                    textSize = 15f
                    setTextColor(Color.BLACK)
                    layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                    setOnClickListener {
                        showColorOnMainScreen(c)
                        dialog.dismiss()
                        status.text = "Vybraná uložená barva: ${displayName(c)}"
                    }
                }
                val rename = makePopupButton("NÁZEV")
                rename.setOnClickListener { editSavedColorName(c, dialog) }
                val remove = makePopupButton("SMAZAT")
                remove.setOnClickListener {
                    setSaved(c, false)
                    dialog.dismiss()
                    showSavedColors()
                }
                row.addView(info)
                val buttonWidth = dp(uiInt("db_button_width", 92, 60, 130))
                val buttonHeight = dp(uiInt("card_button_height", 38, 28, 70))
                row.addView(rename, LinearLayout.LayoutParams(buttonWidth, buttonHeight).apply { marginEnd = dp(4) })
                row.addView(remove, LinearLayout.LayoutParams(buttonWidth, buttonHeight))
                listBox.addView(row)
            }
            scroll.addView(listBox)
            box.addView(scroll, LinearLayout.LayoutParams(-1, dp(480)))
        }
        dialog.setView(box)
        dialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Zavřít") { _, _ -> dialog.dismiss() }
        dialog.show()
        stylePopup(dialog)
        dialog.window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.94).toInt(),
            (resources.displayMetrics.heightPixels * 0.82).toInt()
        )
    }

    private fun showColorOnMainScreen(c: NamedColor) {
        updateDisplayedColor(c.r, c.g, c.b, displayName(c), false)
    }

    private fun nearestColor(r: Int, g: Int, b: Int): NamedColor? {
        if (colors.isEmpty()) return null
        val lab = ColorMath.rgbToLab(r, g, b)
        return colors.minByOrNull { candidate: NamedColor -> ColorMath.deltaE00(lab, candidate.lab) }
    }

    private fun updateDisplayedColor(r: Int, g: Int, b: Int, name: String?, resetNavigation: Boolean = true) {
        val rr = r.coerceIn(0, 255)
        val gg = g.coerceIn(0, 255)
        val bb = b.coerceIn(0, 255)
        updatingSliders = true
        redSeek.progress = rr
        greenSeek.progress = gg
        blueSeek.progress = bb
        updatingSliders = false
        result.setBackgroundColor(Color.rgb(rr, gg, bb))
        val brightness = (rr * 299 + gg * 587 + bb * 114) / 1000
        result.setTextColor(if (brightness < 140) Color.WHITE else Color.BLACK)
        rgbValues.text = "RGB $rr, $gg, $bb"
        result.text = if (name != null) "$name\nRGB $rr, $gg, $bb" else "RGB $rr, $gg, $bb"
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, r: ScanResult) {
            val name = try { r.device.name } catch (_: SecurityException) { null }
            if (name.isNullOrBlank() || !name.contains("LS170", true)) return
            stopScan(); ble?.close()
            ble = Ls170Ble(this@MainActivity, { rr, gg, bb ->
                val lab = ColorMath.rgbToLab(rr, gg, bb)
                val best = colors.minByOrNull { ColorMath.deltaE00(lab, it.lab) }
                runOnUiThread {
                    val labHandler = laboratoryMeasurementHandler
                    if (labHandler != null) {
                        labHandler(rr, gg, bb)
                    } else {
                        updateDisplayedColor(rr, gg, bb, best?.let(::groupDisplayName))
                        status.text = if (best != null) "Měření přijato: ${groupDisplayName(best)} • ΔE00 %.2f".format(ColorMath.deltaE00(lab, best.lab)) else "Měření přijato"
                    }
                    if (activeCardId != null) {
                        recordMeasurementToActiveCard(rr, gg, bb, best?.let(::displayName))
                    }
                }
            }, { s -> runOnUiThread { status.text = s } })
            ble?.connect(r.device)
        }
        override fun onScanFailed(errorCode: Int) {
            scanning = false
            runOnUiThread { status.text = "Skenování selhalo: $errorCode" }
        }
    }

    private fun startScan() {
        if (android.os.Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
            status.text = "Povol Bluetooth skenování a zkus znovu"; return
        }
        if (scanning) return
        scanning = true; status.text = "Hledám LS170…"; scanner.startScan(scanCallback)
    }

    private fun stopScan() {
        if (!scanning) return
        if (android.os.Build.VERSION.SDK_INT < 31 || checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED) scanner.stopScan(scanCallback)
        scanning = false
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        if (laboratoryOverlay != null && ::mainRootRef.isInitialized) {
            val r = laboratoryRInput?.text?.toString()?.toIntOrNull()
            val g = laboratoryGInput?.text?.toString()?.toIntOrNull()
            val b = laboratoryBInput?.text?.toString()?.toIntOrNull()
            if (r != null && g != null && b != null) laboratoryLastRgb = intArrayOf(r, g, b)
            closeLaboratory(mainRootRef)
            showLaboratory(mainRootRef)
        }
    }

    @Deprecated("Deprecated in Android API 30; kept for compatibility with the simple settings UI")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == exportTreeRequestCode && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (_: Exception) {}
            exportPrefs.edit().putString("tree_uri", uri.toString()).apply()
            Toast.makeText(this, "Složka pro export byla vybrána", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        laboratoryMeasurementHandler = null
        stopScan()
        ble?.close()
        super.onDestroy()
    }
}
