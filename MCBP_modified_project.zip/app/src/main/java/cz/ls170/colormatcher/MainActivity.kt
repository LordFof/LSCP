package cz.ls170.colormatcher

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothManager
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var result: TextView
    private lateinit var scan: Button
    private lateinit var measure: Button
    private lateinit var database: Button
    private lateinit var savedColorsButton: Button
    private lateinit var cardsButton: Button
    private lateinit var redSeek: SeekBar
    private lateinit var greenSeek: SeekBar
    private lateinit var blueSeek: SeekBar
    private lateinit var rgbValues: TextView
    private var updatingSliders = false
    private var ble: Ls170Ble? = null
    private var colors: List<NamedColor> = emptyList()
    private var scanning = false
    private lateinit var scanner: BluetoothLeScanner
    private val prefs by lazy { getSharedPreferences("mcbp_colors", Context.MODE_PRIVATE) }
    private val cardsPrefs by lazy { getSharedPreferences("mcbp_cards", Context.MODE_PRIVATE) }
    private var activeCardId: String? = null

    private fun colorKey(c: NamedColor) = "%d,%d,%d".format(c.r, c.g, c.b)
    private fun displayName(c: NamedColor): String =
        prefs.getString("name_${colorKey(c)}", null)?.takeIf { it.isNotBlank() } ?: c.name

    private fun isSaved(c: NamedColor): Boolean = prefs.getBoolean("saved_${colorKey(c)}", false)

    private fun setSaved(c: NamedColor, saved: Boolean) {
        prefs.edit().putBoolean("saved_${colorKey(c)}", saved).apply()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this).apply { setBackgroundColor(Color.rgb(28, 32, 38)) }

        result = TextView(this).apply {
            text = "Zatím žádné měření"
            textSize = 64f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(dp(18), dp(40), dp(18), dp(185))
        }
        root.addView(result, FrameLayout.LayoutParams(-1, -1))

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = aeroBackground(0x551E5AA8.toInt(), dp(22))
            elevation = dp(12).toFloat()
            visibility = View.GONE
        }
        status = TextView(this).apply {
            text = "Načítám…"
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(dp(2), 0, dp(2), dp(8))
        }
        scan = makeAeroButton("Hledat LS170")
        measure = makeAeroButton("Měřit")
        database = makeAeroButton("Databáze barev")
        savedColorsButton = makeAeroButton("ULOŽENÉ BARVY")
        cardsButton = makeAeroButton("KARTY")
        controls.addView(status)
        controls.addView(scan, LinearLayout.LayoutParams(-1, dp(40)).apply { bottomMargin = dp(5) })
        controls.addView(measure, LinearLayout.LayoutParams(-1, dp(40)).apply { bottomMargin = dp(5) })
        controls.addView(database, LinearLayout.LayoutParams(-1, dp(40)).apply { bottomMargin = dp(5) })
        controls.addView(savedColorsButton, LinearLayout.LayoutParams(-1, dp(40)).apply { bottomMargin = dp(5) })
        controls.addView(cardsButton, LinearLayout.LayoutParams(-1, dp(40)).apply { bottomMargin = dp(2) })

        val sliderPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(10), dp(16), dp(10))
            background = aeroBackground(0x332D73B7.toInt(), dp(24))
            elevation = dp(6).toFloat()
        }

        rgbValues = TextView(this).apply {
            text = "RGB 128, 128, 128   #808080"
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(4))
        }
        sliderPanel.addView(rgbValues, LinearLayout.LayoutParams(-1, dp(32)))

        fun addMainSlider(label: String, initial: Int): SeekBar {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val tv = TextView(this).apply {
                text = label
                textSize = 18f
                setTextColor(Color.WHITE)
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                gravity = Gravity.CENTER
                minWidth = dp(34)
            }
            val sb = SeekBar(this).apply {
                max = 255
                progress = initial
                layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f)
            }
            row.addView(tv)
            row.addView(sb)
            sliderPanel.addView(row, LinearLayout.LayoutParams(-1, dp(42)))
            return sb
        }
        redSeek = addMainSlider("R", 128)
        greenSeek = addMainSlider("G", 128)
        blueSeek = addMainSlider("B", 128)

        root.addView(sliderPanel, FrameLayout.LayoutParams(-1, dp(164)).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            setMargins(dp(10), 0, dp(10), dp(12))
        })

        val menuWrap = FrameLayout(this)
        menuWrap.addView(controls, FrameLayout.LayoutParams(dp(250), -2).apply {
            gravity = Gravity.BOTTOM or Gravity.END
            setMargins(0, 0, dp(12), dp(78))
        })
        val menuButton = TextView(this).apply {
            text = "☰"
            textSize = 23f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = aeroBackground(0x662B6CB0.toInt(), dp(30))
            elevation = dp(10).toFloat()
            contentDescription = "Nabídka"
        }
        menuWrap.addView(menuButton, FrameLayout.LayoutParams(dp(58), dp(58)).apply {
            gravity = Gravity.BOTTOM or Gravity.END
            setMargins(0, 0, dp(12), dp(10))
        })
        root.addView(menuWrap, FrameLayout.LayoutParams(-1, -1))

        var menuOpen = false
        menuButton.setOnClickListener {
            menuOpen = !menuOpen
            controls.visibility = if (menuOpen) View.VISIBLE else View.GONE
            menuButton.text = if (menuOpen) "×" else "☰"
        }

        val sliderListener = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!updatingSliders && fromUser) {
                    val rr = redSeek.progress
                    val gg = greenSeek.progress
                    val bb = blueSeek.progress
                    val nearest = nearestColor(rr, gg, bb)
                    updateDisplayedColor(rr, gg, bb, nearest?.let(::displayName))
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        }
        redSeek.setOnSeekBarChangeListener(sliderListener)
        greenSeek.setOnSeekBarChangeListener(sliderListener)
        blueSeek.setOnSeekBarChangeListener(sliderListener)

        val credit = TextView(this).apply {
            text = "Created by LordFof"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(0xCCFFFFFF.toInt())
        }
        root.addView(credit, FrameLayout.LayoutParams(-2, -2).apply {
            gravity = Gravity.BOTTOM or Gravity.START
            setMargins(dp(12), 0, 0, dp(14))
        })
        setContentView(root)

        if (android.os.Build.VERSION.SDK_INT >= 31) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT), 10)
        }

        Executors.newSingleThreadExecutor().execute {
            try {
                colors = ColorDb.load()
                runOnUiThread { status.text = "Databáze: ${colors.size} barev • připraveno" }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Databáze barev se nepodařila načíst" }
            }
        }

        val manager = getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
        scanner = manager.adapter.bluetoothLeScanner

        scan.setOnClickListener {
            ble?.close()
            stopScan()
            startScan()
        }
        measure.setOnClickListener {
            if (ble?.triggerMeasurement() == true) status.text = "Příkaz odeslán • čekám na měření…"
            else status.text = "LS170 není připravený — nejdřív ho připoj"
        }
        database.setOnClickListener { showColorDatabase() }
        savedColorsButton.setOnClickListener { showSavedColors() }
        cardsButton.setOnClickListener { showCards() }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun aeroBackground(color: Int, radius: Int): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
            setStroke(dp(1), 0x55FFFFFF)
        }

    private fun makeAeroButton(label: String): Button = Button(this).apply {
        text = label
        textSize = 13f
        setTextColor(Color.WHITE)
        isAllCaps = false
        background = aeroBackground(0x552D73B7.toInt(), dp(18))
        stateListAnimator = null
        elevation = dp(3).toFloat()
        setPadding(dp(8), 0, dp(8), 0)
    }

    private fun nearestColor(r: Int, g: Int, b: Int): NamedColor? {
        if (colors.isEmpty()) return null
        val lab = ColorMath.rgbToLab(r, g, b)
        return colors.minByOrNull { ColorMath.deltaE00(lab, it.lab) }
    }

    private fun updateDisplayedColor(r: Int, g: Int, b: Int, name: String?, resetNavigation: Boolean = true) {
        val rr = r.coerceIn(0, 255)
        val gg = g.coerceIn(0, 255)
        val bb = b.coerceIn(0, 255)
        updatingSliders = true
        redSeek.progress = rr
        greenSeek.progress = gg
        blueSeek.progress = bb
        updatingSliders = false
        result.setBackgroundColor(Color.rgb(rr, gg, bb))
        val brightness = (rr * 299 + gg * 587 + bb * 114) / 1000
        result.setTextColor(if (brightness < 140) Color.WHITE else Color.BLACK)
        val hex = "#%02X%02X%02X".format(rr, gg, bb)
        rgbValues.text = "RGB $rr, $gg, $bb   $hex"
        result.text = if (name != null) "$name\nRGB $rr, $gg, $bb\n$hex" else "RGB $rr, $gg, $bb\n$hex"
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, r: ScanResult) {
            val name = try { r.device.name } catch (_: SecurityException) { null }
            if (name.isNullOrBlank() || !name.contains("LS170", true)) return
            stopScan(); ble?.close()
            ble = Ls170Ble(this@MainActivity, { rr, gg, bb ->
                val lab = ColorMath.rgbToLab(rr, gg, bb)
                val best = colors.minByOrNull { ColorMath.deltaE00(lab, it.lab) }
                runOnUiThread {
                    updateDisplayedColor(rr, gg, bb, best?.let(::displayName))
                    status.text = if (best != null) "Měření přijato • ΔE00 %.2f".format(ColorMath.deltaE00(lab, best.lab)) else "Měření přijato"
                    if (activeCardId != null) {
                        recordMeasurementToActiveCard(rr, gg, bb, best?.let(::displayName))
                    }
                }
            }, { s -> runOnUiThread { status.text = s } })
            ble?.connect(r.device)
        }
        override fun onScanFailed(errorCode: Int) {
            scanning = false
            runOnUiThread { status.text = "Skenování selhalo: $errorCode" }
        }
    }

    private fun startScan() {
        if (android.os.Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
            status.text = "Povol Bluetooth skenování a zkus znovu"; return
        }
        if (scanning) return
        scanning = true; status.text = "Hledám LS170…"; scanner.startScan(scanCallback)
    }

    private fun stopScan() {
        if (!scanning) return
        if (android.os.Build.VERSION.SDK_INT < 31 || checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED) scanner.stopScan(scanCallback)
        scanning = false
    }

    override fun onDestroy() {
        stopScan()
        ble?.close()
        super.onDestroy()
    }
}
