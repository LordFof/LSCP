# LS170 Color Matcher

Android app for the LS170 colorimeter.

## Measurement flow
1. Tap **Hledat LS170**.
2. The app connects and discovers FFE0/FFE4 notifications and FFE5/FFE9 write service.
3. The app does **not** send a measurement command after connecting.
4. Press the physical measurement button on the LS170.
5. The app receives the BLE notification, extracts RGB from response bytes 36..38, and finds the nearest color using the current color database and CIEDE2000.
6. If the LS170 disconnects, the app resets the GATT state so another **Hledat LS170** scan can reconnect.
